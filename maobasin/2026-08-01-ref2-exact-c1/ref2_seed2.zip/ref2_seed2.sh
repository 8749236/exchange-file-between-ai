set -e
export OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 PYTHONUNBUFFERED=1
python3 ref2.py --outdir ref2_runs/N16_s2 --id-count 16 --steps 2000 --seed 2
python3 ref2.py --outdir ref2_runs/N64_s2 --id-count 64 --steps 10000 --seed 2
echo SEED2_DONE
