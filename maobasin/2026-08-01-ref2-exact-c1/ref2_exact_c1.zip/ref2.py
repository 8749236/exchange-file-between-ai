# 猫盆参考实现 v2（ref2）：exact-C1 语义的 CoT 链条任务
# 对齐 C1Stream（v0.1.9 c1_data.py）：
#   names/codes/values = randperm(id_count)[:4]（episode 内唯一）
#   B facts 经 randperm(4) 随机置换；filler randint(192,240,37)
#   [A_MARK,n,64+c]x4 @0-11, [B_MARK,64+c,128+v]x4 @12-23,
#   filler @24-60, [Q_MARK,n] @61-62, c @63, v @64（模型输入序列长度 65）
# 训练：CE(pos62->c) + CE(pos63->v)，logits 切片到合法类域 [64,64+idc) / [128,128+idc)
# 评估：free-running（ĉ 写回）+ teacher-forced v，固定验证集 1024 episodes（独立种子，一次生成）
# 归档：config.json 含脚本 SHA256 / torch 版本 / 线程数 / 全部超参；trajectory.jsonl 全量曲线
import argparse, hashlib, json, os, platform, time
import torch, torch.nn as nn, torch.nn.functional as F

A_MARK, B_MARK, Q_MARK = 250, 251, 252

def make_episodes(g, B, idc):
    names = torch.stack([torch.randperm(idc, generator=g)[:4] for _ in range(B)])
    codes = torch.stack([torch.randperm(idc, generator=g)[:4] for _ in range(B)])
    values = torch.stack([torch.randperm(idc, generator=g)[:4] for _ in range(B)])
    perm = torch.stack([torch.randperm(4, generator=g) for _ in range(B)])
    qi = torch.randint(0, 4, (B,), generator=g)
    ep = torch.zeros(B, 65, dtype=torch.long)
    rows = torch.arange(B)
    for f in range(4):
        ep[:, 3*f] = A_MARK; ep[:, 3*f+1] = names[:, f]; ep[:, 3*f+2] = 64 + codes[:, f]
    for s in range(4):
        src = perm[:, s]
        ep[:, 12+3*s] = B_MARK
        ep[:, 12+3*s+1] = 64 + codes[rows, src]
        ep[:, 12+3*s+2] = 128 + values[rows, src]
    ep[:, 24:61] = torch.randint(192, 240, (B, 37), generator=g)
    ep[:, 61] = Q_MARK
    ep[:, 62] = names[rows, qi]
    ep[:, 63] = 64 + codes[rows, qi]
    ep[:, 64] = 128 + values[rows, qi]
    return ep, codes[rows, qi], values[rows, qi]

class Ref2(nn.Module):
    def __init__(self, V=256, d=64, L=2, H=2, maxlen=80):
        super().__init__()
        self.tok = nn.Embedding(V, d); self.pos = nn.Embedding(maxlen, d)
        layer = nn.TransformerEncoderLayer(d, H, 4*d, dropout=0.0,
                                           batch_first=True, norm_first=False)
        self.tr = nn.TransformerEncoder(layer, L)
        self.head = nn.Linear(d, V)
    def forward(self, x):
        T = x.shape[1]
        h = self.tok(x) + self.pos(torch.arange(T, device=x.device)).unsqueeze(0)
        m = torch.triu(torch.ones(T, T, device=x.device, dtype=torch.bool), 1)
        return self.tr(h, mask=m)

def run(outdir, idc, steps, seed, B=64, lr=3e-3, valid_n=1024, eval_every=200, nthreads=2):
    torch.set_num_threads(nthreads)
    torch.manual_seed(seed)
    m = Ref2()
    opt = torch.optim.AdamW(m.parameters(), lr=lr, weight_decay=0.0)
    g_train = torch.Generator().manual_seed(10_000 + seed)
    g_valid = torch.Generator().manual_seed(999_983)  # 固定验证集，所有 run 共用
    V_ep, V_c, V_v = make_episodes(g_valid, valid_n, idc)

    os.makedirs(outdir, exist_ok=True)
    sha = hashlib.sha256(open(__file__, 'rb').read()).hexdigest()
    config = dict(script=__file__, script_sha256=sha, id_count=idc, steps=steps,
                  seed=seed, batch=B, lr=lr, weight_decay=0.0, dropout=0.0,
                  clip=1.0, valid_n=valid_n, valid_seed=999_983, eval_every=eval_every,
                  torch_threads=nthreads, torch_version=torch.__version__,
                  platform=platform.platform(), exact_c1=True,
                  model='2L/d64/H2/learned-pos/post-norm/full-head-sliced-loss')
    json.dump(config, open(os.path.join(outdir, 'config.json'), 'w'),
              ensure_ascii=False, indent=1)
    fj = open(os.path.join(outdir, 'trajectory.jsonl'), 'w')

    for step in range(1, steps + 1):
        seqs, cs, vs = make_episodes(g_train, B, idc)
        h = m(seqs)
        loss = F.cross_entropy(m.head(h[:, 62])[:, 64:64+idc], cs) + \
               F.cross_entropy(m.head(h[:, 63])[:, 128:128+idc], vs)
        opt.zero_grad(); loss.backward()
        nn.utils.clip_grad_norm_(m.parameters(), 1.0)
        opt.step()
        if step % eval_every == 0 or step == steps:
            with torch.no_grad():
                h = m(V_ep)
                chat = m.head(h[:, 62])[:, 64:64+idc].argmax(-1)
                x2 = V_ep.clone(); x2[:, 63] = 64 + chat
                vhat = m.head(m(x2)[:, 63])[:, 128:128+idc].argmax(-1)
                rec = dict(step=step,
                           loss=round(loss.item(), 6),
                           free_c=round((chat == V_c).float().mean().item(), 4),
                           free_v=round((vhat == V_v).float().mean().item(), 4),
                           chain=round(((chat == V_c) & (vhat == V_v)).float().mean().item(), 4),
                           tf_v=round((m.head(h[:, 63])[:, 128:128+idc].argmax(-1) == V_v).float().mean().item(), 4))
            fj.write(json.dumps(rec) + '\n'); fj.flush()
            print(outdir, rec, flush=True)
    fj.close()

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--outdir', required=True)
    p.add_argument('--id-count', type=int, required=True)
    p.add_argument('--steps', type=int, required=True)
    p.add_argument('--seed', type=int, default=1)
    a = p.parse_args()
    t0 = time.time()
    run(a.outdir, a.id_count, a.steps, a.seed)
    print('ELAPSED', round(time.time() - t0, 1), 's')
