set -e
export OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 PYTHONUNBUFFERED=1
# 确定性双跑（同脚本同 seed 两次，400 步）
python3 ref2.py --outdir ref2_runs/DET1 --id-count 64 --steps 400 --seed 1
python3 ref2.py --outdir ref2_runs/DET2 --id-count 64 --steps 400 --seed 1
# N16 与 N64 正式标注运行
python3 ref2.py --outdir ref2_runs/N16_s1 --id-count 16 --steps 2000 --seed 1
python3 ref2.py --outdir ref2_runs/N64_s1 --id-count 64 --steps 10000 --seed 1
echo ALL_REF2_DONE
