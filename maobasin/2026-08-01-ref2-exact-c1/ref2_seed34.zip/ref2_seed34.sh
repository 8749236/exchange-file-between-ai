set -e
export OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 PYTHONUNBUFFERED=1
python3 ref2.py --outdir ref2_runs/N64_s3 --id-count 64 --steps 10000 --seed 3
python3 ref2.py --outdir ref2_runs/N64_s4 --id-count 64 --steps 10000 --seed 4
echo SEED34_DONE
