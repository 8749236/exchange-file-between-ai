# 复现网格3：距离/洗牌消融 —— 当年相变也许靠的是短 filler 或洗牌
# S1: marker格式 Ffill=20 固定A先B后（len 48）
# S2: marker格式 Ffill=37 洗牌（A/B对交错，len 65）
# S3: marker格式 Ffill=20 洗牌（len 48）
import torch, torch.nn as nn, torch.nn.functional as F, random, json
A_MARK, B_MARK, Q_MARK = 250, 251, 252
NID = 64
N16 = 16

def gen(B, ffill, shuffle):
    L = 24 + ffill + 4
    seqs = torch.zeros(B, L, dtype=torch.long)
    cs = torch.zeros(B, dtype=torch.long); vs = torch.zeros(B, dtype=torch.long)
    qpos = 24 + ffill  # query mark 位置
    for b in range(B):
        ids = random.sample(range(NID), 4)
        codes = [random.randrange(NID) for _ in range(4)]
        vals = [random.randrange(NID) for _ in range(4)]
        facts = list(zip(ids, codes, vals))
        a = [[A_MARK, n, 64 + c] for (n, c, v) in facts]
        bf = [[B_MARK, 64 + c, 128 + v] for (n, c, v) in facts]
        if shuffle:
            pairs = a + bf
            random.shuffle(pairs)
            row = [t for p in pairs for t in p]
        else:
            row = [t for p in a for t in p] + [t for p in bf for t in p]
        row += [random.randrange(192, 240) for _ in range(ffill)]
        qn, qc, qv = random.choice(facts)
        row += [Q_MARK, qn, 64 + qc, 128 + qv]
        seqs[b] = torch.tensor(row); cs[b] = qc; vs[b] = qv
    return seqs, cs, vs, qpos

class BindTinyR(nn.Module):
    def __init__(self, V=256, d=64, L=2, H=2, maxlen=80):
        super().__init__()
        self.tok = nn.Embedding(V, d); self.pos = nn.Embedding(maxlen, d)
        layer = nn.TransformerEncoderLayer(d, H, 4*d, dropout=0.0,
                                           batch_first=True, norm_first=False)
        self.tr = nn.TransformerEncoder(layer, L)
        self.head = nn.Linear(d, V)
    def forward(self, x):
        T = x.shape[1]
        h = self.tok(x) + self.pos(torch.arange(T, device=x.device)).unsqueeze(0)
        m = torch.triu(torch.ones(T, T, device=x.device, dtype=torch.bool), 1)
        return self.tr(h, mask=m)

def run(tag, ffill, shuffle, steps=2000, B=64, lr=3e-3, seed=1):
    torch.manual_seed(seed); random.seed(seed)
    m = BindTinyR()
    opt = torch.optim.AdamW(m.parameters(), lr=lr, weight_decay=0.0)
    log = []
    for step in range(1, steps+1):
        seqs, cs, vs, qpos = gen(B, ffill, shuffle)
        h = m(seqs)
        lc = F.cross_entropy(m.head(h[:, qpos+1])[:, 64:128], cs)
        lv = F.cross_entropy(m.head(h[:, qpos+2])[:, 128:192], vs)
        loss = lc + lv
        opt.zero_grad(); loss.backward()
        nn.utils.clip_grad_norm_(m.parameters(), 1.0)
        opt.step()
        if step % 200 == 0:
            with torch.no_grad():
                seqs, cs, vs, qpos = gen(200, ffill, shuffle)
                h = m(seqs)
                chat = m.head(h[:, qpos+1])[:, 64:128].argmax(-1)
                x2 = seqs.clone(); x2[:, qpos+2] = 64 + chat
                vhat = m.head(m(x2)[:, qpos+2])[:, 128:192].argmax(-1)
                c_acc = (chat == cs).float().mean().item()
                v_acc = (vhat == vs).float().mean().item()
                chain = ((chat == cs) & (vhat == vs)).float().mean().item()
                tf_v = (m.head(h[:, qpos+2])[:, 128:192].argmax(-1) == vs).float().mean().item()
            log.append(dict(step=step, c=round(c_acc,3), v=round(v_acc,3),
                            chain=round(chain,3), tf_v=round(tf_v,3),
                            loss=round(loss.item(),3)))
            print(tag, log[-1], flush=True)
    return log

if __name__ == '__main__':
    res = {}
    res['S1_ff20_fixed'] = run('S1', 20, False)
    res['S3_ff20_shuf']  = run('S3', 20, True)
    res['S2_ff37_shuf']  = run('S2', 37, True)
    json.dump(res, open('/mnt/agents/output/repro_grid3_results.json', 'w'),
              ensure_ascii=False, indent=1)
    print('DONE')
