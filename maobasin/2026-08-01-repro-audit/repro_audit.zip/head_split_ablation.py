# 头部分裂消融（猫盆盆地侧）：SHARE 单头 vs SPLIT 码/值双头
# 任务：她们的 marker 格式 CoT，64 IDs，lr 3e-3，clip 1.0，2000 步，WD 0
# 与 v1.4 回执中 "你们的格式 @1600/@2000 两段式相变" 同款设置
import torch, torch.nn as nn, torch.nn.functional as F, random, json, math, sys

A_MARK, B_MARK, Q_MARK = 250, 251, 252
FILL0 = 192  # fillers 192-239
NID = 64

def gen_their_cot(B, N=NID, device='cpu'):
    seqs = torch.zeros(B, 65, dtype=torch.long)
    cs = torch.zeros(B, dtype=torch.long)
    vs = torch.zeros(B, dtype=torch.long)
    for b in range(B):
        ids = random.sample(range(N), 4)
        facts = []
        for n in ids:
            c = random.randrange(NID); v = random.randrange(NID)
            facts.append((n, c, v))
        # A facts pos 0-11: [A_MARK, n, 64+c] x4
        row = []
        for (n, c, v) in facts: row += [A_MARK, n, 64 + c]
        # B facts pos 12-23: [B_MARK, 64+c, 128+v] x4
        for (n, c, v) in facts: row += [B_MARK, 64 + c, 128 + v]
        # filler 24-60 (37 tokens)
        row += [random.randrange(FILL0, FILL0 + 48) for _ in range(37)]
        # query 61-62
        qn, qc, qv = random.choice(facts)
        row += [Q_MARK, qn, 64 + qc, 128 + qv]  # 63: c, 64: v（训练标签位）
        seqs[b] = torch.tensor(row)
        cs[b] = qc; vs[b] = qv
    return seqs.to(device), cs.to(device), vs.to(device)

class BindTiny(nn.Module):
    def __init__(self, V=256, d=64, L=2, H=2, maxlen=80, split=False):
        super().__init__()
        self.tok = nn.Embedding(V, d); self.pos = nn.Embedding(maxlen, d)
        layer = nn.TransformerEncoderLayer(d, H, 4 * d, dropout=0.0,
                                           batch_first=True, norm_first=False)
        self.tr = nn.TransformerEncoder(layer, L)
        self.split = split
        self.head = nn.Linear(d, V)              # 共享头（两版都保留：filler/无关位用）
        if split:
            self.head_c = nn.Linear(d, NID)      # 码头：64 类 -> token 64..127
            self.head_v = nn.Linear(d, NID)      # 值头：64 类 -> token 128..191
        self.maxlen = maxlen
    def forward(self, x):
        B, T = x.shape
        h = self.tok(x) + self.pos(torch.arange(T, device=x.device)).unsqueeze(0)
        m = torch.triu(torch.ones(T, T, device=x.device, dtype=torch.bool), 1)
        h = self.tr(h, mask=m)
        return h
    def logits_c(self, h_last):
        return self.head_c(h_last) if self.split else self.head(h_last)[:, 64:128]
    def logits_v(self, h_last):
        return self.head_v(h_last) if self.split else self.head(h_last)[:, 128:192]

def run(tag, split, steps=2000, B=32, lr=3e-3, seed=1):
    torch.manual_seed(seed); random.seed(seed)
    m = BindTiny(split=split)
    opt = torch.optim.AdamW(m.parameters(), lr=lr, weight_decay=0.0)
    log = []
    for step in range(1, steps + 1):
        seqs, cs, vs = gen_their_cot(B)
        h = m(seqs)
        # c 位：pos 62 的隐状态预测 c（token 63）；v 位：pos 63（含真 c）预测 v
        lc = F.cross_entropy(m.logits_c(h[:, 62]), cs)
        lv = F.cross_entropy(m.logits_v(h[:, 63]), vs)
        loss = lc + lv
        opt.zero_grad(); loss.backward()
        nn.utils.clip_grad_norm_(m.parameters(), 1.0)
        opt.step()
        if step % 200 == 0 or step == steps - 1:
            with torch.no_grad():
                seqs, cs, vs = gen_their_cot(200)
                h = m(seqs)
                # free-run：ĉ 写回
                chat = m.logits_c(h[:, 62]).argmax(-1)                 # 0..63
                x2 = seqs.clone()
                # 模拟写回：把 64+ĉ 放到 pos 63 再算 pos 63 隐状态
                x2[:, 63] = 64 + chat
                h2 = m(x2)
                vhat = m.logits_v(h2[:, 63]).argmax(-1)
                c_acc = (chat == cs).float().mean().item()
                v_acc = (vhat == vs).float().mean().item()
                chain = ((chat == cs) & (vhat == vs)).float().mean().item()
                # 教师强制 v
                tf_v = (m.logits_v(h[:, 63]).argmax(-1) == vs).float().mean().item()
            log.append(dict(step=step, c=round(c_acc, 3), v=round(v_acc, 3),
                            chain=round(chain, 3), tf_v=round(tf_v, 3),
                            loss=round(loss.item(), 3)))
            print(tag, log[-1], flush=True)
    return log

if __name__ == '__main__':
    res = {}
    res['SHARE'] = run('SHARE', split=False)
    res['SPLIT'] = run('SPLIT', split=True)
    json.dump(res, open('/mnt/agents/output/head_split_results.json', 'w'),
              ensure_ascii=False, indent=1)
    print('DONE')
