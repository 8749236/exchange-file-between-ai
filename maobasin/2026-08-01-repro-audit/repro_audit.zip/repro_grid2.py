# 复现网格2：全词表CE / 码唯一 / 两者兼具 —— 找当年相变的真配置
import torch, torch.nn as nn, torch.nn.functional as F, random, json
A_MARK, B_MARK, Q_MARK = 250, 251, 252
NID = 64

def gen(B, unique=False):
    seqs = torch.zeros(B, 65, dtype=torch.long)
    cs = torch.zeros(B, dtype=torch.long); vs = torch.zeros(B, dtype=torch.long)
    for b in range(B):
        ids = random.sample(range(NID), 4)
        if unique:
            codes = random.sample(range(NID), 4); vals = random.sample(range(NID), 4)
        else:
            codes = [random.randrange(NID) for _ in range(4)]
            vals = [random.randrange(NID) for _ in range(4)]
        facts = list(zip(ids, codes, vals))
        row = []
        for (n, c, v) in facts: row += [A_MARK, n, 64 + c]
        for (n, c, v) in facts: row += [B_MARK, 64 + c, 128 + v]
        row += [random.randrange(192, 240) for _ in range(37)]
        qn, qc, qv = random.choice(facts)
        row += [Q_MARK, qn, 64 + qc, 128 + qv]
        seqs[b] = torch.tensor(row); cs[b] = qc; vs[b] = qv
    return seqs, cs, vs

class BindTinyR(nn.Module):
    def __init__(self, V=256, d=64, L=2, H=2, maxlen=80):
        super().__init__()
        self.tok = nn.Embedding(V, d); self.pos = nn.Embedding(maxlen, d)
        layer = nn.TransformerEncoderLayer(d, H, 4*d, dropout=0.0,
                                           batch_first=True, norm_first=False)
        self.tr = nn.TransformerEncoder(layer, L)
        self.head = nn.Linear(d, V)
    def forward(self, x):
        T = x.shape[1]
        h = self.tok(x) + self.pos(torch.arange(T, device=x.device)).unsqueeze(0)
        m = torch.triu(torch.ones(T, T, device=x.device, dtype=torch.bool), 1)
        return self.tr(h, mask=m)

def run(tag, unique, fullce, steps=2000, B=64, lr=3e-3, seed=1):
    torch.manual_seed(seed); random.seed(seed)
    m = BindTinyR()
    opt = torch.optim.AdamW(m.parameters(), lr=lr, weight_decay=0.0)
    log = []
    def logits(hpos, lo, hi):
        out = m.head(hpos)
        return out if fullce else out[:, lo:hi]
    def evlog(hpos, lo, hi):  # eval 永远切片到合法类域
        return m.head(hpos)[:, lo:hi]
    for step in range(1, steps+1):
        seqs, cs, vs = gen(B, unique)
        h = m(seqs)
        tc = cs + 64 if fullce else cs
        tv = vs + 128 if fullce else vs
        loss = F.cross_entropy(logits(h[:, 62], 64, 128), tc) + \
               F.cross_entropy(logits(h[:, 63], 128, 192), tv)
        opt.zero_grad(); loss.backward()
        nn.utils.clip_grad_norm_(m.parameters(), 1.0)
        opt.step()
        if step % 200 == 0:
            with torch.no_grad():
                seqs, cs, vs = gen(200, unique)
                h = m(seqs)
                chat = evlog(h[:, 62], 64, 128).argmax(-1)
                x2 = seqs.clone(); x2[:, 63] = 64 + chat
                vhat = evlog(m(x2)[:, 63], 128, 192).argmax(-1)
                c_acc = (chat == cs).float().mean().item()
                v_acc = (vhat == vs).float().mean().item()
                chain = ((chat == cs) & (vhat == vs)).float().mean().item()
                tf_v = (evlog(h[:, 63], 128, 192).argmax(-1) == vs).float().mean().item()
            log.append(dict(step=step, c=round(c_acc,3), v=round(v_acc,3),
                            chain=round(chain,3), tf_v=round(tf_v,3),
                            loss=round(loss.item(),3)))
            print(tag, log[-1], flush=True)
    return log

if __name__ == '__main__':
    res = {}
    res['F3_fullce_unique'] = run('F3', unique=True,  fullce=True)
    res['F1_fullce']        = run('F1', unique=False, fullce=True)
    res['F2_unique']        = run('F2', unique=True,  fullce=False)
    json.dump(res, open('/mnt/agents/output/repro_grid2_results.json', 'w'),
              ensure_ascii=False, indent=1)
    print('DONE')
