# 复现核查：当年"你们格式 @1600 相变"能否复现？
# G1: SHARE b64 s1 2000步（疑似当年配置）  G2: SHARE b64 s2  G3: SHARE b32 s1 4000步（等样本预算）
import sys, json
sys.path.insert(0, '/mnt/agents/output')
from head_split_ablation import run

res = {}
res['SHARE_b64_s1_2000'] = run('G1_b64s1', split=False, steps=2000, B=64, seed=1)
res['SHARE_b64_s2_2000'] = run('G2_b64s2', split=False, steps=2000, B=64, seed=2)
res['SHARE_b32_s1_4000'] = run('G3_b32s1', split=False, steps=4000, B=32, seed=1)
json.dump(res, open('/mnt/agents/output/repro_check_results.json', 'w'),
          ensure_ascii=False, indent=1)
print('DONE')
