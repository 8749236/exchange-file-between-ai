# 正则归因网格：复现当年相变的关键是不是被我"洗"掉的 PyTorch 默认值
# A: dropout0.1 + WD0.01（PyTorch 默认，疑似当年真配置）
# B: dropout0.1 + WD0
# C: dropout0 + WD0.01
# 全部 SHARE 头、b64、seed 1、2000 步、lr 3e-3、clip 1.0
import torch, torch.nn as nn, torch.nn.functional as F, random, json, sys
sys.path.insert(0, '/mnt/agents/output')
from head_split_ablation import gen_their_cot, NID

class BindTinyR(nn.Module):
    def __init__(self, V=256, d=64, L=2, H=2, maxlen=80, dropout=0.0):
        super().__init__()
        self.tok = nn.Embedding(V, d); self.pos = nn.Embedding(maxlen, d)
        layer = nn.TransformerEncoderLayer(d, H, 4*d, dropout=dropout,
                                           batch_first=True, norm_first=False)
        self.tr = nn.TransformerEncoder(layer, L)
        self.head = nn.Linear(d, V)
    def forward(self, x):
        B, T = x.shape
        h = self.tok(x) + self.pos(torch.arange(T, device=x.device)).unsqueeze(0)
        m = torch.triu(torch.ones(T, T, device=x.device, dtype=torch.bool), 1)
        return self.tr(h, mask=m)

def run(tag, dropout, wd, steps=2000, B=64, lr=3e-3, seed=1):
    torch.manual_seed(seed); random.seed(seed)
    m = BindTinyR(dropout=dropout)
    opt = torch.optim.AdamW(m.parameters(), lr=lr, weight_decay=wd)
    log = []
    for step in range(1, steps+1):
        m.train()
        seqs, cs, vs = gen_their_cot(B)
        h = m(seqs)
        lc = F.cross_entropy(m.head(h[:, 62])[:, 64:128], cs)
        lv = F.cross_entropy(m.head(h[:, 63])[:, 128:192], vs)
        loss = lc + lv
        opt.zero_grad(); loss.backward()
        nn.utils.clip_grad_norm_(m.parameters(), 1.0)
        opt.step()
        if step % 200 == 0:
            m.eval()
            with torch.no_grad():
                seqs, cs, vs = gen_their_cot(200)
                h = m(seqs)
                chat = m.head(h[:, 62])[:, 64:128].argmax(-1)
                x2 = seqs.clone(); x2[:, 63] = 64 + chat
                vhat = m.head(m(x2)[:, 63])[:, 128:192].argmax(-1)
                c_acc = (chat == cs).float().mean().item()
                v_acc = (vhat == vs).float().mean().item()
                chain = ((chat == cs) & (vhat == vs)).float().mean().item()
                tf_v = (m.head(h[:, 63])[:, 128:192].argmax(-1) == vs).float().mean().item()
            log.append(dict(step=step, c=round(c_acc,3), v=round(v_acc,3),
                            chain=round(chain,3), tf_v=round(tf_v,3),
                            loss=round(loss.item(),3)))
            print(tag, log[-1], flush=True)
    return log

if __name__ == '__main__':
    res = {}
    res['A_d01_wd001'] = run('A', 0.1, 0.01)
    res['B_d01_wd0']   = run('B', 0.1, 0.0)
    res['C_d0_wd001']  = run('C', 0.0, 0.01)
    json.dump(res, open('/mnt/agents/output/reg_grid_results.json', 'w'),
              ensure_ascii=False, indent=1)
    print('DONE')
