# N=16 验证：如果相变在 ~1000-1600 复现，v1.4 表格就是 N=16 误标
import sys; sys.path.insert(0, '/mnt/agents/output')
import torch, random, json
import repro_grid3 as g

res = {}
res['n16_their_fmt_2k'] = g.run('N16', 37, False, steps=2000, B=64, seed=1)
json.dump(res, open('/mnt/agents/output/verify_n16_results.json', 'w'), ensure_ascii=False, indent=1)
print('DONE')
