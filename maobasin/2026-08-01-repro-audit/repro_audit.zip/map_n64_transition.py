# n64 their-format 10k：定位 64 IDs 真相变点，复验 n64_cot10k
import sys; sys.path.insert(0, '/mnt/agents/output')
import json, repro_grid3 as g
res = {'n64_their_fmt_10k': g.run('N64_10K', 37, False, steps=10000, B=64, seed=1)}
json.dump(res, open('/mnt/agents/output/n64_10k_results.json', 'w'), ensure_ascii=False, indent=1)
print('DONE')
