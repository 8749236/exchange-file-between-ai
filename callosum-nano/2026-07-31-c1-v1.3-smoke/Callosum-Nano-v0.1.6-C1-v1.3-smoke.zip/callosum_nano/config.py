from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Literal

from .budget import matched_dense_width

Variant = Literal[
    "narrow-dense",
    "wide-dense",
    "twin-no-comm",
    "twin-callosum",
]


@dataclass(frozen=True)
class ModelConfig:
    variant: Variant
    vocab_size: int = 256
    context_length: int = 128
    n_layers: int = 4
    n_heads: int = 3
    dense_heads: int | None = None
    branch_heads: int | None = None
    branch_width: int = 48
    dense_width_override: int | None = None
    wide_dense_width_override: int | None = None
    callosum_rank: int = 8
    interface_width: int = 64
    mlp_ratio: int = 4
    dropout: float = 0.0
    c1_heads: bool = False
    c1_answer_classes: int = 64

    @property
    def dense_width(self) -> int:
        if self.variant == "wide-dense":
            return self.wide_dense_width_override or 2 * self.branch_width
        return self.dense_width_override or matched_dense_width(
            self.branch_width,
            self.callosum_rank,
            self.mlp_ratio,
            communication=True,
        )

    @property
    def effective_dense_heads(self) -> int:
        return self.dense_heads or self.n_heads

    @property
    def effective_branch_heads(self) -> int:
        return self.branch_heads or self.n_heads

    def validate(self) -> None:
        if self.variant not in {
            "narrow-dense",
            "wide-dense",
            "twin-no-comm",
            "twin-callosum",
        }:
            raise ValueError(f"unknown variant: {self.variant}")
        if self.context_length < 2:
            raise ValueError("context_length must be at least 2")
        if self.n_layers < 1:
            raise ValueError("n_layers must be positive")
        if self.effective_dense_heads < 1 or self.effective_branch_heads < 1:
            raise ValueError("head counts must be positive")
        if (
            self.variant not in {"narrow-dense", "wide-dense"}
            and self.branch_width % self.effective_branch_heads
        ):
            raise ValueError(
                "branch_width must be divisible by effective_branch_heads"
            )
        if (
            self.variant in {"narrow-dense", "wide-dense"}
            and self.dense_width % self.effective_dense_heads
        ):
            raise ValueError(
                f"matched dense width {self.dense_width} must be divisible "
                f"by dense head count {self.effective_dense_heads}"
            )
        if not 0 <= self.dropout < 1:
            raise ValueError("dropout must be in [0, 1)")
        if self.callosum_rank < 1:
            raise ValueError("callosum_rank must be positive")
        if not 4 <= self.c1_answer_classes <= 64:
            raise ValueError("c1_answer_classes must be in [4, 64]")

    def to_dict(self) -> dict[str, object]:
        result = asdict(self)
        result["dense_width"] = self.dense_width
        result["effective_dense_heads"] = self.effective_dense_heads
        result["effective_branch_heads"] = self.effective_branch_heads
        return result


@dataclass(frozen=True)
class ExperimentConfig:
    steps: int = 2_000
    batch_size: int = 32
    learning_rate: float = 3e-4
    warmup_steps: int = 100
    lr_decay_steps: int | None = None
    min_lr_ratio: float = 0.1
    weight_decay: float = 0.1
    grad_clip: float = 1.0
    eval_interval: int = 100
    eval_batches: int = 20
    seed: int = 1
    device: str = "auto"
    synthetic_records: int = 20_000

    @property
    def effective_lr_decay_steps(self) -> int:
        return self.lr_decay_steps or self.steps

    @property
    def effective_warmup_steps(self) -> int:
        return min(
            self.warmup_steps,
            max(0, self.effective_lr_decay_steps - 1),
        )

    def validate(self) -> None:
        if self.steps < 1 or self.batch_size < 1:
            raise ValueError("steps and batch_size must be positive")
        if self.eval_interval < 1 or self.eval_batches < 1:
            raise ValueError("evaluation settings must be positive")
        if self.warmup_steps < 0:
            raise ValueError("warmup_steps cannot be negative")
        if self.effective_lr_decay_steps < 1:
            raise ValueError("lr_decay_steps must be positive")
        if not 0 <= self.min_lr_ratio <= 1:
            raise ValueError("min_lr_ratio must be in [0, 1]")

    def to_dict(self) -> dict[str, object]:
        result = asdict(self)
        result["effective_lr_decay_steps"] = self.effective_lr_decay_steps
        result["effective_warmup_steps"] = self.effective_warmup_steps
        return result
