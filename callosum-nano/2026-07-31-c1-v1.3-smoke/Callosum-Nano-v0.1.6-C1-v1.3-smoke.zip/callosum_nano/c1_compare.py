from __future__ import annotations

import argparse
import csv
import json
import math
import os
import random
import time
from contextlib import contextmanager
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import torch
import torch.nn.functional as F

from .c1_data import (
    C1Batch,
    C1Stream,
    C1_DATA_MODES,
    C1_FILLER_MODES,
    c1_context_length,
)
from .config import ModelConfig
from .model import TwinTransformer, build_model, count_parameters
from .train import (
    callosum_up_rms,
    learning_rate_at_step,
    resolve_device,
    save_json_line,
    seed_everything,
    set_learning_rate,
)
from .config import ExperimentConfig


ORACLE = "oracle-left"
C1_A = "c1-a-no-bridge"
C1_B = "c1-b-bridge"
C1_C = "c1-c-reconstruction-job"
CONDITIONS = (ORACLE, C1_A, C1_B, C1_C)
ORACLE_GATE_ACCURACY = 0.90
ORACLE_GATE_GIVEN4 = 0.90
ORACLE_GATE_CHAIN_EXACT = 0.90
ORACLE_GATE_SEEDS = 2
BRIDGE_PROBE_POSITIONS = {
    "filler": 60,
    "query_name": 62,
    "code": 63,
}


def assay_name(data_mode: str, id_count: int, filler_mode: str) -> str:
    if data_mode == "chain-two-hop":
        return "C1-v1.3-frozen"
    if data_mode == "two-hop":
        if id_count == 64:
            return "C1-v1.1-frozen"
        return f"C1-v1.2-calibration-id{id_count}-{filler_mode}-filler"
    return f"C1-oracle-diagnostic-{data_mode}"


@dataclass(frozen=True)
class C1TrainConfig:
    steps: int = 5_000
    batch_size: int = 32
    learning_rate: float = 3e-4
    warmup_steps: int = 100
    lr_decay_steps: int | None = None
    min_lr_ratio: float = 0.1
    weight_decay: float = 0.1
    grad_clip: float = 1.0
    eval_interval: int = 100
    validation_episodes: int = 4_096
    seed: int = 1
    device: str = "auto"
    job_lambda: float = 0.1
    ema_beta: float = 0.98
    data_mode: str = "chain-two-hop"
    full_lm_lambda: float = 1.0
    id_count: int = 64
    filler_mode: str = "random"
    probe_episodes: int = 0

    def experiment_config(self) -> ExperimentConfig:
        return ExperimentConfig(
            steps=self.steps,
            batch_size=self.batch_size,
            learning_rate=self.learning_rate,
            warmup_steps=self.warmup_steps,
            lr_decay_steps=self.lr_decay_steps,
            min_lr_ratio=self.min_lr_ratio,
            weight_decay=self.weight_decay,
            grad_clip=self.grad_clip,
            eval_interval=self.eval_interval,
            eval_batches=1,
            seed=self.seed,
            device=self.device,
        )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run the frozen Callosum Nano C1 two-hop assay"
    )
    parser.add_argument("--output", type=Path, default=Path("runs-c1"))
    parser.add_argument("--steps", type=int, default=5_000)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--eval-interval", type=int, default=100)
    parser.add_argument("--validation-episodes", type=int, default=4_096)
    parser.add_argument("--learning-rate", type=float, default=3e-4)
    parser.add_argument("--weight-decay", type=float, default=0.1)
    parser.add_argument("--grad-clip", type=float, default=1.0)
    parser.add_argument("--warmup-steps", type=int, default=100)
    parser.add_argument("--lr-decay-steps", type=int)
    parser.add_argument("--min-lr-ratio", type=float, default=0.1)
    parser.add_argument("--job-lambda", type=float, default=0.1)
    parser.add_argument("--ema-beta", type=float, default=0.98)
    parser.add_argument(
        "--data-mode", choices=C1_DATA_MODES, default="chain-two-hop"
    )
    parser.add_argument("--full-lm-lambda", type=float, default=1.0)
    parser.add_argument("--id-count", type=int, default=64)
    parser.add_argument(
        "--filler-mode", choices=C1_FILLER_MODES, default="random"
    )
    parser.add_argument(
        "--probe-episodes",
        type=int,
        default=0,
        help="fit deterministic bridge probes after B/C (0 disables)",
    )
    parser.add_argument("--device", default="auto")
    parser.add_argument("--seeds", type=int, nargs="+", default=[1])
    parser.add_argument(
        "--conditions", nargs="+", choices=CONDITIONS, default=[ORACLE]
    )
    parser.add_argument(
        "--oracle-approved",
        action="store_true",
        help="allow A/B/C only after the frozen two-seed Oracle gate passed",
    )
    parser.add_argument("--layers", type=int, default=4)
    parser.add_argument("--heads", type=int, default=3)
    parser.add_argument("--branch-width", type=int, default=48)
    parser.add_argument("--callosum-rank", type=int, default=8)
    parser.add_argument("--interface-width", type=int, default=64)
    parser.add_argument("--mlp-ratio", type=int, default=4)
    parser.add_argument("--dropout", type=float, default=0.0)
    parser.add_argument("--resume", action="store_true")
    return parser.parse_args()


def model_config_for(condition: str, args: argparse.Namespace) -> ModelConfig:
    variant = (
        "twin-callosum" if condition in {C1_B, C1_C} else "twin-no-comm"
    )
    return ModelConfig(
        variant=variant,
        context_length=c1_context_length(args.data_mode),
        n_layers=args.layers,
        n_heads=args.heads,
        branch_width=args.branch_width,
        callosum_rank=args.callosum_rank,
        interface_width=args.interface_width,
        mlp_ratio=args.mlp_ratio,
        dropout=args.dropout,
        c1_heads=True,
        c1_answer_classes=args.id_count,
    )


def parameter_accounting(model: TwinTransformer) -> dict[str, int]:
    groups = {
        "backbone": 0,
        "bridge": 0,
        "code_head": 0,
        "value_head": 0,
        "job_head": 0,
    }
    for name, parameter in model.named_parameters():
        count = parameter.numel()
        if ".bridge." in name:
            groups["bridge"] += count
        elif name.startswith("code_"):
            groups["code_head"] += count
        elif name.startswith("value_"):
            groups["value_head"] += count
        elif name.startswith("job_head"):
            groups["job_head"] += count
        else:
            groups["backbone"] += count
    groups["total"] = sum(groups.values())
    return groups


def condition_inputs(
    condition: str, batch: C1Batch
) -> tuple[torch.Tensor, torch.Tensor]:
    if condition == ORACLE:
        return batch.inputs, batch.right_inputs
    return batch.left_inputs, batch.right_inputs


def forward_condition(
    model: TwinTransformer,
    condition: str,
    batch: C1Batch,
    *,
    job_lambda: float = 0.1,
    full_lm_lambda: float = 1.0,
    return_answer_logits: bool = False,
):
    left_inputs, right_inputs = condition_inputs(condition, batch)
    return model.forward_c1(
        batch.inputs,
        batch.targets,
        left_tokens=left_inputs,
        right_tokens=right_inputs,
        answer_mask=batch.answer_mask,
        code_mask=batch.code_mask,
        value_mask=batch.value_mask,
        b_fact_mask=batch.b_fact_mask,
        use_bridge_job=condition == C1_C,
        job_lambda=job_lambda,
        full_lm_lambda=full_lm_lambda,
        return_answer_logits=return_answer_logits,
    )


@torch.no_grad()
def free_run_chain(
    model: TwinTransformer,
    condition: str,
    batch: C1Batch,
    *,
    collect_bridge_messages: bool = False,
) -> dict[str, object]:
    """Greedily emit code, write it back, then emit value.

    The true code/value suffix in ``batch`` is deliberately sliced away. This
    is the decisive v1.3 path; teacher-forced value accuracy is diagnostic only.
    """
    left_inputs, right_inputs = condition_inputs(condition, batch)
    query_prefix_length = 63  # facts/filler/Q/name, positions 0..62
    left_prefix = left_inputs[:, :query_prefix_length]
    right_prefix = right_inputs[:, :query_prefix_length]
    code_pass = model.c1_head_logits(
        left_tokens=left_prefix,
        right_tokens=right_prefix,
    )
    all_code_logits = code_pass["code_logits"]
    assert isinstance(all_code_logits, torch.Tensor)
    code_logits = all_code_logits[:, -1]
    predicted_code_ids = code_logits.argmax(dim=-1)
    predicted_code_tokens = 64 + predicted_code_ids

    shared_code = predicted_code_tokens[:, None]
    value_pass = model.c1_head_logits(
        left_tokens=torch.cat((left_prefix, shared_code), dim=1),
        right_tokens=torch.cat((right_prefix, shared_code), dim=1),
        collect_bridge_messages=collect_bridge_messages,
    )
    all_value_logits = value_pass["value_logits"]
    assert isinstance(all_value_logits, torch.Tensor)
    return {
        "code_logits": code_logits,
        "value_logits": all_value_logits[:, -1],
        "predicted_code_ids": predicted_code_ids,
        "predicted_code_tokens": predicted_code_tokens,
        "bridge_messages": value_pass["bridge_messages"],
    }


def _ridge_scores(
    train_features: torch.Tensor,
    train_targets: torch.Tensor,
    validation_features: torch.Tensor,
    *,
    ridge: float = 1e-3,
) -> torch.Tensor:
    """Fit a deterministic linear probe with an unregularized bias."""
    if train_features.ndim != 2 or validation_features.ndim != 2:
        raise ValueError("probe features must be matrices")
    if train_targets.ndim != 2:
        raise ValueError("probe targets must be a matrix")
    if train_features.shape[0] != train_targets.shape[0]:
        raise ValueError("probe feature/target row counts differ")
    dtype = torch.float64
    train = train_features.detach().to(device="cpu", dtype=dtype)
    validation = validation_features.detach().to(device="cpu", dtype=dtype)
    targets = train_targets.detach().to(device="cpu", dtype=dtype)
    train = torch.cat((train, torch.ones(train.shape[0], 1, dtype=dtype)), dim=1)
    validation = torch.cat(
        (validation, torch.ones(validation.shape[0], 1, dtype=dtype)), dim=1
    )
    penalty = torch.eye(train.shape[1], dtype=dtype) * ridge
    penalty[-1, -1] = 0.0
    weights = torch.linalg.solve(train.T @ train + penalty, train.T @ targets)
    return validation @ weights


@torch.no_grad()
def collect_bridge_probe_features(
    model: TwinTransformer,
    condition: str,
    *,
    seed: int,
    episodes: int,
    batch_size: int,
    device: torch.device,
    id_count: int,
    filler_mode: str,
) -> dict[str, object]:
    """Collect right→left messages at filler/query/code causal positions."""
    if condition not in {C1_B, C1_C}:
        raise ValueError("bridge probes require C1-B or C1-C")
    if episodes < 1:
        raise ValueError("probe episodes must be positive")
    stream = C1Stream(
        seed,
        device=device,
        data_mode="chain-two-hop",
        id_count=id_count,
        filler_mode=filler_mode,
    )
    feature_lists: dict[int, dict[str, list[torch.Tensor]]] = {}
    queried_codes: list[torch.Tensor] = []
    queried_values: list[torch.Tensor] = []
    all_values: list[torch.Tensor] = []
    completed = 0
    while completed < episodes:
        current = min(batch_size, episodes - completed)
        batch = stream.batch(current)
        free = free_run_chain(
            model,
            condition,
            batch,
            collect_bridge_messages=True,
        )
        messages = free["bridge_messages"]
        if not isinstance(messages, list) or not messages:
            raise RuntimeError("bridge messages are unavailable or disabled")
        for layer_index, message in enumerate(messages):
            per_position = feature_lists.setdefault(
                layer_index,
                {name: [] for name in BRIDGE_PROBE_POSITIONS},
            )
            to_left = message["to_left"]
            for name, position in BRIDGE_PROBE_POSITIONS.items():
                per_position[name].append(to_left[:, position].detach().cpu())
        queried_codes.append((batch.targets[batch.code_mask] - 64).cpu())
        queried_values.append((batch.targets[batch.value_mask] - 128).cpu())
        all_values.append(
            (batch.inputs[:, [14, 17, 20, 23]] - 128).cpu()
        )
        completed += current

    return {
        "features": {
            layer: {
                name: torch.cat(chunks, dim=0)
                for name, chunks in positions.items()
            }
            for layer, positions in feature_lists.items()
        },
        "queried_codes": torch.cat(queried_codes),
        "queried_values": torch.cat(queried_values),
        "all_values": torch.cat(all_values),
    }


def evaluate_bridge_probes(
    model: TwinTransformer,
    condition: str,
    *,
    seed: int,
    episodes: int,
    batch_size: int,
    device: torch.device,
    id_count: int,
    filler_mode: str,
) -> dict[str, object]:
    """Fit train-split ridge probes and score a disjoint fixed split."""
    was_training = model.training
    model.eval()
    train = collect_bridge_probe_features(
        model,
        condition,
        seed=20_000 + seed,
        episodes=episodes,
        batch_size=batch_size,
        device=device,
        id_count=id_count,
        filler_mode=filler_mode,
    )
    validation = collect_bridge_probe_features(
        model,
        condition,
        seed=30_000 + seed,
        episodes=episodes,
        batch_size=batch_size,
        device=device,
        id_count=id_count,
        filler_mode=filler_mode,
    )
    model.train(was_training)

    train_code = F.one_hot(
        train["queried_codes"], num_classes=id_count
    ).float()
    train_value = F.one_hot(
        train["queried_values"], num_classes=id_count
    ).float()
    train_all = torch.zeros(episodes, id_count)
    train_all.scatter_(1, train["all_values"], 1.0)
    validation_codes = validation["queried_codes"]
    validation_values = validation["queried_values"]
    validation_all = validation["all_values"]

    results: dict[str, object] = {}
    for layer, positions in train["features"].items():
        layer_results: dict[str, object] = {}
        for name, train_features in positions.items():
            validation_features = validation["features"][layer][name]
            code_scores = _ridge_scores(
                train_features, train_code, validation_features
            )
            value_scores = _ridge_scores(
                train_features, train_value, validation_features
            )
            all_scores = _ridge_scores(
                train_features, train_all, validation_features
            )
            top4 = all_scores.topk(4, dim=-1).indices
            matches = (
                top4[:, :, None] == validation_all[:, None, :]
            ).any(dim=-1)
            layer_results[name] = {
                "queried_code_acc": float(
                    (code_scores.argmax(dim=-1) == validation_codes)
                    .float()
                    .mean()
                    .item()
                ),
                "queried_value_acc": float(
                    (value_scores.argmax(dim=-1) == validation_values)
                    .float()
                    .mean()
                    .item()
                ),
                "all4_top4_recall": float(matches.float().mean().item()),
                "all4_exact_set_acc": float(
                    matches.all(dim=-1).float().mean().item()
                ),
            }
        results[f"layer_{layer}"] = layer_results
    return {
        "train_episodes": episodes,
        "validation_episodes": episodes,
        "positions": BRIDGE_PROBE_POSITIONS,
        "layers": results,
    }


@torch.no_grad()
def evaluate_c1(
    model: TwinTransformer,
    condition: str,
    *,
    seed: int,
    episodes: int,
    batch_size: int,
    device: torch.device,
    bridge_enabled: bool = True,
    job_lambda: float = 0.1,
    data_mode: str = "chain-two-hop",
    full_lm_lambda: float = 1.0,
    id_count: int = 64,
    filler_mode: str = "random",
) -> dict[str, float]:
    if episodes < 1:
        raise ValueError("validation_episodes must be positive")
    was_training = model.training
    model.eval()
    model.set_bridge_enabled(bridge_enabled)
    stream = C1Stream(
        10_000 + seed,
        device=device,
        data_mode=data_mode,
        id_count=id_count,
        filler_mode=filler_mode,
    )
    is_chain = data_mode == "chain-two-hop"
    value_nll_sum = 0.0
    value_tokens = 0
    value_correct = 0
    code_nll_sum = 0.0
    code_tokens = 0
    code_correct = 0
    chain_exact = 0
    teacher_value_nll_sum = 0.0
    teacher_value_correct = 0
    full_lm_sum = 0.0
    job_sum = 0.0
    job_batches = 0
    completed = 0
    given4_correct = 0
    top4_correct = 0
    top1_in_values = 0
    episode_value_mass = 0.0
    while completed < episodes:
        current = min(batch_size, episodes - completed)
        batch = stream.batch(current)
        output = forward_condition(
            model,
            condition,
            batch,
            job_lambda=job_lambda,
            full_lm_lambda=full_lm_lambda,
            return_answer_logits=True,
        )
        teacher_value_nll_sum += output.metrics["value_nll_sum"].item()
        teacher_value_correct += int(output.metrics["value_correct"].item())
        full_lm_sum += output.metrics["full_lm_loss"].item() * current
        if "bridge_job_ce" in output.metrics:
            job_sum += output.metrics["bridge_job_ce"].item() * current
            job_batches += current
        value_targets = batch.targets[batch.value_mask] - 128
        if is_chain:
            free = free_run_chain(model, condition, batch)
            code_logits = free["code_logits"]
            value_logits = free["value_logits"]
            assert isinstance(code_logits, torch.Tensor)
            assert isinstance(value_logits, torch.Tensor)
            code_targets = batch.targets[batch.code_mask] - 64
            code_losses = F.cross_entropy(
                code_logits, code_targets, reduction="none"
            )
            value_losses = F.cross_entropy(
                value_logits, value_targets, reduction="none"
            )
            code_predictions = code_logits.argmax(dim=-1)
            value_predictions = value_logits.argmax(dim=-1)
            code_hits = code_predictions == code_targets
            value_hits = value_predictions == value_targets
            code_nll_sum += code_losses.sum().item()
            code_tokens += code_targets.numel()
            code_correct += int(code_hits.sum().item())
            chain_exact += int((code_hits & value_hits).sum().item())
        else:
            value_logits = output.aux["value_logits"][batch.value_mask]
            value_losses = F.cross_entropy(
                value_logits, value_targets, reduction="none"
            )
            value_predictions = value_logits.argmax(dim=-1)

        value_nll_sum += value_losses.sum().item()
        value_tokens += value_targets.numel()
        value_correct += int(
            (value_predictions == value_targets).sum().item()
        )
        episode_values = batch.inputs[:, [14, 17, 20, 23]] - 128
        restricted = torch.full_like(value_logits, float("-inf"))
        restricted.scatter_(
            1,
            episode_values,
            value_logits.gather(1, episode_values),
        )
        given4_correct += int(
            (restricted.argmax(dim=-1) == value_targets).sum().item()
        )
        top_k = min(4, value_logits.shape[-1])
        top4_correct += int(
            (
                value_logits.topk(top_k, dim=-1).indices
                == value_targets[:, None]
            ).any(dim=-1).sum().item()
        )
        top1_in_values += int(
            (value_predictions[:, None] == episode_values)
            .any(dim=-1)
            .sum()
            .item()
        )
        episode_value_mass += float(
            value_logits.softmax(dim=-1)
            .gather(1, episode_values)
            .sum()
            .item()
        )
        completed += current
    model.set_bridge_enabled(True)
    model.train(was_training)
    result = {
        "answer_nll": value_nll_sum / value_tokens,
        "answer_acc": value_correct / value_tokens,
        "full_lm_loss": full_lm_sum / episodes,
        "answer_tokens": float(value_tokens),
        "given4_acc": given4_correct / value_tokens,
        "answer_top4_recall": top4_correct / value_tokens,
        "top1_is_episode_value": top1_in_values / value_tokens,
        "episode_value_probability_mass": episode_value_mass / value_tokens,
        "teacher_forced_value_nll": teacher_value_nll_sum / value_tokens,
        "teacher_forced_value_acc": teacher_value_correct / value_tokens,
    }
    if is_chain:
        result.update(
            {
                "free_code_nll": code_nll_sum / code_tokens,
                "free_code_acc": code_correct / code_tokens,
                "free_value_nll": value_nll_sum / value_tokens,
                "free_value_acc": value_correct / value_tokens,
                "free_v_given4_acc": given4_correct / value_tokens,
                "free_chain_exact_acc": chain_exact / value_tokens,
            }
        )
    if job_batches:
        result["bridge_job_ce"] = job_sum / job_batches
    return result


def truncate_jsonl(path: Path, maximum_step: int) -> None:
    if not path.exists():
        return
    retained: dict[int, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        value = json.loads(line)
        if int(value["step"]) <= maximum_step:
            retained[int(value["step"])] = json.dumps(value, sort_keys=True)
    path.write_text(
        "".join(retained[step] + "\n" for step in sorted(retained)),
        encoding="utf-8",
    )


def resume_signature(config: dict[str, Any]) -> dict[str, Any]:
    # The target step may be extended only when lr_decay_steps was explicitly
    # fixed. Device migration is safe; every optimization hyperparameter is not.
    return {
        key: value
        for key, value in config.items()
        if key not in {"steps", "device"}
    }


@contextmanager
def run_lock(path: Path):
    """Hold a non-blocking, cross-platform advisory lock for one run dir."""
    path.parent.mkdir(parents=True, exist_ok=True)
    handle = path.open("a+b")
    try:
        if os.name == "posix":
            import fcntl

            try:
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError as error:
                raise RuntimeError(f"run is already active: {path.parent}") from error
        else:  # pragma: no cover - Windows path
            import msvcrt

            try:
                handle.seek(0)
                if handle.read(1) == b"":
                    handle.write(b"0")
                    handle.flush()
                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            except OSError as error:
                raise RuntimeError(f"run is already active: {path.parent}") from error
        yield
    finally:
        handle.close()


def train_one_c1(
    condition: str,
    model_config: ModelConfig,
    train_config: C1TrainConfig,
    output_dir: Path,
    *,
    resume: bool = False,
) -> dict[str, Any]:
    if condition not in CONDITIONS:
        raise ValueError(f"unknown C1 condition: {condition}")
    model_config.validate()
    experiment = train_config.experiment_config()
    experiment.validate()
    seed_everything(train_config.seed)
    device = resolve_device(train_config.device)
    output_dir.mkdir(parents=True, exist_ok=True)

    built = build_model(model_config)
    if not isinstance(built, TwinTransformer):
        raise TypeError("C1 requires TwinTransformer")
    model = built.to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=train_config.learning_rate,
        weight_decay=train_config.weight_decay,
    )
    train_stream = C1Stream(
        train_config.seed,
        device=device,
        data_mode=train_config.data_mode,
        id_count=train_config.id_count,
        filler_mode=train_config.filler_mode,
    )
    metrics_path = output_dir / "metrics.jsonl"
    curve_path = output_dir / "train_curve.jsonl"
    latest_path = output_dir / "latest.pt"

    metadata = {
        "assay": assay_name(
            train_config.data_mode,
            train_config.id_count,
            train_config.filler_mode,
        ),
        "condition": condition,
        "model": model_config.to_dict(),
        "train": asdict(train_config),
        "device": str(device),
        "parameters": parameter_accounting(model),
        "chance_answer_nll": math.log(train_config.id_count),
        "chance_answer_acc": 1 / train_config.id_count,
        "fixed_validation": train_config.validation_episodes == 4_096,
    }
    (output_dir / "config.json").write_text(
        json.dumps(metadata, indent=2, sort_keys=True), encoding="utf-8"
    )

    best_nll = math.inf
    best_step = 0
    start_step = 0
    previous_elapsed = 0.0
    ema_nll: float | None = None
    ema_acc: float | None = None
    if resume and latest_path.exists():
        checkpoint = torch.load(
            latest_path, map_location=device, weights_only=False
        )
        if checkpoint["condition"] != condition:
            raise ValueError("resume condition does not match")
        if checkpoint["model_config"] != model_config.to_dict():
            raise ValueError("resume model configuration does not match")
        if resume_signature(checkpoint["train_config"]) != resume_signature(
            asdict(train_config)
        ):
            raise ValueError("resume training configuration does not match")
        if (
            checkpoint["train_config"]["lr_decay_steps"] is None
            and checkpoint["train_config"]["steps"] != train_config.steps
        ):
            raise ValueError(
                "cannot extend a run whose cosine decay was tied to its old steps"
            )
        model.load_state_dict(checkpoint["model_state"])
        optimizer.load_state_dict(checkpoint["optimizer_state"])
        train_stream.load_state_dict(checkpoint["train_stream_state"])
        random.setstate(checkpoint["python_random_state"])
        torch.set_rng_state(checkpoint["torch_random_state"])
        if torch.cuda.is_available() and checkpoint.get("cuda_random_state"):
            torch.cuda.set_rng_state_all(checkpoint["cuda_random_state"])
        start_step = checkpoint["step"]
        best_nll = checkpoint["best_answer_nll"]
        best_step = checkpoint["best_step"]
        previous_elapsed = checkpoint.get("elapsed_seconds", 0.0)
        ema_nll = checkpoint.get("ema_answer_nll")
        ema_acc = checkpoint.get("ema_answer_acc")
        truncate_jsonl(metrics_path, start_step)
        truncate_jsonl(curve_path, start_step)
    else:
        for path in (metrics_path, curve_path):
            if path.exists():
                path.unlink()

    started = time.perf_counter()
    model.train()
    for step in range(start_step + 1, train_config.steps + 1):
        learning_rate = learning_rate_at_step(step, experiment)
        set_learning_rate(optimizer, learning_rate)
        batch = train_stream.batch(train_config.batch_size)
        optimizer.zero_grad(set_to_none=True)
        output = forward_condition(
            model,
            condition,
            batch,
            job_lambda=train_config.job_lambda,
            full_lm_lambda=train_config.full_lm_lambda,
        )
        output.loss.backward()
        grad_norm = torch.nn.utils.clip_grad_norm_(
            model.parameters(), train_config.grad_clip
        )
        optimizer.step()

        train_nll = (
            output.metrics["answer_nll_sum"].item()
            / output.metrics["answer_tokens"].item()
        )
        train_acc = (
            output.metrics["answer_correct"].item()
            / output.metrics["answer_tokens"].item()
        )
        beta = train_config.ema_beta
        ema_nll = (
            train_nll
            if ema_nll is None
            else beta * ema_nll + (1 - beta) * train_nll
        )
        ema_acc = (
            train_acc
            if ema_acc is None
            else beta * ema_acc + (1 - beta) * train_acc
        )
        curve = {
            "step": step,
            "answer_nll": train_nll,
            "answer_acc": train_acc,
            "ema_answer_nll": ema_nll,
            "ema_answer_acc": ema_acc,
            "total_loss": output.loss.detach().item(),
            "full_lm_loss": output.metrics["full_lm_loss"].item(),
            "learning_rate": learning_rate,
        }
        if "code_tokens" in output.metrics:
            curve["code_nll"] = (
                output.metrics["code_nll_sum"].item()
                / output.metrics["code_tokens"].item()
            )
            curve["code_acc"] = (
                output.metrics["code_correct"].item()
                / output.metrics["code_tokens"].item()
            )
        if "bridge_job_ce" in output.metrics:
            curve["bridge_job_ce"] = output.metrics["bridge_job_ce"].item()
        save_json_line(curve_path, curve)

        should_eval = (
            step == 1
            or step % train_config.eval_interval == 0
            or step == train_config.steps
        )
        if not should_eval:
            continue

        validation = evaluate_c1(
            model,
            condition,
            seed=train_config.seed,
            episodes=train_config.validation_episodes,
            batch_size=train_config.batch_size,
            device=device,
            job_lambda=train_config.job_lambda,
            data_mode=train_config.data_mode,
            full_lm_lambda=train_config.full_lm_lambda,
            id_count=train_config.id_count,
            filler_mode=train_config.filler_mode,
        )
        elapsed = previous_elapsed + time.perf_counter() - started
        metric: dict[str, Any] = {
            "step": step,
            "validation": validation,
            "train_answer_nll": train_nll,
            "train_answer_acc": train_acc,
            "ema_answer_nll": ema_nll,
            "ema_answer_acc": ema_acc,
            "grad_norm": (
                grad_norm.detach().item()
                if isinstance(grad_norm, torch.Tensor)
                else float(grad_norm)
            ),
            "learning_rate": learning_rate,
            "elapsed_seconds": elapsed,
        }
        bridge_rms = callosum_up_rms(model)
        if bridge_rms is not None:
            metric["callosum_up_rms"] = bridge_rms
        if condition == C1_C:
            metric["bridge_zero_validation"] = evaluate_c1(
                model,
                condition,
                seed=train_config.seed,
                episodes=train_config.validation_episodes,
                batch_size=train_config.batch_size,
                device=device,
                bridge_enabled=False,
                job_lambda=train_config.job_lambda,
                data_mode=train_config.data_mode,
                full_lm_lambda=train_config.full_lm_lambda,
                id_count=train_config.id_count,
                filler_mode=train_config.filler_mode,
            )
        save_json_line(metrics_path, metric)
        if train_config.data_mode == "chain-two-hop":
            print(
                f"{condition} seed={train_config.seed} step={step:5d} "
                f"free_c={validation['free_code_acc']:.3f} "
                f"free_v={validation['free_value_acc']:.3f} "
                f"chain={validation['free_chain_exact_acc']:.3f} "
                f"given4={validation['free_v_given4_acc']:.3f} "
                f"lr={learning_rate:.3e}"
            )
        else:
            print(
                f"{condition} seed={train_config.seed} step={step:5d} "
                f"train_nll={train_nll:.4f} "
                f"val_nll={validation['answer_nll']:.4f} "
                f"val_acc={validation['answer_acc']:.3f} "
                f"given4={validation['given4_acc']:.3f} "
                f"lr={learning_rate:.3e}"
            )

        if validation["answer_nll"] < best_nll:
            best_nll = validation["answer_nll"]
            best_step = step
            torch.save(
                {
                    "model_state": model.state_dict(),
                    "model_config": model_config.to_dict(),
                    "train_config": asdict(train_config),
                    "condition": condition,
                    "step": step,
                    "validation": validation,
                },
                output_dir / "best.pt",
            )
        torch.save(
            {
                "model_state": model.state_dict(),
                "optimizer_state": optimizer.state_dict(),
                "model_config": model_config.to_dict(),
                "train_config": asdict(train_config),
                "condition": condition,
                "step": step,
                "best_answer_nll": best_nll,
                "best_step": best_step,
                "ema_answer_nll": ema_nll,
                "ema_answer_acc": ema_acc,
                "train_stream_state": train_stream.state_dict(),
                "python_random_state": random.getstate(),
                "torch_random_state": torch.get_rng_state(),
                "cuda_random_state": (
                    torch.cuda.get_rng_state_all()
                    if torch.cuda.is_available()
                    else None
                ),
                "elapsed_seconds": elapsed,
            },
            latest_path,
        )

    best_checkpoint = torch.load(
        output_dir / "best.pt", map_location=device, weights_only=False
    )
    model.load_state_dict(best_checkpoint["model_state"])
    best_validation = evaluate_c1(
        model,
        condition,
        seed=train_config.seed,
        episodes=train_config.validation_episodes,
        batch_size=train_config.batch_size,
        device=device,
        job_lambda=train_config.job_lambda,
        data_mode=train_config.data_mode,
        full_lm_lambda=train_config.full_lm_lambda,
        id_count=train_config.id_count,
        filler_mode=train_config.filler_mode,
    )
    result: dict[str, Any] = {
        **metadata,
        "best_step": best_step,
        "best_validation": best_validation,
        "elapsed_seconds": previous_elapsed + time.perf_counter() - started,
    }
    if condition == C1_C:
        result["best_bridge_zero_validation"] = evaluate_c1(
            model,
            condition,
            seed=train_config.seed,
            episodes=train_config.validation_episodes,
            batch_size=train_config.batch_size,
            device=device,
            bridge_enabled=False,
            job_lambda=train_config.job_lambda,
            data_mode=train_config.data_mode,
            full_lm_lambda=train_config.full_lm_lambda,
            id_count=train_config.id_count,
            filler_mode=train_config.filler_mode,
        )
    if condition in {C1_B, C1_C} and train_config.probe_episodes:
        result["bridge_probe"] = evaluate_bridge_probes(
            model,
            condition,
            seed=train_config.seed,
            episodes=train_config.probe_episodes,
            batch_size=train_config.batch_size,
            device=device,
            id_count=train_config.id_count,
            filler_mode=train_config.filler_mode,
        )
        (output_dir / "bridge_probe.json").write_text(
            json.dumps(result["bridge_probe"], indent=2, sort_keys=True),
            encoding="utf-8",
        )
    (output_dir / "result.json").write_text(
        json.dumps(result, indent=2, sort_keys=True), encoding="utf-8"
    )
    return result


def write_summary_csv(path: Path, results: list[dict[str, Any]]) -> None:
    fields = (
        "condition",
        "seed",
        "parameters",
        "best_step",
        "free_code_acc",
        "free_value_acc",
        "free_v_given4_acc",
        "free_chain_exact_acc",
        "answer_nll",
        "answer_acc",
        "given4_acc",
        "bridge_zero_free_code_acc",
        "bridge_zero_free_value_acc",
        "bridge_zero_free_chain_exact_acc",
        "bridge_zero_answer_nll",
        "bridge_zero_answer_acc",
        "elapsed_seconds",
    )
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for result in results:
            zero = result.get("best_bridge_zero_validation", {})
            writer.writerow(
                {
                    "condition": result["condition"],
                    "seed": result["train"]["seed"],
                    "parameters": result["parameters"]["total"],
                    "best_step": result["best_step"],
                    "free_code_acc": result["best_validation"].get(
                        "free_code_acc", ""
                    ),
                    "free_value_acc": result["best_validation"].get(
                        "free_value_acc", ""
                    ),
                    "free_v_given4_acc": result["best_validation"].get(
                        "free_v_given4_acc", ""
                    ),
                    "free_chain_exact_acc": result["best_validation"].get(
                        "free_chain_exact_acc", ""
                    ),
                    "answer_nll": result["best_validation"]["answer_nll"],
                    "answer_acc": result["best_validation"]["answer_acc"],
                    "given4_acc": result["best_validation"]["given4_acc"],
                    "bridge_zero_free_code_acc": zero.get(
                        "free_code_acc", ""
                    ),
                    "bridge_zero_free_value_acc": zero.get(
                        "free_value_acc", ""
                    ),
                    "bridge_zero_free_chain_exact_acc": zero.get(
                        "free_chain_exact_acc", ""
                    ),
                    "bridge_zero_answer_nll": zero.get("answer_nll", ""),
                    "bridge_zero_answer_acc": zero.get("answer_acc", ""),
                    "elapsed_seconds": result["elapsed_seconds"],
                }
            )


def main() -> None:
    args = parse_args()
    if args.probe_episodes < 0:
        raise ValueError("probe_episodes cannot be negative")
    diagnostic_modes = {
        "code-query-one-hop",
        "direct-name-value-one-hop",
    }
    if args.data_mode in diagnostic_modes and args.conditions != [ORACLE]:
        raise ValueError(
            "one-hop diagnostic modes require --conditions oracle-left"
        )
    if (
        args.data_mode == "chain-two-hop"
        and any(condition != ORACLE for condition in args.conditions)
        and not args.oracle_approved
    ):
        raise ValueError(
            "C1-v1.3 A/B/C are frozen until the two-seed Oracle gate passes; "
            "rerun with --oracle-approved only after recording that result"
        )
    if args.validation_episodes != 4_096:
        print(
            "NOTE: validation_episodes is not the frozen formal value 4096; "
            "this run is diagnostic only."
        )
    args.output.mkdir(parents=True, exist_ok=True)
    results: list[dict[str, Any]] = []
    for seed in args.seeds:
        for condition in args.conditions:
            train_config = C1TrainConfig(
                steps=args.steps,
                batch_size=args.batch_size,
                learning_rate=args.learning_rate,
                warmup_steps=args.warmup_steps,
                lr_decay_steps=args.lr_decay_steps,
                min_lr_ratio=args.min_lr_ratio,
                weight_decay=args.weight_decay,
                grad_clip=args.grad_clip,
                eval_interval=args.eval_interval,
                validation_episodes=args.validation_episodes,
                seed=seed,
                device=args.device,
                job_lambda=args.job_lambda,
                ema_beta=args.ema_beta,
                data_mode=args.data_mode,
                full_lm_lambda=args.full_lm_lambda,
                id_count=args.id_count,
                filler_mode=args.filler_mode,
                probe_episodes=args.probe_episodes,
            )
            run_dir = args.output / condition / f"seed-{seed}"
            with run_lock(run_dir / ".active.lock"):
                results.append(
                    train_one_c1(
                        condition,
                        model_config_for(condition, args),
                        train_config,
                        run_dir,
                        resume=args.resume,
                    )
                )

    oracle_results = [
        result for result in results if result["condition"] == ORACLE
    ]
    if args.data_mode == "chain-two-hop":
        oracle_gate = {
            "required_seeds": ORACLE_GATE_SEEDS,
            "free_code_accuracy_threshold": ORACLE_GATE_ACCURACY,
            "free_v_given4_accuracy_threshold": ORACLE_GATE_GIVEN4,
            "free_chain_exact_accuracy_threshold": ORACLE_GATE_CHAIN_EXACT,
            "passed": (
                len(oracle_results) >= ORACLE_GATE_SEEDS
                and all(
                    result["best_validation"]["free_code_acc"]
                    >= ORACLE_GATE_ACCURACY
                    and result["best_validation"]["free_v_given4_acc"]
                    >= ORACLE_GATE_GIVEN4
                    and result["best_validation"]["free_chain_exact_acc"]
                    >= ORACLE_GATE_CHAIN_EXACT
                    for result in oracle_results
                )
            ),
        }
    else:
        oracle_gate = {
            "required_seeds": ORACLE_GATE_SEEDS,
            "overall_accuracy_threshold": ORACLE_GATE_ACCURACY,
            "given4_accuracy_threshold": ORACLE_GATE_GIVEN4,
            "passed": (
                len(oracle_results) >= ORACLE_GATE_SEEDS
                and all(
                    result["best_validation"]["answer_acc"]
                    >= ORACLE_GATE_ACCURACY
                    and result["best_validation"]["given4_acc"]
                    >= ORACLE_GATE_GIVEN4
                    for result in oracle_results
                )
            ),
        }
    summary = {
        "assay": assay_name(args.data_mode, args.id_count, args.filler_mode),
        "chance": {
            "answer_nll": math.log(args.id_count),
            "answer_acc": 1 / args.id_count,
        },
        "oracle_gate": oracle_gate,
        "decision_rule": {
            "oracle": (
                "both seeds must pass free code, free given-4 value, and "
                "free chain-exact 90% gates"
            ),
            "c1_a": (
                "free code must pass 90% while free value remains at chance"
            ),
            "key_comparison": "C1-C answer_nll < C1-B answer_nll",
            "necessity": (
                "C1-C-zero must selectively regress value while preserving code"
            ),
            "best_checkpoint": "minimum fixed-validation free value NLL",
        },
        "results": results,
    }
    (args.output / "summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True), encoding="utf-8"
    )
    write_summary_csv(args.output / "summary.csv", results)
    compact = {
        f"{result['condition']}/seed-{result['train']['seed']}": {
            "best_step": result["best_step"],
            **result["best_validation"],
        }
        for result in results
    }
    print(json.dumps(compact, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
