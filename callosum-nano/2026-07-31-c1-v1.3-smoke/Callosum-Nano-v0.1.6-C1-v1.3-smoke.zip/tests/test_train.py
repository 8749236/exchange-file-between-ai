from dataclasses import replace

import torch

from callosum_nano.config import ExperimentConfig, ModelConfig
from callosum_nano.data import make_synthetic_corpus
from callosum_nano.train import learning_rate_at_step, train_one


def tiny_model() -> ModelConfig:
    return ModelConfig(
        variant="twin-callosum",
        context_length=8,
        n_layers=1,
        n_heads=1,
        branch_width=4,
        callosum_rank=2,
        interface_width=4,
        mlp_ratio=2,
    )


def tiny_experiment(steps: int) -> ExperimentConfig:
    return ExperimentConfig(
        steps=steps,
        batch_size=2,
        learning_rate=1e-3,
        warmup_steps=1,
        lr_decay_steps=4,
        min_lr_ratio=0.1,
        eval_interval=2,
        eval_batches=1,
        seed=5,
        device="cpu",
        synthetic_records=100,
    )


def test_warmup_and_cosine_schedule() -> None:
    experiment = tiny_experiment(steps=4)
    assert learning_rate_at_step(1, experiment) == 1e-3
    assert 1e-4 < learning_rate_at_step(2, experiment) < 1e-3
    assert learning_rate_at_step(4, experiment) == 1e-4


def test_resume_matches_uninterrupted_training(tmp_path) -> None:
    train_bytes = make_synthetic_corpus(100, seed=11)
    valid_bytes = make_synthetic_corpus(30, seed=12)
    model_config = tiny_model()

    full_dir = tmp_path / "full"
    resumed_dir = tmp_path / "resumed"
    train_one(
        model_config,
        tiny_experiment(steps=4),
        train_bytes,
        valid_bytes,
        full_dir,
    )
    train_one(
        model_config,
        tiny_experiment(steps=2),
        train_bytes,
        valid_bytes,
        resumed_dir,
    )
    train_one(
        model_config,
        replace(tiny_experiment(steps=4), steps=4),
        train_bytes,
        valid_bytes,
        resumed_dir,
        resume=True,
    )

    full = torch.load(full_dir / "latest.pt", weights_only=False)
    resumed = torch.load(resumed_dir / "latest.pt", weights_only=False)
    assert full["step"] == resumed["step"] == 4
    for name, parameter in full["model_state"].items():
        torch.testing.assert_close(parameter, resumed["model_state"][name])

