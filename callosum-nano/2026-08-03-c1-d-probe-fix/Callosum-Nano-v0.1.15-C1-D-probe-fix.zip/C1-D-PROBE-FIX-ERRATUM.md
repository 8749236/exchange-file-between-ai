# C1-D v0.1.15 probe 修复勘误

v0.1.14 正式脚本在 D0 seed 1 完成 10,000 步后进入 probe 阶段崩溃。调用方已把
D0/D 纳入 probe 条件，但 `collect_bridge_probe_features` 的内部 guard 仍只允许
C1-B/C。猫盆按 `set -euo pipefail` 正确熔断，没有改源码或继续混炉。

v0.1.15 只做以下科学中性的缺陷修复：

1. collector guard 接受 D0/D；
2. 新增回归测试，真实执行 D0 与 D 的 8+8 episode、两层消息采集与 ridge probe；
3. 测试总数由 48 增至 49。

模型、初始化顺序、训练数据、loss、10k 窗口、判读门和正式命令均未改变。正式炉从
全新输出目录重开，不续用崩溃现场。

校准与猫盆 D0 seed 1 轨迹不一致不能归为 validation 配置：训练流与验证流相互独立。
已知执行栈不同（本地 torch 2.13.0+cpu；猫盆 torch 2.8.0+cu128 CPU，并限制
OMP/MKL 线程），seed 不承诺跨 PyTorch/线程归约路径同轨。D0 的分岔敏感性因此保留
为诊断观察；正式结论只依据同一猫盆环境内 paired D0/D。
