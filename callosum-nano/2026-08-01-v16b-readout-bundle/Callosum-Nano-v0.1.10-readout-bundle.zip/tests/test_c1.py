import math
import json
from dataclasses import replace

import pytest
import torch

from callosum_nano.c1_data import (
    C1_A_MARK,
    C1_B_MARK,
    C1_CHAIN_CONTEXT_LENGTH,
    C1_MASK,
    C1_Q_MARK,
    C1Stream,
)
from callosum_nano.config import ModelConfig
from callosum_nano.model import build_model
from callosum_nano.c1_compare import (
    C1_A,
    C1_B,
    ORACLE,
    C1TrainConfig,
    _ridge_scores,
    evaluate_c1,
    free_run_chain,
    train_one_c1,
    truncate_jsonl,
    audit_jsonl_steps,
)


def c1_config(
    variant: str = "twin-callosum",
    answer_classes: int = 64,
    context_length: int = 64,
    head_style: str = "separate-rms",
) -> ModelConfig:
    return ModelConfig(
        variant=variant,
        context_length=context_length,
        n_layers=2,
        n_heads=1,
        branch_width=8,
        callosum_rank=2,
        interface_width=8,
        mlp_ratio=2,
        c1_heads=True,
        c1_answer_classes=answer_classes,
        c1_head_style=head_style,
    )


def test_c1_stream_has_complementary_views_and_no_job_shortcut() -> None:
    batch = C1Stream(7).batch(32)
    assert batch.inputs.shape == (32, 64)
    assert (batch.left_inputs[:, 12:24] == C1_MASK).all()
    assert not (batch.left_inputs == C1_B_MARK).any()
    assert (batch.right_inputs[:, :12] == C1_MASK).all()
    assert not (batch.right_inputs == C1_A_MARK).any()
    assert batch.answer_mask.sum().item() == 32
    assert (batch.answer_mask.sum(dim=1) == 1).all()
    answers = batch.targets[batch.answer_mask]
    assert ((128 <= answers) & (answers < 192)).all()
    assert batch.b_fact_mask.sum().item() == 32 * 8
    assert not batch.b_fact_mask[:, [12, 15, 18, 21]].any()
    assert (batch.inputs[batch.b_fact_mask] != C1_B_MARK).all()
    # No value byte is visible to the left before the answer position.
    visible_prefix = batch.left_inputs[:, :63]
    assert not ((128 <= visible_prefix) & (visible_prefix < 192)).any()


def test_c1_stream_resume_is_exact() -> None:
    stream = C1Stream(11)
    stream.batch(3)
    state = stream.state_dict()
    expected = stream.batch(5)
    resumed = C1Stream(999)
    resumed.load_state_dict(state)
    actual = resumed.batch(5)
    for name in vars(expected):
        torch.testing.assert_close(getattr(expected, name), getattr(actual, name))


def test_c1_one_hop_diagnostic_modes_preserve_the_answer() -> None:
    code_query = C1Stream(13, data_mode="code-query-one-hop").batch(16)
    queried_codes = code_query.inputs[:, 62]
    b_codes = code_query.inputs[:, [13, 16, 19, 22]]
    assert (queried_codes[:, None] == b_codes).any(dim=1).all()

    direct = C1Stream(13, data_mode="direct-name-value-one-hop").batch(16)
    a_values = direct.inputs[:, [2, 5, 8, 11]]
    answers = direct.targets[direct.answer_mask]
    assert (answers[:, None] == a_values).any(dim=1).all()


def test_c1_id16_calibration_reduces_only_symbol_pool_and_answer_head() -> None:
    batch = C1Stream(17, id_count=16).batch(32)
    assert batch.inputs[:, [1, 4, 7, 10, 62]].max().item() < 16
    assert batch.inputs[:, [2, 5, 8, 11]].max().item() < 80
    assert batch.inputs[:, [14, 17, 20, 23]].max().item() < 144
    assert batch.inputs[:, 24:61].min().item() >= 192
    assert batch.inputs[:, 24:61].max().item() < 240

    model = build_model(c1_config(answer_classes=16))
    output = model.forward_c1(
        batch.inputs,
        batch.targets,
        left_tokens=batch.inputs,
        right_tokens=batch.right_inputs,
        answer_mask=batch.answer_mask,
        b_fact_mask=batch.b_fact_mask,
        return_answer_logits=True,
    )
    assert output.aux["answer_logits"].shape == (32, 64, 16)


def test_c1_constant_filler_removes_entropy_without_moving_query() -> None:
    random_batch = C1Stream(41, id_count=16).batch(8)
    constant_batch = C1Stream(
        41, id_count=16, filler_mode="constant"
    ).batch(8)
    torch.testing.assert_close(
        random_batch.inputs[:, :24], constant_batch.inputs[:, :24]
    )
    torch.testing.assert_close(
        random_batch.inputs[:, 61:], constant_batch.inputs[:, 61:]
    )
    assert (constant_batch.inputs[:, 24:61] == 239).all()
    assert not torch.equal(
        random_batch.inputs[:, 24:61], constant_batch.inputs[:, 24:61]
    )


def test_c1_v13_chain_appends_code_and_value_without_moving_query() -> None:
    legacy = C1Stream(43, id_count=16, data_mode="two-hop").batch(16)
    chain = C1Stream(43, id_count=16, data_mode="chain-two-hop").batch(16)
    assert chain.inputs.shape == (16, C1_CHAIN_CONTEXT_LENGTH)
    torch.testing.assert_close(chain.inputs[:, :63], legacy.inputs[:, :63])
    assert (chain.inputs[:, 61] == C1_Q_MARK).all()
    assert (chain.code_mask.sum(dim=1) == 1).all()
    assert (chain.value_mask.sum(dim=1) == 1).all()
    assert chain.code_mask[:, 62].all()
    assert chain.value_mask[:, 63].all()
    codes = chain.targets[chain.code_mask]
    values = chain.targets[chain.value_mask]
    assert ((64 <= codes) & (codes < 80)).all()
    assert ((128 <= values) & (values < 144)).all()
    torch.testing.assert_close(chain.answer_mask, chain.value_mask)
    # The teacher-forced code is public to both streams; the future value is
    # not present at or before the value-decision position.
    torch.testing.assert_close(
        chain.left_inputs[:, 63], chain.right_inputs[:, 63]
    )
    visible_left = chain.left_inputs[:, :64]
    assert not ((128 <= visible_left) & (visible_left < 192)).any()


def test_c1_v13_has_distinct_left_only_code_and_value_heads() -> None:
    torch.manual_seed(47)
    batch = C1Stream(47, id_count=16, data_mode="chain-two-hop").batch(8)
    model = build_model(c1_config(answer_classes=16, context_length=65))
    output = model.forward_c1(
        batch.inputs,
        batch.targets,
        left_tokens=batch.inputs,
        right_tokens=batch.right_inputs,
        code_mask=batch.code_mask,
        value_mask=batch.value_mask,
        b_fact_mask=batch.b_fact_mask,
        return_answer_logits=True,
    )
    assert output.aux["code_logits"].shape == (8, 65, 16)
    assert output.aux["value_logits"].shape == (8, 65, 16)
    assert "code_nll_sum" in output.metrics
    assert "value_nll_sum" in output.metrics
    assert abs(output.metrics["code_nll_sum"].item() / 8 - math.log(16)) < 0.5
    assert abs(output.metrics["value_nll_sum"].item() / 8 - math.log(16)) < 0.5


def test_c1_shared_vocab_plain_head_slices_legal_rows() -> None:
    torch.manual_seed(49)
    batch = C1Stream(49, id_count=16, data_mode="chain-two-hop").batch(8)
    model = build_model(
        c1_config(
            answer_classes=16,
            context_length=65,
            head_style="shared-vocab-plain",
        )
    )
    head_output = model.c1_head_logits(
        left_tokens=batch.inputs,
        right_tokens=batch.right_inputs,
    )
    left = head_output["left_state"]
    shared = model.c1_shared_head(left)
    torch.testing.assert_close(
        head_output["code_logits"], shared[..., 64:80]
    )
    torch.testing.assert_close(
        head_output["value_logits"], shared[..., 128:144]
    )
    assert model.c1_shared_head.bias is not None
    assert not hasattr(model, "code_norm")
    assert not hasattr(model, "value_norm")


def test_sliced_vocab_head_has_same_opponent_set_as_separate_linear() -> None:
    torch.manual_seed(51)
    state = torch.randn(3, 5, 8)
    shared = torch.nn.Linear(8, 256, bias=True)
    separate = torch.nn.Linear(8, 16, bias=True)
    with torch.no_grad():
        separate.weight.copy_(shared.weight[64:80])
        separate.bias.copy_(shared.bias[64:80])
    torch.testing.assert_close(shared(state)[..., 64:80], separate(state))
    targets = torch.randint(0, 16, (3, 5))
    torch.testing.assert_close(
        torch.nn.functional.cross_entropy(
            shared(state)[..., 64:80].reshape(-1, 16), targets.reshape(-1)
        ),
        torch.nn.functional.cross_entropy(
            separate(state).reshape(-1, 16), targets.reshape(-1)
        ),
    )


def test_c1_v13_free_run_slices_away_true_code_and_value() -> None:
    torch.manual_seed(53)
    batch = C1Stream(53, id_count=16, data_mode="chain-two-hop").batch(8)
    model = build_model(
        c1_config("twin-no-comm", answer_classes=16, context_length=65)
    ).eval()
    original = free_run_chain(model, ORACLE, batch)
    batch.inputs[:, 63] = 64 + torch.arange(8) % 16
    batch.inputs[:, 64] = 128 + torch.arange(8) % 16
    batch.left_inputs[:, 63:] = batch.inputs[:, 63:]
    batch.right_inputs[:, 63:] = batch.inputs[:, 63:]
    changed = free_run_chain(model, ORACLE, batch)
    torch.testing.assert_close(original["code_logits"], changed["code_logits"])
    torch.testing.assert_close(original["value_logits"], changed["value_logits"])
    predicted = original["predicted_code_tokens"]
    assert ((64 <= predicted) & (predicted < 80)).all()


def test_c1_v13_bridge_messages_cover_filler_query_and_code_positions() -> None:
    torch.manual_seed(59)
    batch = C1Stream(59, id_count=16, data_mode="chain-two-hop").batch(4)
    model = build_model(c1_config(answer_classes=16, context_length=65)).eval()
    bridge = model.layers[0].bridge
    assert bridge is not None
    with torch.no_grad():
        bridge.right_to_left.up.weight.normal_(0, 0.01)
    free = free_run_chain(
        model, C1_B, batch, collect_bridge_messages=True
    )
    messages = free["bridge_messages"]
    assert len(messages) == 2
    for layer_message in messages:
        to_left = layer_message["to_left"]
        assert to_left.shape[:2] == (4, 64)
        assert to_left[:, 60].shape == to_left[:, 62].shape
        assert to_left[:, 62].shape == to_left[:, 63].shape


def test_c1_v13_ridge_probe_uses_a_disjoint_validation_matrix() -> None:
    features = torch.eye(4).repeat(8, 1)
    targets = torch.eye(4).repeat(8, 1)
    validation = torch.eye(4)
    scores = _ridge_scores(features, targets, validation)
    assert scores.shape == (4, 4)
    torch.testing.assert_close(scores.argmax(dim=-1), torch.arange(4))


@pytest.mark.parametrize(
    "head_style", ["separate-rms", "shared-vocab-plain"]
)
def test_c1_heads_and_common_weights_are_paired(head_style: str) -> None:
    torch.manual_seed(19)
    no_comm = build_model(
        c1_config("twin-no-comm", head_style=head_style)
    )
    torch.manual_seed(19)
    callosum = build_model(
        c1_config("twin-callosum", head_style=head_style)
    )
    callosum_parameters = dict(callosum.named_parameters())
    for name, parameter in no_comm.named_parameters():
        torch.testing.assert_close(parameter, callosum_parameters[name])


def test_c1_bridge_switch_causality_and_job_gradient() -> None:
    torch.manual_seed(23)
    model = build_model(c1_config()).eval()
    batch = C1Stream(3).batch(4)
    kwargs = dict(
        left_tokens=batch.left_inputs,
        right_tokens=batch.right_inputs,
        answer_mask=batch.answer_mask,
        b_fact_mask=batch.b_fact_mask,
    )

    model.set_bridge_enabled(False)
    closed = model.forward_c1(batch.inputs, batch.targets, **kwargs)
    model.set_bridge_enabled(True)
    zero_open = model.forward_c1(batch.inputs, batch.targets, **kwargs)
    torch.testing.assert_close(closed.logits, zero_open.logits)

    bridge = model.layers[0].bridge
    assert bridge is not None
    with torch.no_grad():
        bridge.right_to_left.up.weight.normal_(0, 0.01)
    changed = model.forward_c1(batch.inputs, batch.targets, **kwargs)
    assert not torch.allclose(closed.logits, changed.logits)
    model.set_bridge_enabled(False)
    reclosed = model.forward_c1(batch.inputs, batch.targets, **kwargs)
    torch.testing.assert_close(closed.logits, reclosed.logits)

    model.set_bridge_enabled(True)
    model.zero_grad(set_to_none=True)
    output = model.forward_c1(
        batch.inputs,
        batch.targets,
        use_bridge_job=True,
        **kwargs,
    )
    output.loss.backward()
    up_gradient = bridge.right_to_left.up.weight.grad
    down_gradient = bridge.right_to_left.down.weight.grad
    assert up_gradient is not None and up_gradient.abs().sum() > 0
    assert down_gradient is not None and down_gradient.abs().sum() > 0


def test_c1_answer_is_causal_and_uses_64_class_chance_floor() -> None:
    torch.manual_seed(29)
    model = build_model(c1_config()).eval()
    batch = C1Stream(5).batch(8)
    changed_left = batch.left_inputs.clone()
    changed_right = batch.right_inputs.clone()
    changed_left[:, 63] = torch.randint(128, 192, (8,))
    changed_right[:, 63] = torch.randint(128, 192, (8,))
    kwargs = dict(
        answer_mask=batch.answer_mask,
        b_fact_mask=batch.b_fact_mask,
        collect_bridge_messages=True,
    )
    with torch.no_grad():
        original = model.forward_c1(
            batch.inputs,
            batch.targets,
            left_tokens=batch.left_inputs,
            right_tokens=batch.right_inputs,
            **kwargs,
        )
        changed = model.forward_c1(
            batch.inputs,
            batch.targets,
            left_tokens=changed_left,
            right_tokens=changed_right,
            **kwargs,
        )
    original_answer = original.aux["answer_logits"][batch.answer_mask]
    changed_answer = changed.aux["answer_logits"][batch.answer_mask]
    torch.testing.assert_close(original_answer, changed_answer)
    assert original_answer.shape[-1] == 64
    initial_nll = original.metrics["answer_nll_sum"] / 8
    assert abs(initial_nll.item() - math.log(64)) < 0.5


def test_c1_fixed_validation_repeats_exactly() -> None:
    torch.manual_seed(31)
    model = build_model(c1_config("twin-no-comm"))
    first = evaluate_c1(
        model,
        C1_A,
        seed=2,
        episodes=17,
        batch_size=8,
        device=torch.device("cpu"),
        data_mode="two-hop",
    )
    second = evaluate_c1(
        model,
        C1_A,
        seed=2,
        episodes=17,
        batch_size=8,
        device=torch.device("cpu"),
        data_mode="two-hop",
    )
    assert first == second


def test_c1_v13_fixed_validation_reports_free_and_teacher_metrics() -> None:
    torch.manual_seed(61)
    model = build_model(
        c1_config("twin-no-comm", answer_classes=16, context_length=65)
    )
    result = evaluate_c1(
        model,
        ORACLE,
        seed=3,
        episodes=17,
        batch_size=8,
        device=torch.device("cpu"),
        data_mode="chain-two-hop",
        id_count=16,
    )
    assert result["answer_nll"] == result["free_value_nll"]
    assert result["answer_acc"] == result["free_value_acc"]
    assert result["given4_acc"] == result["free_v_given4_acc"]
    assert 0.0 <= result["free_chain_exact_acc"] <= 1.0
    assert "teacher_forced_value_acc" in result


def test_c1_resume_matches_uninterrupted_training(tmp_path) -> None:
    model_config = c1_config("twin-no-comm")
    base = C1TrainConfig(
        steps=4,
        batch_size=2,
        learning_rate=1e-3,
        warmup_steps=1,
        lr_decay_steps=4,
        min_lr_ratio=0.1,
        eval_interval=2,
        validation_episodes=4,
        seed=37,
        device="cpu",
        data_mode="two-hop",
    )
    full_dir = tmp_path / "full"
    resumed_dir = tmp_path / "resumed"
    train_one_c1(C1_A, model_config, base, full_dir)
    train_one_c1(C1_A, model_config, replace(base, steps=2), resumed_dir)
    train_one_c1(C1_A, model_config, base, resumed_dir, resume=True)

    full = torch.load(full_dir / "latest.pt", weights_only=False)
    resumed = torch.load(resumed_dir / "latest.pt", weights_only=False)
    assert full["step"] == resumed["step"] == 4
    for name, parameter in full["model_state"].items():
        torch.testing.assert_close(parameter, resumed["model_state"][name])


def test_c1_resume_skips_malformed_jsonl_records(tmp_path) -> None:
    path = tmp_path / "curve.jsonl"
    path.write_text(
        '{"step": 1, "ok": true}\n}\n'
        '{"step": 2, "ok": true}\n117}\n'
        '{"step": 3, "ok": true}\n',
        encoding="utf-8",
    )
    with pytest.warns(RuntimeWarning, match="2 malformed"):
        truncate_jsonl(path, 2)
    records = [json.loads(line) for line in path.read_text().splitlines()]
    assert [record["step"] for record in records] == [1, 2]


def test_c1_jsonl_audit_rejects_sparse_nul_holes(tmp_path) -> None:
    path = tmp_path / "curve.jsonl"
    path.write_bytes(b'{"step": 1}\n\x00\x00{"step": 2}\n')
    with pytest.raises(RuntimeError, match="NUL hole"):
        audit_jsonl_steps(path, {1, 2})
