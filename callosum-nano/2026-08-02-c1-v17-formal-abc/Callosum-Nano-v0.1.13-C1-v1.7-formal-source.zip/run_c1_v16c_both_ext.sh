#!/usr/bin/env bash
set -euo pipefail

source_root="${1:-runs-c1-v1.6c-model-ladder}"
output_root="${2:-runs-c1-v1.6c-both-ext}"
device="${3:-cpu}"

if [[ ! -d "$source_root/BOTH/oracle-left" ]]; then
  echo "missing v1.6c BOTH source: $source_root/BOTH/oracle-left" >&2
  exit 2
fi
if [[ -e "$output_root" ]]; then
  echo "refusing to overwrite output: $output_root" >&2
  exit 2
fi

python - "$source_root" <<'PY'
import json
import pathlib
import sys

root = pathlib.Path(sys.argv[1]) / "BOTH" / "oracle-left"
expected_model = {
    "variant": "twin-no-comm",
    "n_layers": 2,
    "n_heads": 2,
    "branch_width": 64,
    "interface_width": 64,
    "position_encoding": "learned",
    "c1_answer_classes": 16,
    "c1_head_style": "shared-vocab-plain",
    "c1_block_style": "torch-post-ln",
    "c1_input_style": "direct-default",
}
expected_train = {
    "steps": 4000,
    "batch_size": 64,
    "learning_rate": 0.003,
    "warmup_steps": 1,
    "lr_decay_steps": 4000,
    "min_lr_ratio": 1.0,
    "weight_decay": 0.0,
    "grad_clip": 1.0,
    "eval_interval": 200,
    "validation_episodes": 1024,
    "data_mode": "chain-two-hop",
    "filler_mode": "random",
    "full_lm_lambda": 0.0,
    "id_count": 16,
}
for seed in (1, 2):
    run = root / f"seed-{seed}"
    for name in ("config.json", "latest.pt", "metrics.jsonl", "train_curve.jsonl", "logging_audit.json"):
        if not (run / name).is_file():
            raise SystemExit(f"missing source artifact: {run / name}")
    config = json.loads((run / "config.json").read_text(encoding="utf-8"))
    if config.get("condition") != "oracle-left":
        raise SystemExit(f"seed {seed}: source condition mismatch")
    if config.get("train", {}).get("seed") != seed:
        raise SystemExit(f"seed {seed}: source seed mismatch")
    for key, value in expected_model.items():
        if config.get("model", {}).get(key) != value:
            raise SystemExit(f"seed {seed}: model {key} mismatch")
    for key, value in expected_train.items():
        if config.get("train", {}).get(key) != value:
            raise SystemExit(f"seed {seed}: train {key} mismatch")
    audit = json.loads((run / "logging_audit.json").read_text(encoding="utf-8"))
    curve = audit.get("train_curve", {})
    metrics = audit.get("metrics", {})
    if not (
        curve.get("first_step") == 1
        and curve.get("last_step") == 4000
        and curve.get("records") == 4000
        and metrics.get("first_step") == 1
        and metrics.get("last_step") == 4000
        and metrics.get("records") == 21
    ):
        raise SystemExit(f"seed {seed}: source logging range mismatch")
    for ledger in (curve, metrics):
        if any(ledger.get(key) != 0 for key in (
            "missing_required_new_steps", "malformed_records", "nul_holes"
        )):
            raise SystemExit(f"seed {seed}: source logging audit is not green")
print("source JSON/audit preflight OK")
PY

python -m pytest -q

mkdir -p "$output_root/BOTH/oracle-left"
for seed in 1 2; do
  cp -a \
    "$source_root/BOTH/oracle-left/seed-$seed" \
    "$output_root/BOTH/oracle-left/seed-$seed"
done

python - "$output_root" <<'PY'
import pathlib
import sys
import torch

root = pathlib.Path(sys.argv[1]) / "BOTH" / "oracle-left"
for seed in (1, 2):
    checkpoint = torch.load(
        root / f"seed-{seed}" / "latest.pt",
        map_location="cpu",
        weights_only=False,
    )
    if checkpoint.get("step") != 4000:
        raise SystemExit(f"seed {seed}: checkpoint is not at step 4000")
    if checkpoint.get("condition") != "oracle-left":
        raise SystemExit(f"seed {seed}: checkpoint condition mismatch")
print("checkpoint preflight OK")
PY

python -m callosum_nano.c1_compare \
  --output "$output_root/BOTH" \
  --assay-label C1-v1.6c-BOTH-EXT \
  --steps 8000 \
  --batch-size 64 \
  --eval-interval 200 \
  --validation-episodes 1024 \
  --learning-rate 3e-3 \
  --warmup-steps 1 \
  --lr-decay-steps 4000 \
  --min-lr-ratio 1.0 \
  --weight-decay 0 \
  --grad-clip 1.0 \
  --full-lm-lambda 0.0 \
  --data-mode chain-two-hop \
  --filler-mode random \
  --id-count 16 \
  --layers 2 \
  --heads 2 \
  --branch-width 64 \
  --interface-width 64 \
  --position-encoding learned \
  --c1-head-style shared-vocab-plain \
  --c1-block-style torch-post-ln \
  --c1-input-style direct-default \
  --seeds 1 2 \
  --conditions oracle-left \
  --device "$device" \
  --resume

python - "$output_root" <<'PY'
import json
import pathlib
import sys

root = pathlib.Path(sys.argv[1])
summary = json.loads((root / "BOTH" / "summary.json").read_text(encoding="utf-8"))
rows = []
for result in summary["results"]:
    seed = result["train"]["seed"]
    endpoint = result["endpoint_validation"]
    metrics_path = root / "BOTH" / "oracle-left" / f"seed-{seed}" / "metrics.jsonl"
    metrics = [json.loads(line) for line in metrics_path.read_text(encoding="utf-8").splitlines() if line]
    first_crossing = {}
    for label, key in (
        ("code", "free_code_acc"),
        ("given4_value", "free_v_given4_acc"),
        ("chain", "free_chain_exact_acc"),
    ):
        first_crossing[label] = next(
            (record["step"] for record in metrics if record["validation"][key] >= 0.90),
            None,
        )
    passed = all(
        endpoint[key] >= 0.90
        for key in ("free_code_acc", "free_v_given4_acc", "free_chain_exact_acc")
    )
    rows.append({
        "seed": seed,
        "endpoint_step": result["endpoint_step"],
        "free_code_acc": endpoint["free_code_acc"],
        "free_v_given4_acc": endpoint["free_v_given4_acc"],
        "free_chain_exact_acc": endpoint["free_chain_exact_acc"],
        "first_fixed_eval_crossing_0.90": first_crossing,
        "passed": passed,
        "logging_audit": result["logging_audit"],
    })

passed = len(rows) == 2 and all(row["passed"] for row in rows)
gate = {
    "status": "post-hoc window diagnostic; original v1.6c 4k decision is unchanged",
    "rule": "both seeds at step 8000 require free code/free given-4 value/free chain >= 0.90",
    "passed": passed,
    "seeds": rows,
    "interpretation": (
        "extended window recovered the internal positive bridge"
        if passed
        else "internal positive bridge remains unstable by step 8000"
    ),
}
(root / "both_ext_gate.json").write_text(
    json.dumps(gate, indent=2, sort_keys=True), encoding="utf-8"
)
print(json.dumps(gate, indent=2, sort_keys=True))
raise SystemExit(0 if passed else 3)
PY
