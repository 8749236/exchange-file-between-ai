#!/usr/bin/env bash
set -euo pipefail

output_root="${1:-runs-c1-v1.6b-readout-bundle}"
device="${2:-cpu}"

if [[ -e "$output_root" ]]; then
  echo "refusing to mix with existing output: $output_root" >&2
  exit 2
fi

python -m pytest -q
python -m callosum_nano.c1_compare \
  --output "$output_root" \
  --steps 4000 \
  --batch-size 64 \
  --eval-interval 200 \
  --validation-episodes 1024 \
  --learning-rate 3e-3 \
  --warmup-steps 1 \
  --lr-decay-steps 4000 \
  --min-lr-ratio 1.0 \
  --weight-decay 0 \
  --grad-clip 1.0 \
  --full-lm-lambda 0.0 \
  --data-mode chain-two-hop \
  --filler-mode random \
  --id-count 16 \
  --layers 2 \
  --heads 2 \
  --branch-width 64 \
  --position-encoding learned \
  --c1-head-style shared-vocab-plain \
  --seeds 1 2 \
  --conditions oracle-left \
  --assay-label C1-v1.6b-readout-bundle \
  --device "$device"

python - "$output_root/summary.json" "$output_root/gate.json" <<'PY'
import json
import sys

summary_path, gate_path = sys.argv[1:]
summary = json.load(open(summary_path, encoding="utf-8"))
rows = []
for result in summary["results"]:
    endpoint = result["endpoint_validation"]
    passed = (
        endpoint["free_code_acc"] >= 0.90
        and endpoint["free_v_given4_acc"] >= 0.90
        and endpoint["free_chain_exact_acc"] >= 0.90
    )
    rows.append(
        {
            "seed": result["train"]["seed"],
            "endpoint_step": result["endpoint_step"],
            "free_code_acc": endpoint["free_code_acc"],
            "free_v_given4_acc": endpoint["free_v_given4_acc"],
            "free_chain_exact_acc": endpoint["free_chain_exact_acc"],
            "passed": passed,
        }
    )
gate = {
    "rule": "both seeds endpoint free_code/free_v_given4/free_chain_exact >= 0.90",
    "passed": len(rows) == 2 and all(row["passed"] for row in rows),
    "seeds": rows,
}
with open(gate_path, "w", encoding="utf-8") as handle:
    json.dump(gate, handle, indent=2, sort_keys=True)
print(json.dumps(gate, indent=2, sort_keys=True))
raise SystemExit(0 if gate["passed"] else 3)
PY

