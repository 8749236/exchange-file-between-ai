import torch

from callosum_nano.config import ModelConfig
from callosum_nano.model import (
    CallosumBridge,
    CausalSelfAttention,
    build_model,
    count_parameters,
)


def config(variant: str) -> ModelConfig:
    return ModelConfig(
        variant=variant,
        context_length=16,
        n_layers=2,
        n_heads=1,
        branch_width=8,
        callosum_rank=2,
        interface_width=8,
        mlp_ratio=2,
    )


def test_all_variants_produce_language_model_logits() -> None:
    tokens = torch.randint(0, 256, (2, 12))
    for variant in (
        "narrow-dense",
        "wide-dense",
        "twin-no-comm",
        "twin-callosum",
    ):
        model = build_model(config(variant))
        logits, loss = model(tokens, tokens)
        assert logits.shape == (2, 12, 256)
        assert loss is not None and loss.ndim == 0
        assert count_parameters(model) > 0


def test_callosum_starts_as_exact_identity() -> None:
    bridge = CallosumBridge(width=8, rank=2)
    left = torch.randn(2, 5, 8)
    right = torch.randn(2, 5, 8)
    output_left, output_right = bridge(left, right)
    torch.testing.assert_close(output_left, left)
    torch.testing.assert_close(output_right, right)


def test_callosum_and_no_comm_have_paired_initialization() -> None:
    tokens = torch.randint(0, 256, (2, 12))
    torch.manual_seed(17)
    no_comm = build_model(config("twin-no-comm")).eval()
    torch.manual_seed(17)
    callosum = build_model(config("twin-callosum")).eval()

    no_comm_parameters = dict(no_comm.named_parameters())
    callosum_parameters = dict(callosum.named_parameters())
    for name, parameter in no_comm_parameters.items():
        torch.testing.assert_close(parameter, callosum_parameters[name])

    with torch.no_grad():
        no_comm_logits, _ = no_comm(tokens)
        callosum_logits, _ = callosum(tokens)
    torch.testing.assert_close(no_comm_logits, callosum_logits)


def test_initial_loss_is_close_to_uniform_prediction() -> None:
    torch.manual_seed(23)
    model = build_model(config("narrow-dense"))
    tokens = torch.randint(0, 256, (4, 12))
    _, loss = model(tokens, tokens)
    assert loss is not None
    assert 5.0 < loss.item() < 6.1


def test_model_is_causal() -> None:
    torch.manual_seed(3)
    model = build_model(config("twin-callosum")).eval()
    original = torch.randint(0, 256, (1, 12))
    changed = original.clone()
    changed[:, 8:] = torch.randint(0, 256, (1, 4))
    with torch.no_grad():
        first, _ = model(original)
        second, _ = model(changed)
    torch.testing.assert_close(first[:, :8], second[:, :8])


def test_twin_branch_parameters_are_not_shared() -> None:
    model = build_model(config("twin-callosum"))
    layer = model.layers[0]
    left_parameters = {parameter.data_ptr() for parameter in layer.left.parameters()}
    right_parameters = {
        parameter.data_ptr() for parameter in layer.right.parameters()
    }
    assert left_parameters.isdisjoint(right_parameters)


def test_rope_supports_odd_head_width() -> None:
    attention = CausalSelfAttention(width=9, n_heads=3, dropout=0.0)
    tensor = torch.randn(2, 3, 7, 3)
    encoded = attention.apply_rope(tensor, sequence_length=7)
    assert encoded.shape == tensor.shape
    torch.testing.assert_close(encoded[..., -1], tensor[..., -1])


def test_learned_positions_disable_rope_and_preserve_causality() -> None:
    learned_config = ModelConfig(
        variant="twin-no-comm",
        context_length=12,
        n_layers=1,
        n_heads=1,
        branch_width=8,
        interface_width=8,
        mlp_ratio=2,
        position_encoding="learned",
    )
    model = build_model(learned_config).eval()
    assert model.position_interface is not None
    assert not model.layers[0].left.attention.use_rope
    original = torch.randint(0, 256, (1, 12))
    changed = original.clone()
    changed[:, 8:] = torch.randint(0, 256, (1, 4))
    with torch.no_grad():
        first, _ = model(original)
        second, _ = model(changed)
    torch.testing.assert_close(first[:, :8], second[:, :8])


def test_dense_and_twin_can_use_different_head_counts() -> None:
    dense_config = ModelConfig(
        variant="narrow-dense",
        context_length=16,
        n_layers=1,
        n_heads=3,
        dense_heads=6,
        branch_heads=3,
        branch_width=48,
        dense_width_override=72,
        interface_width=8,
        mlp_ratio=2,
    )
    twin_config = ModelConfig(
        variant="twin-no-comm",
        context_length=16,
        n_layers=1,
        n_heads=3,
        dense_heads=6,
        branch_heads=3,
        branch_width=48,
        dense_width_override=72,
        interface_width=8,
        mlp_ratio=2,
    )
    assert build_model(dense_config).layers[0].attention.n_heads == 6
    assert build_model(twin_config).layers[0].left.attention.n_heads == 3
