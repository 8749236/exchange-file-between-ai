from callosum_nano.budget import (
    dense_layer_parameters,
    matched_dense_width,
    model_budget,
    twin_layer_parameters,
)


def test_default_dense_width_matches_callosum_budget() -> None:
    assert matched_dense_width(48, 8) == 69
    dense = dense_layer_parameters(69)
    twin = twin_layer_parameters(48, 8, communication=True)
    assert abs(dense - twin) / twin < 0.01


def test_callosum_budget_counts_communication() -> None:
    no_comm = model_budget("twin-no-comm")
    callosum = model_budget("twin-callosum")
    assert callosum.backbone_parameters > no_comm.backbone_parameters
    assert callosum.interface_parameters == no_comm.interface_parameters
    assert callosum.forward_macs_per_token > no_comm.forward_macs_per_token


def test_dense_width_can_be_overridden_for_controls() -> None:
    dense = model_budget("narrow-dense", dense_width=72)
    assert dense.width == 72


def test_wide_dense_uses_combined_twin_width() -> None:
    wide = model_budget("wide-dense", branch_width=48)
    assert wide.width == 96
    assert wide.total_parameters > model_budget("twin-callosum").total_parameters
