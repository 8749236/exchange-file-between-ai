from callosum_nano.data import make_synthetic_corpus


def test_synthetic_corpus_is_deterministic_and_byte_safe() -> None:
    first = make_synthetic_corpus(10, seed=7)
    second = make_synthetic_corpus(10, seed=7)
    different = make_synthetic_corpus(10, seed=8)
    assert first == second
    assert first != different
    assert b"query" in first or b"ask" in first or b"who owns" in first
    assert all(0 <= value < 256 for value in first)

