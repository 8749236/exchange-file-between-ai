import json
from pathlib import Path

from callosum_nano.c1_v17_gate import adjudicate_a, adjudicate_final


def _result(condition: str, seed: int, *, learned: bool) -> dict:
    communication = condition != "c1-a-no-bridge"
    endpoint = {
        "free_code_acc": 1.0,
        "free_value_acc": 1.0 if learned else 0.0625,
        "free_v_given4_acc": 1.0 if learned else 0.25,
        "free_chain_exact_acc": 1.0 if learned else 0.0625,
    }
    return {
        "condition": condition,
        "endpoint_step": 10_000,
        "endpoint_validation": endpoint,
        "best_bridge_zero_validation": {
            "free_code_acc": 1.0,
            "free_value_acc": 0.0625,
            "free_v_given4_acc": 0.25,
            "free_chain_exact_acc": 0.0625,
        },
        "train": {
            "steps": 10_000,
            "batch_size": 64,
            "learning_rate": 3e-3,
            "warmup_steps": 1,
            "lr_decay_steps": 10_000,
            "min_lr_ratio": 1.0,
            "weight_decay": 0.0,
            "grad_clip": 1.0,
            "eval_interval": 200,
            "validation_episodes": 4_096,
            "job_lambda": 0.1,
            "data_mode": "chain-two-hop",
            "full_lm_lambda": 0.0,
            "id_count": 16,
            "filler_mode": "random",
            "probe_episodes": 4_096,
            "seed": seed,
        },
        "model": {
            "variant": "twin-callosum" if communication else "twin-no-comm",
            "n_layers": 2,
            "n_heads": 2,
            "branch_width": 64,
            "callosum_rank": 8,
            "interface_width": 64,
            "mlp_ratio": 4,
            "dropout": 0.0,
            "position_encoding": "learned",
            "c1_heads": True,
            "c1_answer_classes": 16,
            "c1_head_style": "shared-vocab-plain",
            "c1_block_style": "nano-pre-rms",
            "c1_input_style": "direct-default",
        },
        "logging_audit": {
            "resume_start_step": 0,
            "train_curve": {
                "records": 10_000,
                "first_step": 1,
                "last_step": 10_000,
                "missing_required_new_steps": 0,
                "malformed_records": 0,
                "nul_holes": 0,
            },
            "metrics": {
                "records": 51,
                "first_step": 1,
                "last_step": 10_000,
                "missing_required_new_steps": 0,
                "malformed_records": 0,
                "nul_holes": 0,
            },
        },
    }


def _write_summary(path: Path, results: list[dict]) -> None:
    path.parent.mkdir(parents=True)
    path.write_text(json.dumps({"results": results}), encoding="utf-8")


def test_v17_a_fuse_and_job_necessity_adjudication(tmp_path: Path) -> None:
    _write_summary(
        tmp_path / "A" / "summary.json",
        [_result("c1-a-no-bridge", seed, learned=False) for seed in (1, 2)],
    )
    a_gate = adjudicate_a(tmp_path)
    assert a_gate["passed"]

    _write_summary(
        tmp_path / "BC" / "summary.json",
        [
            *[_result("c1-b-bridge", seed, learned=False) for seed in (1, 2)],
            *[
                _result("c1-c-reconstruction-job", seed, learned=True)
                for seed in (1, 2)
            ],
        ],
    )
    gate = adjudicate_final(tmp_path)
    assert not gate["cells"]["B"]["passed"]
    assert gate["cells"]["C"]["passed"]
    assert gate["cells"]["C-zero"]["passed"]
    assert "needs an explicit bridge job" in gate["interpretation"]
