#!/usr/bin/env bash
set -euo pipefail

output_root="${1:-runs-c1-v1.7-formal-abc}"
device="${2:-cpu}"
run="$output_root/BC/c1-b-bridge/seed-2"

expected_curve="3d7a493b40375b07cb53bfe8378dab6990a2d2361c48aafac548fe4b85416198"
expected_metrics="6cc3a01cff91e3f66267160e7543634ea99260c1697e6776725c5dd54eef3ea9"
expected_checkpoint="4f7dcce4990635887b9e7d806132478fa582b8f645511c52520b0d6e317a0159"

actual_curve="$(sha256sum "$run/train_curve.jsonl" | cut -d' ' -f1)"
actual_metrics="$(sha256sum "$run/metrics.jsonl" | cut -d' ' -f1)"
actual_checkpoint="$(sha256sum "$run/latest.pt" | cut -d' ' -f1)"
[[ "$actual_curve" == "$expected_curve" ]]
[[ "$actual_metrics" == "$expected_metrics" ]]
[[ "$actual_checkpoint" == "$expected_checkpoint" ]]

python - "$run" <<'PY'
import pathlib
import sys
import torch

run = pathlib.Path(sys.argv[1])
checkpoint = torch.load(run / "latest.pt", map_location="cpu", weights_only=False)
assert checkpoint["step"] == 4400
assert checkpoint["condition"] == "c1-b-bridge"
assert checkpoint["train_config"]["seed"] == 2
print("B2 interruption preflight OK: exact step-4400 checkpoint and ledgers")
PY

common=(
  --steps 10000
  --batch-size 64
  --eval-interval 200
  --validation-episodes 4096
  --learning-rate 3e-3
  --warmup-steps 1
  --lr-decay-steps 10000
  --min-lr-ratio 1.0
  --weight-decay 0
  --grad-clip 1.0
  --job-lambda 0.1
  --full-lm-lambda 0.0
  --data-mode chain-two-hop
  --filler-mode random
  --id-count 16
  --probe-episodes 4096
  --layers 2
  --heads 2
  --branch-width 64
  --callosum-rank 8
  --interface-width 64
  --mlp-ratio 4
  --dropout 0
  --position-encoding learned
  --c1-head-style shared-vocab-plain
  --c1-block-style nano-pre-rms
  --c1-input-style direct-default
  --oracle-approved
  --device "$device"
)

echo "===== RESUME C1-v1.7 B seed 2 FROM STEP 4400 ====="
python -m callosum_nano.c1_compare \
  --output "$output_root/BC" \
  --assay-label C1-v1.7-formal-BC \
  --seeds 2 --conditions c1-b-bridge --resume \
  "${common[@]}"

python - "$run" "$expected_curve" "$expected_metrics" <<'PY'
import hashlib
import json
import pathlib
import sys

run = pathlib.Path(sys.argv[1])
expected_curve, expected_metrics = sys.argv[2:]

def prefix_hash(path: pathlib.Path, records: int) -> str:
    lines = path.read_bytes().splitlines(keepends=True)[:records]
    return hashlib.sha256(b"".join(lines)).hexdigest()

curve_hash = prefix_hash(run / "train_curve.jsonl", 4400)
metrics_hash = prefix_hash(run / "metrics.jsonl", 23)
audit = {
    "interruption_step": 4400,
    "curve_prefix_sha256_before": expected_curve,
    "curve_prefix_sha256_after": curve_hash,
    "metrics_prefix_sha256_before": expected_metrics,
    "metrics_prefix_sha256_after": metrics_hash,
    "prefix_exact": (
        curve_hash == expected_curve and metrics_hash == expected_metrics
    ),
}
if not audit["prefix_exact"]:
    raise SystemExit("resumed ledger prefix changed")
(run / "resume_prefix_audit.json").write_text(
    json.dumps(audit, indent=2, sort_keys=True), encoding="utf-8"
)
print("B2 resume prefix audit OK")
PY

echo "===== START C1-v1.7 C seed 2 ====="
python -m callosum_nano.c1_compare \
  --output "$output_root/BC" \
  --assay-label C1-v1.7-formal-BC \
  --seeds 2 --conditions c1-c-reconstruction-job --resume \
  "${common[@]}"

python - "$output_root" <<'PY'
import json
import pathlib
import sys

root = pathlib.Path(sys.argv[1])
results = []
for condition in ("c1-b-bridge", "c1-c-reconstruction-job"):
    for seed in (1, 2):
        path = root / "BC" / condition / f"seed-{seed}" / "result.json"
        results.append(json.loads(path.read_text(encoding="utf-8")))
(root / "BC" / "summary.json").write_text(
    json.dumps(
        {"assay": "C1-v1.7-formal-BC", "results": results},
        indent=2,
        sort_keys=True,
    ),
    encoding="utf-8",
)
print("combined four-cell BC summary rebuilt")
PY

python -m callosum_nano.c1_v17_gate "$output_root" --phase final
