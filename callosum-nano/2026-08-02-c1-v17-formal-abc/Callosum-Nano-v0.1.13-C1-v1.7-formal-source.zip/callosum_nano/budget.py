from __future__ import annotations

import argparse
import json
import math
from dataclasses import asdict, dataclass


@dataclass(frozen=True)
class Budget:
    variant: str
    width: int
    backbone_parameters: int
    interface_parameters: int
    embedding_parameters: int
    forward_macs_per_token: int

    @property
    def total_parameters(self) -> int:
        return (
            self.backbone_parameters
            + self.interface_parameters
            + self.embedding_parameters
        )

    def to_dict(self) -> dict[str, int | str]:
        result = asdict(self)
        result["total_parameters"] = self.total_parameters
        return result


def dense_layer_parameters(width: int, mlp_ratio: int = 4) -> int:
    """Bias-free attention + MLP + two RMSNorm scales."""
    attention = 4 * width * width
    mlp = 2 * mlp_ratio * width * width
    norms = 2 * width
    return attention + mlp + norms


def twin_layer_parameters(
    branch_width: int,
    callosum_rank: int,
    mlp_ratio: int = 4,
    *,
    communication: bool = True,
) -> int:
    branches = 2 * dense_layer_parameters(branch_width, mlp_ratio)
    if not communication:
        return branches
    # Two source RMSNorms and two directional down/up low-rank paths.
    return branches + 2 * branch_width + 4 * branch_width * callosum_rank


def matched_dense_width(
    branch_width: int,
    callosum_rank: int,
    mlp_ratio: int = 4,
    *,
    communication: bool = True,
) -> int:
    target = twin_layer_parameters(
        branch_width,
        callosum_rank,
        mlp_ratio,
        communication=communication,
    )
    estimate = branch_width * math.sqrt(2)
    candidates = range(max(1, int(estimate) - 8), int(estimate) + 10)
    return min(
        candidates,
        key=lambda width: abs(
            dense_layer_parameters(width, mlp_ratio) - target
        ),
    )


def model_budget(
    variant: str,
    *,
    vocab_size: int = 256,
    interface_width: int = 64,
    n_layers: int = 4,
    branch_width: int = 48,
    callosum_rank: int = 8,
    mlp_ratio: int = 4,
    context_length: int = 128,
    dense_width: int | None = None,
    wide_dense_width: int | None = None,
) -> Budget:
    embedding = vocab_size * interface_width

    if variant in {"narrow-dense", "wide-dense"}:
        width = (
            wide_dense_width or 2 * branch_width
            if variant == "wide-dense"
            else dense_width
            or matched_dense_width(
                branch_width, callosum_rank, mlp_ratio, communication=True
            )
        )
        backbone = n_layers * dense_layer_parameters(width, mlp_ratio)
        # input adapter + output adapter + final RMSNorm
        interface = 2 * interface_width * width + width
        layer_macs = (
            (4 + 2 * mlp_ratio) * width * width
            + 2 * context_length * width
        )
        forward_macs = (
            n_layers * layer_macs
            + 2 * interface_width * width
            + interface_width * vocab_size
        )
    elif variant in {"twin-no-comm", "twin-callosum"}:
        width = 2 * branch_width
        communication = variant == "twin-callosum"
        backbone = n_layers * twin_layer_parameters(
            branch_width,
            callosum_rank,
            mlp_ratio,
            communication=communication,
        )
        interface = 4 * interface_width * branch_width + 2 * branch_width
        layer_macs = 2 * (
            (4 + 2 * mlp_ratio) * branch_width * branch_width
            + 2 * context_length * branch_width
        )
        if communication:
            layer_macs += 4 * branch_width * callosum_rank
        forward_macs = (
            n_layers * layer_macs
            + 4 * interface_width * branch_width
            + interface_width * vocab_size
        )
    else:
        raise ValueError(f"unknown variant: {variant}")

    return Budget(
        variant=variant,
        width=width,
        backbone_parameters=backbone,
        interface_parameters=interface,
        embedding_parameters=embedding,
        forward_macs_per_token=forward_macs,
    )


def main() -> None:
    parser = argparse.ArgumentParser(description="Print analytical model budgets")
    parser.add_argument("--branch-width", type=int, default=48)
    parser.add_argument("--callosum-rank", type=int, default=8)
    parser.add_argument("--layers", type=int, default=4)
    parser.add_argument("--interface-width", type=int, default=64)
    parser.add_argument("--vocab-size", type=int, default=256)
    parser.add_argument("--mlp-ratio", type=int, default=4)
    parser.add_argument("--context-length", type=int, default=128)
    args = parser.parse_args()

    budgets = [
        model_budget(
            variant,
            vocab_size=args.vocab_size,
            interface_width=args.interface_width,
            n_layers=args.layers,
            branch_width=args.branch_width,
            callosum_rank=args.callosum_rank,
            mlp_ratio=args.mlp_ratio,
            context_length=args.context_length,
        ).to_dict()
        for variant in ("narrow-dense", "twin-no-comm", "twin-callosum")
    ]
    print(json.dumps(budgets, indent=2))


if __name__ == "__main__":
    main()
