from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


CODE_PASS = 0.90
VALUE_PASS = 0.90
GIVEN4_CHANCE_CEILING = 0.30
VALUE_CHANCE_CEILING = 0.10

EXPECTED_TRAIN = {
    "steps": 10_000,
    "batch_size": 64,
    "learning_rate": 3e-3,
    "warmup_steps": 1,
    "lr_decay_steps": 10_000,
    "min_lr_ratio": 1.0,
    "weight_decay": 0.0,
    "grad_clip": 1.0,
    "eval_interval": 200,
    "validation_episodes": 4_096,
    "job_lambda": 0.1,
    "data_mode": "chain-two-hop",
    "full_lm_lambda": 0.0,
    "id_count": 16,
    "filler_mode": "random",
    "probe_episodes": 4_096,
}

EXPECTED_MODEL = {
    "n_layers": 2,
    "n_heads": 2,
    "branch_width": 64,
    "callosum_rank": 8,
    "interface_width": 64,
    "mlp_ratio": 4,
    "dropout": 0.0,
    "position_encoding": "learned",
    "c1_heads": True,
    "c1_answer_classes": 16,
    "c1_head_style": "shared-vocab-plain",
    "c1_block_style": "nano-pre-rms",
    "c1_input_style": "direct-default",
}


def _read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _check_fields(
    actual: dict[str, Any], expected: dict[str, Any], label: str
) -> None:
    for key, value in expected.items():
        if actual.get(key) != value:
            raise ValueError(
                f"{label}: {key}={actual.get(key)!r}, expected {value!r}"
            )


def _audit_is_green(result: dict[str, Any]) -> bool:
    audit = result.get("logging_audit", {})
    curve = audit.get("train_curve", {})
    metrics = audit.get("metrics", {})
    expected = (
        (curve, 10_000, 1, 10_000),
        (metrics, 51, 1, 10_000),
    )
    for ledger, records, first, last in expected:
        if (
            ledger.get("records") != records
            or ledger.get("first_step") != first
            or ledger.get("last_step") != last
            or any(
                ledger.get(key) != 0
                for key in (
                    "missing_required_new_steps",
                    "malformed_records",
                    "nul_holes",
                )
            )
        ):
            return False
    resume_start = audit.get("resume_start_step")
    return (
        isinstance(resume_start, int)
        and 0 <= resume_start < EXPECTED_TRAIN["steps"]
    )


def _endpoint_row(result: dict[str, Any]) -> dict[str, Any]:
    condition = result["condition"]
    seed = int(result["train"]["seed"])
    _check_fields(result["train"], EXPECTED_TRAIN, f"{condition}/seed-{seed} train")
    expected_model = dict(EXPECTED_MODEL)
    expected_model["variant"] = (
        "twin-no-comm"
        if condition == "c1-a-no-bridge"
        else "twin-callosum"
    )
    _check_fields(
        result["model"], expected_model, f"{condition}/seed-{seed} model"
    )
    if result.get("endpoint_step") != 10_000:
        raise ValueError(f"{condition}/seed-{seed}: endpoint is not 10000")
    endpoint = result["endpoint_validation"]
    return {
        "condition": condition,
        "seed": seed,
        "free_code_acc": endpoint["free_code_acc"],
        "free_value_acc": endpoint["free_value_acc"],
        "free_v_given4_acc": endpoint["free_v_given4_acc"],
        "free_chain_exact_acc": endpoint["free_chain_exact_acc"],
        "logging_audit_green": _audit_is_green(result),
        "resume_start_step": result["logging_audit"].get(
            "resume_start_step"
        ),
    }


def _a_row_passes(row: dict[str, Any]) -> bool:
    return (
        row["logging_audit_green"]
        and row["free_code_acc"] >= CODE_PASS
        and row["free_value_acc"] <= VALUE_CHANCE_CEILING
        and row["free_v_given4_acc"] <= GIVEN4_CHANCE_CEILING
        and row["free_chain_exact_acc"] <= VALUE_CHANCE_CEILING
    )


def _communication_row_passes(row: dict[str, Any]) -> bool:
    return (
        row["logging_audit_green"]
        and row["free_code_acc"] >= CODE_PASS
        and row["free_v_given4_acc"] >= VALUE_PASS
        and row["free_chain_exact_acc"] >= VALUE_PASS
    )


def _zero_row(result: dict[str, Any]) -> dict[str, Any]:
    condition = result["condition"]
    seed = int(result["train"]["seed"])
    zero = result["best_bridge_zero_validation"]
    row = {
        "condition": condition,
        "seed": seed,
        "free_code_acc": zero["free_code_acc"],
        "free_value_acc": zero["free_value_acc"],
        "free_v_given4_acc": zero["free_v_given4_acc"],
        "free_chain_exact_acc": zero["free_chain_exact_acc"],
    }
    row["passed"] = (
        row["free_code_acc"] >= CODE_PASS
        and row["free_value_acc"] <= VALUE_CHANCE_CEILING
        and row["free_v_given4_acc"] <= GIVEN4_CHANCE_CEILING
        and row["free_chain_exact_acc"] <= VALUE_CHANCE_CEILING
    )
    return row


def _load_results(path: Path) -> list[dict[str, Any]]:
    return _read_json(path)["results"]


def adjudicate_a(root: Path) -> dict[str, Any]:
    results = _load_results(root / "A" / "summary.json")
    if {(r["condition"], int(r["train"]["seed"])) for r in results} != {
        ("c1-a-no-bridge", 1),
        ("c1-a-no-bridge", 2),
    }:
        raise ValueError("A summary does not contain exactly the paired seeds")
    rows = [_endpoint_row(result) for result in results]
    for row in rows:
        row["passed"] = _a_row_passes(row)
    passed = all(row["passed"] for row in rows)
    gate = {
        "phase": "A structural fuse",
        "rule": (
            "both seeds: endpoint free_code>=0.90, free_value<=0.10, "
            "free_v_given4<=0.30, free_chain<=0.10, logging audit green"
        ),
        "passed": passed,
        "seeds": rows,
        "interpretation": (
            "A fuse passed; B/C may start"
            if passed
            else "A fuse failed; assay invalid and B/C must not start"
        ),
    }
    (root / "a_gate.json").write_text(
        json.dumps(gate, indent=2, sort_keys=True), encoding="utf-8"
    )
    return gate


def adjudicate_final(root: Path) -> dict[str, Any]:
    a_gate = adjudicate_a(root)
    if not a_gate["passed"]:
        raise ValueError("cannot adjudicate B/C after a failed A fuse")
    results = _load_results(root / "BC" / "summary.json")
    expected = {
        (condition, seed)
        for condition in ("c1-b-bridge", "c1-c-reconstruction-job")
        for seed in (1, 2)
    }
    if {(r["condition"], int(r["train"]["seed"])) for r in results} != expected:
        raise ValueError("B/C summary does not contain exactly the paired cells")

    endpoint_rows = [_endpoint_row(result) for result in results]
    for row in endpoint_rows:
        row["passed"] = _communication_row_passes(row)
    by_condition = {
        condition: [
            row for row in endpoint_rows if row["condition"] == condition
        ]
        for condition in ("c1-b-bridge", "c1-c-reconstruction-job")
    }
    b_passed = all(row["passed"] for row in by_condition["c1-b-bridge"])
    c_passed = all(
        row["passed"] for row in by_condition["c1-c-reconstruction-job"]
    )
    zero_rows = [
        _zero_row(result)
        for result in results
        if result["condition"] == "c1-c-reconstruction-job"
    ]
    zero_passed = len(zero_rows) == 2 and all(
        row["passed"] for row in zero_rows
    )

    if c_passed and zero_passed and not b_passed:
        interpretation = (
            "C passes, B does not, and C-zero selectively collapses value: "
            "supports that this assay needs an explicit bridge job"
        )
    elif c_passed and zero_passed and b_passed:
        interpretation = (
            "B and C pass and C-zero selectively collapses value: the bridge "
            "is necessary, but an explicit reconstruction job is not"
        )
    elif c_passed and not zero_passed:
        interpretation = (
            "C learns, but C-zero necessity control fails; no communication "
            "mechanism claim is permitted"
        )
    else:
        interpretation = (
            "C does not pass both seeds by 10k; the reconstruction job is "
            "insufficient under this frozen assay"
        )

    gate = {
        "assay": "C1-v1.7-formal-ABC",
        "status": "valid",
        "a_gate": a_gate,
        "endpoint_rule": (
            "each communication cell requires both seeds endpoint "
            "free_code/free_v_given4/free_chain>=0.90"
        ),
        "cells": {
            "B": {
                "passed": b_passed,
                "seeds": by_condition["c1-b-bridge"],
            },
            "C": {
                "passed": c_passed,
                "seeds": by_condition["c1-c-reconstruction-job"],
            },
            "C-zero": {
                "passed": zero_passed,
                "rule": (
                    "best checkpoint: free_code>=0.90, free_value<=0.10, "
                    "free_v_given4<=0.30, free_chain<=0.10"
                ),
                "seeds": zero_rows,
            },
        },
        "interpretation": interpretation,
    }
    (root / "formal_gate.json").write_text(
        json.dumps(gate, indent=2, sort_keys=True), encoding="utf-8"
    )
    return gate


def main() -> None:
    parser = argparse.ArgumentParser(description="Adjudicate frozen C1 v1.7")
    parser.add_argument("root", type=Path)
    parser.add_argument("--phase", choices=("a", "final"), required=True)
    args = parser.parse_args()
    gate = (
        adjudicate_a(args.root)
        if args.phase == "a"
        else adjudicate_final(args.root)
    )
    print(json.dumps(gate, indent=2, sort_keys=True))
    if args.phase == "a" and not gate["passed"]:
        raise SystemExit(3)


if __name__ == "__main__":
    main()
