from __future__ import annotations

import random
from pathlib import Path

try:
    import torch
except ModuleNotFoundError:  # Corpus generation remains usable without PyTorch.
    torch = None  # type: ignore[assignment]


NAMES = (
    "ada",
    "bea",
    "cy",
    "dia",
    "eli",
    "fox",
    "gia",
    "hal",
    "ian",
    "joy",
)
COLORS = ("red", "blue", "green", "gold", "white", "black")
OBJECTS = ("key", "orb", "book", "coin", "ring", "map")


def make_synthetic_corpus(records: int, seed: int) -> bytes:
    """Generate compact, deterministic relational text for byte-level LM."""
    if records < 1:
        raise ValueError("records must be positive")
    rng = random.Random(seed)
    lines: list[str] = []
    templates = (
        "{a} has {n} {c} {o}s . {b} has {m} {d} {p}s . "
        "query {a} {c} {o} => {n} .\n",
        "owner {a} ; item {c} {o} ; count {n} . "
        "ask count of {a}'s {c} {o} => {n} .\n",
        "{n} {c} {o}s belong to {a} . "
        "{m} {d} {p}s belong to {b} . who owns {c} {o}s ? {a} .\n",
    )
    for _ in range(records):
        a, b = rng.sample(NAMES, 2)
        c, d = rng.sample(COLORS, 2)
        o, p = rng.sample(OBJECTS, 2)
        n, m = rng.sample(range(1, 10), 2)
        template = rng.choice(templates)
        lines.append(
            template.format(a=a, b=b, c=c, d=d, o=o, p=p, n=n, m=m)
        )
    return "".join(lines).encode("utf-8")


def read_corpus(path: str | Path) -> bytes:
    content = Path(path).read_bytes()
    if len(content) < 2:
        raise ValueError(f"corpus is too short: {path}")
    return content


class ByteStream:
    def __init__(
        self,
        data: bytes,
        context_length: int,
        *,
        seed: int,
        device: torch.device,
    ) -> None:
        if torch is None:
            raise RuntimeError("ByteStream requires PyTorch; install project dependencies")
        if len(data) <= context_length:
            raise ValueError(
                f"need more than {context_length} bytes, got {len(data)}"
            )
        self.tokens = torch.tensor(
            list(data), dtype=torch.long, device=device
        )
        self.context_length = context_length
        self.generator = torch.Generator(device=device)
        self.generator.manual_seed(seed)

    def batch(self, batch_size: int) -> tuple[torch.Tensor, torch.Tensor]:
        if torch is None:
            raise RuntimeError("ByteStream requires PyTorch; install project dependencies")
        starts = torch.randint(
            0,
            len(self.tokens) - self.context_length,
            (batch_size,),
            generator=self.generator,
            device=self.tokens.device,
        )
        offsets = torch.arange(
            self.context_length, device=self.tokens.device
        )
        inputs = self.tokens[starts[:, None] + offsets[None, :]]
        targets = self.tokens[starts[:, None] + offsets[None, :] + 1]
        return inputs, targets

    def state_dict(self) -> dict[str, torch.Tensor]:
        return {"generator_state": self.generator.get_state()}

    def load_state_dict(self, state: dict[str, torch.Tensor]) -> None:
        self.generator.set_state(state["generator_state"])
