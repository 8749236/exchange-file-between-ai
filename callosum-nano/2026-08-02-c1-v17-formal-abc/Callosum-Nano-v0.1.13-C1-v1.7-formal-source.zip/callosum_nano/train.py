from __future__ import annotations

import json
import math
import os
import random
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any

import torch

from .config import ExperimentConfig, ModelConfig
from .data import ByteStream
from .model import DirectionalBridge, build_model, count_parameters


def resolve_device(name: str) -> torch.device:
    if name != "auto":
        return torch.device(name)
    if torch.cuda.is_available():
        return torch.device("cuda")
    if (
        hasattr(torch.backends, "mps")
        and torch.backends.mps.is_available()
    ):
        return torch.device("mps")
    return torch.device("cpu")


def seed_everything(seed: int) -> None:
    random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


@torch.no_grad()
def evaluate(
    model: torch.nn.Module,
    stream: ByteStream,
    batches: int,
    batch_size: int,
) -> float:
    model.eval()
    losses: list[float] = []
    for _ in range(batches):
        inputs, targets = stream.batch(batch_size)
        _, loss = model(inputs, targets)
        assert loss is not None
        losses.append(loss.detach().item())
    model.train()
    return sum(losses) / len(losses)


def save_json_line(path: Path, value: dict[str, Any]) -> None:
    payload = (json.dumps(value, sort_keys=True) + "\n").encode("utf-8")
    flags = os.O_WRONLY | os.O_CREAT | os.O_APPEND
    flags |= getattr(os, "O_BINARY", 0)
    try:
        descriptor = os.open(path, flags, 0o666)
    except FileExistsError:
        # Some network-mounted filesystems have transiently treated O_CREAT
        # as exclusive even though O_EXCL is absent. The run lock guarantees a
        # single writer, so retrying an existing path without O_CREAT keeps the
        # append atomic while avoiding a lost diagnostic run.
        descriptor = os.open(path, flags & ~os.O_CREAT, 0o666)
    try:
        remaining = memoryview(payload)
        while remaining:
            written = os.write(descriptor, remaining)
            if written == 0:
                raise OSError("zero-byte write while appending JSONL")
            remaining = remaining[written:]
    finally:
        os.close(descriptor)


def write_jsonl_atomic(
    path: Path, records: list[dict[str, Any]]
) -> None:
    """Replace a JSONL file atomically from an in-memory record ledger.

    The experiment filesystem has produced sparse NUL holes when a file is
    repeatedly reopened with O_APPEND. Training now batches records until an
    evaluation/checkpoint boundary and replaces the complete ledger instead.
    """
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8", newline="\n") as handle:
        for record in records:
            handle.write(json.dumps(record, sort_keys=True))
            handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


def callosum_up_rms(model: torch.nn.Module) -> float | None:
    weights = [
        module.up.weight.detach().float()
        for module in model.modules()
        if isinstance(module, DirectionalBridge)
    ]
    if not weights:
        return None
    squared_sum = sum(float(weight.pow(2).sum()) for weight in weights)
    element_count = sum(weight.numel() for weight in weights)
    return math.sqrt(squared_sum / element_count)


def learning_rate_at_step(step: int, experiment: ExperimentConfig) -> float:
    warmup_steps = experiment.effective_warmup_steps
    if warmup_steps and step <= warmup_steps:
        return experiment.learning_rate * step / warmup_steps
    decay_steps = experiment.effective_lr_decay_steps
    if step >= decay_steps:
        return experiment.learning_rate * experiment.min_lr_ratio
    decay_span = decay_steps - warmup_steps
    progress = (step - warmup_steps) / decay_span
    cosine = 0.5 * (1.0 + math.cos(math.pi * progress))
    multiplier = (
        experiment.min_lr_ratio
        + (1.0 - experiment.min_lr_ratio) * cosine
    )
    return experiment.learning_rate * multiplier


def set_learning_rate(
    optimizer: torch.optim.Optimizer, learning_rate: float
) -> None:
    for group in optimizer.param_groups:
        group["lr"] = learning_rate


def train_one(
    model_config: ModelConfig,
    experiment: ExperimentConfig,
    train_bytes: bytes,
    valid_bytes: bytes,
    output_dir: Path,
    *,
    resume: bool = False,
) -> dict[str, Any]:
    model_config.validate()
    experiment.validate()
    seed_everything(experiment.seed)
    device = resolve_device(experiment.device)
    output_dir.mkdir(parents=True, exist_ok=True)

    model = build_model(model_config).to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=experiment.learning_rate,
        weight_decay=experiment.weight_decay,
    )
    train_stream = ByteStream(
        train_bytes,
        model_config.context_length,
        seed=experiment.seed,
        device=device,
    )
    valid_stream = ByteStream(
        valid_bytes,
        model_config.context_length,
        seed=10_000 + experiment.seed,
        device=device,
    )
    metrics_path = output_dir / "metrics.jsonl"
    latest_path = output_dir / "latest.pt"

    metadata = {
        "model": model_config.to_dict(),
        "experiment": experiment.to_dict(),
        "device": str(device),
        "parameters": count_parameters(model),
    }
    (output_dir / "config.json").write_text(
        json.dumps(metadata, indent=2, sort_keys=True),
        encoding="utf-8",
    )

    best_loss = math.inf
    best_step = 0
    start_step = 0
    previous_elapsed = 0.0
    if resume and latest_path.exists():
        checkpoint = torch.load(
            latest_path, map_location=device, weights_only=False
        )
        if checkpoint["model_config"] != model_config.to_dict():
            raise ValueError("resume model configuration does not match")
        model.load_state_dict(checkpoint["model_state"])
        optimizer.load_state_dict(checkpoint["optimizer_state"])
        train_stream.load_state_dict(checkpoint["train_stream_state"])
        valid_stream.load_state_dict(checkpoint["valid_stream_state"])
        random.setstate(checkpoint["python_random_state"])
        torch.set_rng_state(checkpoint["torch_random_state"])
        if torch.cuda.is_available() and checkpoint.get("cuda_random_state"):
            torch.cuda.set_rng_state_all(checkpoint["cuda_random_state"])
        start_step = checkpoint["step"]
        best_loss = checkpoint["best_validation_loss"]
        best_step = checkpoint["best_step"]
        previous_elapsed = checkpoint.get("elapsed_seconds", 0.0)
    elif metrics_path.exists():
        metrics_path.unlink()

    started = time.perf_counter()
    model.train()

    for step in range(start_step + 1, experiment.steps + 1):
        learning_rate = learning_rate_at_step(step, experiment)
        set_learning_rate(optimizer, learning_rate)
        inputs, targets = train_stream.batch(experiment.batch_size)
        optimizer.zero_grad(set_to_none=True)
        _, loss = model(inputs, targets)
        assert loss is not None
        loss.backward()
        grad_norm = torch.nn.utils.clip_grad_norm_(
            model.parameters(), experiment.grad_clip
        )
        optimizer.step()
        loss_value = loss.detach().item()
        grad_norm_value = (
            grad_norm.detach().item()
            if isinstance(grad_norm, torch.Tensor)
            else float(grad_norm)
        )

        should_eval = (
            step == 1
            or step % experiment.eval_interval == 0
            or step == experiment.steps
        )
        if should_eval:
            validation_loss = evaluate(
                model,
                valid_stream,
                experiment.eval_batches,
                experiment.batch_size,
            )
            elapsed = previous_elapsed + time.perf_counter() - started
            metric = {
                "step": step,
                "train_loss": loss_value,
                "validation_loss": validation_loss,
                "validation_bpb": validation_loss / math.log(2),
                "grad_norm": grad_norm_value,
                "learning_rate": learning_rate,
                "elapsed_seconds": elapsed,
            }
            bridge_rms = callosum_up_rms(model)
            if bridge_rms is not None:
                metric["callosum_up_rms"] = bridge_rms
            save_json_line(metrics_path, metric)
            bridge_text = (
                f" bridge_up_rms={bridge_rms:.3e}"
                if bridge_rms is not None
                else ""
            )
            print(
                f"{model_config.variant} seed={experiment.seed} "
                f"step={step:5d} train={loss_value:.4f} "
                f"valid={validation_loss:.4f} "
                f"bpb={metric['validation_bpb']:.3f}"
                f" lr={learning_rate:.3e}"
                f"{bridge_text}"
            )
            if validation_loss < best_loss:
                best_loss = validation_loss
                best_step = step
                torch.save(
                    {
                        "model_state": model.state_dict(),
                        "model_config": model_config.to_dict(),
                        "experiment": asdict(experiment),
                        "step": step,
                        "validation_loss": validation_loss,
                    },
                    output_dir / "best.pt",
                )
            torch.save(
                {
                    "model_state": model.state_dict(),
                    "optimizer_state": optimizer.state_dict(),
                    "model_config": model_config.to_dict(),
                    "experiment": experiment.to_dict(),
                    "step": step,
                    "best_validation_loss": best_loss,
                    "best_step": best_step,
                    "train_stream_state": train_stream.state_dict(),
                    "valid_stream_state": valid_stream.state_dict(),
                    "python_random_state": random.getstate(),
                    "torch_random_state": torch.get_rng_state(),
                    "cuda_random_state": (
                        torch.cuda.get_rng_state_all()
                        if torch.cuda.is_available()
                        else None
                    ),
                    "elapsed_seconds": elapsed,
                },
                latest_path,
            )

    return {
        **metadata,
        "best_validation_loss": best_loss,
        "best_validation_bpb": best_loss / math.log(2),
        "best_step": best_step,
        "elapsed_seconds": (
            previous_elapsed + time.perf_counter() - started
        ),
    }
