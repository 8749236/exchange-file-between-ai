from __future__ import annotations

from dataclasses import dataclass

import torch


C1_CONTEXT_LENGTH = 64
C1_CHAIN_CONTEXT_LENGTH = 65
C1_FACTS = 4
C1_A_MARK = 250
C1_B_MARK = 251
C1_Q_MARK = 252
C1_MASK = 253
C1_PAD = 254
C1_DATA_MODES = (
    "chain-two-hop",
    "two-hop",
    "code-query-one-hop",
    "direct-name-value-one-hop",
)
C1_FILLER_MODES = ("random", "constant")


@dataclass
class C1Batch:
    inputs: torch.Tensor
    targets: torch.Tensor
    left_inputs: torch.Tensor
    right_inputs: torch.Tensor
    answer_mask: torch.Tensor
    code_mask: torch.Tensor
    value_mask: torch.Tensor
    b_fact_mask: torch.Tensor

    def to(self, device: torch.device | str) -> "C1Batch":
        return C1Batch(
            **{
                name: value.to(device)
                for name, value in vars(self).items()
            }
        )


class C1Stream:
    """Generate causal name→code→value episodes for the C1 assay.

    A facts occupy 0..11, B facts 12..23, filler 24..60, and the query
    marker/name 61..62. Legacy modes place the value at input 63. The v1.3
    chain mode appends code/value at inputs 63..64 without moving the query
    or shortening retention distance. Left cannot see B facts; right cannot
    see A facts.
    """

    def __init__(
        self,
        seed: int,
        device: torch.device | str = "cpu",
        data_mode: str = "two-hop",
        id_count: int = 64,
        filler_mode: str = "random",
    ) -> None:
        if data_mode not in C1_DATA_MODES:
            raise ValueError(f"unknown C1 data mode: {data_mode}")
        if not 4 <= id_count <= 64:
            raise ValueError("id_count must be in [4, 64]")
        if filler_mode not in C1_FILLER_MODES:
            raise ValueError(f"unknown C1 filler mode: {filler_mode}")
        self.generator = torch.Generator(device="cpu")
        self.generator.manual_seed(int(seed))
        self.device = torch.device(device)
        self.data_mode = data_mode
        self.id_count = id_count
        self.filler_mode = filler_mode

    @property
    def context_length(self) -> int:
        return c1_context_length(self.data_mode)

    def batch(self, batch_size: int) -> C1Batch:
        if batch_size < 1:
            raise ValueError("batch_size must be positive")
        g = self.generator
        names = torch.stack(
            [
                torch.randperm(self.id_count, generator=g)[:C1_FACTS]
                for _ in range(batch_size)
            ]
        )
        codes = torch.stack(
            [
                torch.randperm(self.id_count, generator=g)[:C1_FACTS]
                for _ in range(batch_size)
            ]
        )
        values = torch.stack(
            [
                torch.randperm(self.id_count, generator=g)[:C1_FACTS]
                for _ in range(batch_size)
            ]
        )
        permutation = torch.stack(
            [
                torch.randperm(C1_FACTS, generator=g)
                for _ in range(batch_size)
            ]
        )
        query_index = torch.randint(
            0, C1_FACTS, (batch_size,), generator=g
        )
        context_length = self.context_length
        episode = torch.zeros(
            batch_size, context_length + 1, dtype=torch.long
        )
        rows = torch.arange(batch_size)

        for fact in range(C1_FACTS):
            start = 3 * fact
            episode[:, start] = C1_A_MARK
            episode[:, start + 1] = names[:, fact]
            if self.data_mode == "direct-name-value-one-hop":
                episode[:, start + 2] = 128 + values[:, fact]
            else:
                episode[:, start + 2] = 64 + codes[:, fact]

        for slot in range(C1_FACTS):
            start = 12 + 3 * slot
            source = permutation[:, slot]
            episode[:, start] = C1_B_MARK
            episode[:, start + 1] = 64 + codes[rows, source]
            episode[:, start + 2] = 128 + values[rows, source]

        if self.filler_mode == "random":
            episode[:, 24:61] = torch.randint(
                192, 240, (batch_size, 37), generator=g
            )
        else:
            # Remove distractor entropy while preserving retention distance,
            # query position, sequence length, and RoPE coordinates.
            episode[:, 24:61] = 239
        episode[:, 61] = C1_Q_MARK
        if self.data_mode == "code-query-one-hop":
            episode[:, 62] = 64 + codes[rows, query_index]
        else:
            episode[:, 62] = names[rows, query_index]
        if self.data_mode == "chain-two-hop":
            episode[:, 63] = 64 + codes[rows, query_index]
            episode[:, 64] = 128 + values[rows, query_index]
            episode[:, 65] = C1_PAD
        else:
            episode[:, 63] = 128 + values[rows, query_index]
            episode[:, 64] = C1_PAD

        inputs = episode[:, :context_length]
        targets = episode[:, 1 : context_length + 1]
        left_inputs = inputs.clone()
        left_inputs[:, 12:24] = C1_MASK
        right_inputs = inputs.clone()
        right_inputs[:, :12] = C1_MASK

        code_mask = torch.zeros_like(inputs, dtype=torch.bool)
        value_mask = torch.zeros_like(inputs, dtype=torch.bool)
        if self.data_mode == "chain-two-hop":
            code_mask[:, 62] = True
            value_mask[:, 63] = True
        else:
            value_mask[:, 62] = True
        # Compatibility alias for v1.1/v1.2 callers. It always denotes the
        # value-decision position, never the intermediate code position.
        answer_mask = value_mask.clone()
        b_fact_mask = torch.zeros_like(inputs, dtype=torch.bool)
        # Payload only: exclude the fixed B_MARK positions so the auxiliary
        # job cannot lower its loss by exploiting a 4/12 constant shortcut.
        b_fact_mask[:, [13, 14, 16, 17, 19, 20, 22, 23]] = True

        return C1Batch(
            inputs,
            targets,
            left_inputs,
            right_inputs,
            answer_mask,
            code_mask,
            value_mask,
            b_fact_mask,
        ).to(self.device)

    def state_dict(self) -> dict[str, torch.Tensor]:
        return {"generator_state": self.generator.get_state()}

    def load_state_dict(self, state: dict[str, torch.Tensor]) -> None:
        self.generator.set_state(state["generator_state"].cpu())


def c1_context_length(data_mode: str) -> int:
    if data_mode not in C1_DATA_MODES:
        raise ValueError(f"unknown C1 data mode: {data_mode}")
    if data_mode == "chain-two-hop":
        return C1_CHAIN_CONTEXT_LENGTH
    return C1_CONTEXT_LENGTH
