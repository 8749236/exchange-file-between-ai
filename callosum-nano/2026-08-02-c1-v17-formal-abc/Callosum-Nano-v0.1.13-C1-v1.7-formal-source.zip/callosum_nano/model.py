from __future__ import annotations

import math
from dataclasses import dataclass, field

import torch
import torch.nn as nn
import torch.nn.functional as F

from .config import ModelConfig


def initialize_linear(layer: nn.Linear, std: float = 0.02) -> nn.Linear:
    nn.init.normal_(layer.weight, mean=0.0, std=std)
    return layer


class RMSNorm(nn.Module):
    def __init__(self, width: int, eps: float = 1e-6) -> None:
        super().__init__()
        self.weight = nn.Parameter(torch.ones(width))
        self.eps = eps

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        scale = torch.rsqrt(x.float().pow(2).mean(dim=-1, keepdim=True) + self.eps)
        return (x * scale.to(dtype=x.dtype)) * self.weight


class CausalSelfAttention(nn.Module):
    def __init__(
        self,
        width: int,
        n_heads: int,
        dropout: float,
        *,
        use_rope: bool = True,
    ) -> None:
        super().__init__()
        if width % n_heads:
            raise ValueError("attention width must be divisible by n_heads")
        self.width = width
        self.n_heads = n_heads
        self.head_width = width // n_heads
        self.dropout = dropout
        self.use_rope = use_rope
        self.qkv = initialize_linear(
            nn.Linear(width, 3 * width, bias=False)
        )
        self.output = initialize_linear(
            nn.Linear(width, width, bias=False)
        )

    def apply_rope(
        self, tensor: torch.Tensor, sequence_length: int
    ) -> torch.Tensor:
        rotary_width = self.head_width - (self.head_width % 2)
        if rotary_width == 0:
            return tensor
        positions = torch.arange(
            sequence_length, device=tensor.device, dtype=torch.float32
        )
        dimension_ids = torch.arange(
            0, rotary_width, 2, device=tensor.device, dtype=torch.float32
        )
        inverse_frequency = 1.0 / (
            10_000 ** (dimension_ids / rotary_width)
        )
        angles = torch.outer(positions, inverse_frequency)
        cosine = angles.cos().repeat_interleave(2, dim=-1)[None, None, :, :]
        sine = angles.sin().repeat_interleave(2, dim=-1)[None, None, :, :]

        rotated_part = tensor[..., :rotary_width]
        pairs = rotated_part.reshape(*rotated_part.shape[:-1], -1, 2)
        rotated_half = torch.stack(
            (-pairs[..., 1], pairs[..., 0]), dim=-1
        ).flatten(-2)
        encoded = (
            rotated_part * cosine.to(dtype=tensor.dtype)
            + rotated_half * sine.to(dtype=tensor.dtype)
        )
        if rotary_width == self.head_width:
            return encoded
        return torch.cat((encoded, tensor[..., rotary_width:]), dim=-1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        batch, length, _ = x.shape
        q, k, v = self.qkv(x).chunk(3, dim=-1)

        def heads(tensor: torch.Tensor) -> torch.Tensor:
            return tensor.view(
                batch, length, self.n_heads, self.head_width
            ).transpose(1, 2)

        q, k, v = heads(q), heads(k), heads(v)
        if self.use_rope:
            q = self.apply_rope(q, length)
            k = self.apply_rope(k, length)
        if hasattr(F, "scaled_dot_product_attention"):
            attended = F.scaled_dot_product_attention(
                q,
                k,
                v,
                dropout_p=self.dropout if self.training else 0.0,
                is_causal=True,
            )
        else:
            scores = (q @ k.transpose(-2, -1)) / math.sqrt(self.head_width)
            causal = torch.ones(
                length, length, device=x.device, dtype=torch.bool
            ).tril()
            scores = scores.masked_fill(~causal, float("-inf"))
            weights = F.softmax(scores, dim=-1)
            weights = F.dropout(
                weights, p=self.dropout, training=self.training
            )
            attended = weights @ v

        attended = attended.transpose(1, 2).contiguous().view(
            batch, length, self.width
        )
        return self.output(attended)


class MLP(nn.Module):
    def __init__(self, width: int, ratio: int, dropout: float) -> None:
        super().__init__()
        hidden = ratio * width
        self.up = initialize_linear(
            nn.Linear(width, hidden, bias=False)
        )
        self.down = initialize_linear(
            nn.Linear(hidden, width, bias=False)
        )
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.dropout(self.down(F.gelu(self.up(x), approximate="tanh")))


class TransformerBlock(nn.Module):
    def __init__(
        self,
        width: int,
        n_heads: int,
        mlp_ratio: int,
        dropout: float,
        *,
        use_rope: bool = True,
    ) -> None:
        super().__init__()
        self.attention_norm = RMSNorm(width)
        self.attention = CausalSelfAttention(
            width, n_heads, dropout, use_rope=use_rope
        )
        self.mlp_norm = RMSNorm(width)
        self.mlp = MLP(width, mlp_ratio, dropout)
        self.residual_dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x + self.residual_dropout(self.attention(self.attention_norm(x)))
        x = x + self.residual_dropout(self.mlp(self.mlp_norm(x)))
        return x


class TorchPostNormBlock(nn.Module):
    """PyTorch reference-style post-LayerNorm encoder block.

    This intentionally keeps TransformerEncoderLayer defaults that differ
    from the Nano block: biased projections, ReLU, LayerNorm, and post-norm.
    It is an Oracle diagnostic component, not a proposed production block.
    """

    def __init__(
        self,
        width: int,
        n_heads: int,
        mlp_ratio: int,
        dropout: float,
    ) -> None:
        super().__init__()
        self.layer = nn.TransformerEncoderLayer(
            width,
            n_heads,
            dim_feedforward=mlp_ratio * width,
            dropout=dropout,
            activation="relu",
            batch_first=True,
            norm_first=False,
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        length = x.shape[1]
        causal_mask = torch.triu(
            torch.ones(length, length, device=x.device, dtype=torch.bool),
            diagonal=1,
        )
        return self.layer(x, src_mask=causal_mask)


class DirectionalBridge(nn.Module):
    def __init__(self, width: int, rank: int) -> None:
        super().__init__()
        self.down = initialize_linear(
            nn.Linear(width, rank, bias=False)
        )
        self.up = nn.Linear(rank, width, bias=False)
        nn.init.zeros_(self.up.weight)

    def forward(self, source: torch.Tensor) -> torch.Tensor:
        return self.up(F.silu(self.down(source)))


class CallosumBridge(nn.Module):
    def __init__(self, width: int, rank: int) -> None:
        super().__init__()
        self.left_source_norm = RMSNorm(width)
        self.right_source_norm = RMSNorm(width)
        self.left_to_right = DirectionalBridge(width, rank)
        self.right_to_left = DirectionalBridge(width, rank)
        self.enabled = True

    def messages(
        self, left: torch.Tensor, right: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Return synchronous (to-left, to-right) messages."""
        left_message = self.right_to_left(self.right_source_norm(right))
        right_message = self.left_to_right(self.left_source_norm(left))
        return left_message, right_message

    def forward(
        self, left: torch.Tensor, right: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        if not self.enabled:
            return left, right
        # Both messages are computed from the pre-communication states.
        left_message, right_message = self.messages(left, right)
        return left + left_message, right + right_message


class TwinLayer(nn.Module):
    def __init__(self, config: ModelConfig) -> None:
        super().__init__()
        width = config.branch_width
        if config.c1_block_style == "torch-post-ln":
            block = TorchPostNormBlock
            self.left = block(
                width,
                config.effective_branch_heads,
                config.mlp_ratio,
                config.dropout,
            )
            self.right = block(
                width,
                config.effective_branch_heads,
                config.mlp_ratio,
                config.dropout,
            )
        else:
            self.left = TransformerBlock(
                width,
                config.effective_branch_heads,
                config.mlp_ratio,
                config.dropout,
                use_rope=config.position_encoding == "rope",
            )
            self.right = TransformerBlock(
                width,
                config.effective_branch_heads,
                config.mlp_ratio,
                config.dropout,
                use_rope=config.position_encoding == "rope",
            )
        self.bridge: CallosumBridge | None = None

    def forward(
        self, left: torch.Tensor, right: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        left = self.left(left)
        right = self.right(right)
        if self.bridge is not None:
            left, right = self.bridge(left, right)
        return left, right


class TokenInterface(nn.Module):
    def __init__(
        self, vocab_size: int, width: int, *, torch_default_init: bool = False
    ) -> None:
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, width)
        if not torch_default_init:
            nn.init.normal_(self.embedding.weight, mean=0.0, std=0.02)

    def embed(self, tokens: torch.Tensor) -> torch.Tensor:
        return self.embedding(tokens)

    def logits(self, state: torch.Tensor) -> torch.Tensor:
        return F.linear(state, self.embedding.weight)


class LearnedPositionInterface(nn.Module):
    """Learned absolute positions in the shared token-interface space."""

    def __init__(
        self,
        context_length: int,
        width: int,
        *,
        torch_default_init: bool = False,
    ) -> None:
        super().__init__()
        self.embedding = nn.Embedding(context_length, width)
        if not torch_default_init:
            nn.init.normal_(self.embedding.weight, mean=0.0, std=0.02)

    def forward(self, embedded: torch.Tensor) -> torch.Tensor:
        positions = torch.arange(
            embedded.shape[1], device=embedded.device
        )
        return embedded + self.embedding(positions)[None, :, :]


@dataclass
class C1ModelOutput:
    logits: torch.Tensor
    loss: torch.Tensor
    metrics: dict[str, torch.Tensor]
    aux: dict[str, object] = field(default_factory=dict)


class NarrowDenseTransformer(nn.Module):
    def __init__(self, config: ModelConfig) -> None:
        super().__init__()
        config.validate()
        width = config.dense_width
        self.config = config
        self.token_interface = TokenInterface(
            config.vocab_size, config.interface_width
        )
        self.position_interface = (
            LearnedPositionInterface(
                config.context_length, config.interface_width
            )
            if config.position_encoding == "learned"
            else None
        )
        self.input_adapter = initialize_linear(
            nn.Linear(config.interface_width, width, bias=False)
        )
        self.layers = nn.ModuleList(
            [
                TransformerBlock(
                    width,
                    config.effective_dense_heads,
                    config.mlp_ratio,
                    config.dropout,
                    use_rope=config.position_encoding == "rope",
                )
                for _ in range(config.n_layers)
            ]
        )
        self.final_norm = RMSNorm(width)
        self.output_adapter = initialize_linear(
            nn.Linear(width, config.interface_width, bias=False)
        )

    def forward(
        self, tokens: torch.Tensor, targets: torch.Tensor | None = None
    ) -> tuple[torch.Tensor, torch.Tensor | None]:
        if tokens.shape[1] > self.config.context_length:
            raise ValueError("sequence exceeds configured context length")
        embedded = self.token_interface.embed(tokens)
        if self.position_interface is not None:
            embedded = self.position_interface(embedded)
        x = self.input_adapter(embedded)
        for layer in self.layers:
            x = layer(x)
        state = self.output_adapter(self.final_norm(x))
        logits = self.token_interface.logits(state)
        loss = language_model_loss(logits, targets)
        return logits, loss


class TwinTransformer(nn.Module):
    def __init__(self, config: ModelConfig) -> None:
        super().__init__()
        config.validate()
        width = config.branch_width
        self.config = config
        direct_input = config.c1_input_style == "direct-default"
        self.token_interface = TokenInterface(
            config.vocab_size,
            config.interface_width,
            torch_default_init=direct_input,
        )
        self.position_interface = (
            LearnedPositionInterface(
                config.context_length,
                config.interface_width,
                torch_default_init=direct_input,
            )
            if config.position_encoding == "learned"
            else None
        )
        if direct_input:
            self.left_input = nn.Identity()
            self.right_input = nn.Identity()
        else:
            self.left_input = initialize_linear(
                nn.Linear(config.interface_width, width, bias=False)
            )
            self.right_input = initialize_linear(
                nn.Linear(config.interface_width, width, bias=False)
            )
        self.layers = nn.ModuleList(
            [
                TwinLayer(config)
                for _ in range(config.n_layers)
            ]
        )
        if config.c1_block_style == "torch-post-ln" and len(self.layers) > 1:
            # nn.TransformerEncoder deep-copies one initialized layer. Mirror
            # that initial symmetry independently for each Twin branch.
            left_state = self.layers[0].left.state_dict()
            right_state = self.layers[0].right.state_dict()
            for layer in self.layers[1:]:
                layer.left.load_state_dict(left_state)
                layer.right.load_state_dict(right_state)
        self.final_norm = RMSNorm(2 * width)
        self.output_adapter = initialize_linear(
            nn.Linear(2 * width, config.interface_width, bias=False)
        )
        if config.c1_heads:
            # All C1 heads are constructed for every condition, including
            # no-job controls, so paired seeds consume identical RNG before
            # a Callosum bridge is added.
            if config.c1_head_style == "separate-rms":
                self.code_norm = RMSNorm(width)
                self.code_head = initialize_linear(
                    nn.Linear(width, config.c1_answer_classes, bias=False)
                )
                self.value_norm = RMSNorm(width)
                self.value_head = initialize_linear(
                    nn.Linear(width, config.c1_answer_classes, bias=False)
                )
            else:
                # ref2 applies one ordinary biased vocabulary projection to
                # the unnormalised final state, then slices the legal code and
                # value rows before CE. The slice means this is *not* a
                # full-vocabulary softmax; the diagnostic changes the readout
                # normalisation/initialisation bundle, not the opponent set.
                self.c1_shared_head = nn.Linear(
                    width, config.vocab_size, bias=True
                )
                self.job_norm = RMSNorm(width)
            self.job_head = initialize_linear(
                nn.Linear(width, config.vocab_size, bias=False)
            )
        # Build every shared/base parameter before bridges consume RNG. With the
        # same seed, no-comm and Callosum now have bit-identical common weights.
        if config.variant == "twin-callosum":
            for layer in self.layers:
                layer.bridge = CallosumBridge(width, config.callosum_rank)

    def forward(
        self, tokens: torch.Tensor, targets: torch.Tensor | None = None
    ) -> tuple[torch.Tensor, torch.Tensor | None]:
        if tokens.shape[1] > self.config.context_length:
            raise ValueError("sequence exceeds configured context length")
        embedded = self.token_interface.embed(tokens)
        if self.position_interface is not None:
            embedded = self.position_interface(embedded)
        left = self.left_input(embedded)
        right = self.right_input(embedded)
        for layer in self.layers:
            left, right = layer(left, right)
        joined = self.final_norm(torch.cat((left, right), dim=-1))
        state = self.output_adapter(joined)
        logits = self.token_interface.logits(state)
        loss = language_model_loss(logits, targets)
        return logits, loss

    def set_bridge_enabled(self, enabled: bool) -> None:
        for layer in self.layers:
            if layer.bridge is not None:
                layer.bridge.enabled = enabled

    def c1_head_logits(
        self,
        *,
        left_tokens: torch.Tensor,
        right_tokens: torch.Tensor,
        collect_bridge_messages: bool = False,
    ) -> dict[str, object]:
        """Run the two causal streams and expose the left-only C1 heads."""
        if not self.config.c1_heads:
            raise RuntimeError("C1 heads are disabled in this model configuration")
        if left_tokens.shape != right_tokens.shape:
            raise ValueError("left and right C1 views must have identical shapes")
        if left_tokens.shape[1] > self.config.context_length:
            raise ValueError("sequence exceeds configured context length")

        left_embedded = self.token_interface.embed(left_tokens)
        right_embedded = self.token_interface.embed(right_tokens)
        if self.position_interface is not None:
            left_embedded = self.position_interface(left_embedded)
            right_embedded = self.position_interface(right_embedded)
        left = self.left_input(left_embedded)
        right = self.right_input(right_embedded)
        bridge_messages: list[dict[str, torch.Tensor]] = []
        for layer in self.layers:
            left = layer.left(left)
            right = layer.right(right)
            if layer.bridge is not None and layer.bridge.enabled:
                to_left, to_right = layer.bridge.messages(left, right)
                if collect_bridge_messages:
                    bridge_messages.append(
                        {"to_left": to_left, "to_right": to_right}
                    )
                left, right = left + to_left, right + to_right

        if self.config.c1_head_style == "shared-vocab-plain":
            shared_logits = self.c1_shared_head(left)
            classes = self.config.c1_answer_classes
            code_logits = shared_logits[..., 64 : 64 + classes]
            value_logits = shared_logits[..., 128 : 128 + classes]
        else:
            code_logits = self.code_head(self.code_norm(left))
            value_logits = self.value_head(self.value_norm(left))

        return {
            "left_state": left,
            "right_state": right,
            "code_logits": code_logits,
            "value_logits": value_logits,
            "bridge_messages": bridge_messages,
        }

    def forward_c1(
        self,
        tokens: torch.Tensor,
        targets: torch.Tensor,
        *,
        left_tokens: torch.Tensor,
        right_tokens: torch.Tensor,
        answer_mask: torch.Tensor | None = None,
        code_mask: torch.Tensor | None = None,
        value_mask: torch.Tensor | None = None,
        b_fact_mask: torch.Tensor | None = None,
        use_bridge_job: bool = False,
        job_lambda: float = 0.1,
        full_lm_lambda: float = 1.0,
        collect_bridge_messages: bool = False,
        return_answer_logits: bool = False,
    ) -> C1ModelOutput:
        """C1 assay with left-only code and value decision heads."""
        if value_mask is None:
            value_mask = answer_mask
        if value_mask is None:
            raise ValueError("value_mask or answer_mask is required")

        head_output = self.c1_head_logits(
            left_tokens=left_tokens,
            right_tokens=right_tokens,
            collect_bridge_messages=collect_bridge_messages,
        )
        left = head_output["left_state"]
        right = head_output["right_state"]
        assert isinstance(left, torch.Tensor)
        assert isinstance(right, torch.Tensor)

        joined = self.final_norm(torch.cat((left, right), dim=-1))
        logits = self.token_interface.logits(self.output_adapter(joined))
        full_lm_loss = language_model_loss(logits, targets)
        assert full_lm_loss is not None

        value_logits = head_output["value_logits"]
        assert isinstance(value_logits, torch.Tensor)
        value_targets = targets[value_mask] - 128
        if value_targets.numel() == 0:
            raise ValueError("value_mask must select at least one target")
        if not bool(
            (
                (0 <= value_targets)
                & (value_targets < self.config.c1_answer_classes)
            ).all()
        ):
            raise ValueError(
                "C1 value targets exceed configured answer classes"
            )
        selected_value_logits = value_logits[value_mask]
        value_losses = F.cross_entropy(
            selected_value_logits, value_targets, reduction="none"
        )
        value_nll = value_losses.mean()
        total_loss = full_lm_lambda * full_lm_loss + value_nll
        metrics = {
            "full_lm_loss": full_lm_loss.detach(),
            "value_nll_sum": value_losses.sum().detach(),
            "value_tokens": torch.tensor(
                value_targets.numel(), device=tokens.device
            ),
            "value_correct": (
                selected_value_logits.argmax(dim=-1) == value_targets
            ).sum().detach(),
        }
        # Compatibility aliases used by the v1.1/v1.2 training harness.
        metrics["answer_nll_sum"] = metrics["value_nll_sum"]
        metrics["answer_tokens"] = metrics["value_tokens"]
        metrics["answer_correct"] = metrics["value_correct"]

        code_logits = head_output["code_logits"]
        assert isinstance(code_logits, torch.Tensor)
        if code_mask is not None and bool(code_mask.any()):
            code_targets = targets[code_mask] - 64
            if not bool(
                (
                    (0 <= code_targets)
                    & (code_targets < self.config.c1_answer_classes)
                ).all()
            ):
                raise ValueError(
                    "C1 code targets exceed configured answer classes"
                )
            selected_code_logits = code_logits[code_mask]
            code_losses = F.cross_entropy(
                selected_code_logits, code_targets, reduction="none"
            )
            total_loss = total_loss + code_losses.mean()
            metrics.update(
                {
                    "code_nll_sum": code_losses.sum().detach(),
                    "code_tokens": torch.tensor(
                        code_targets.numel(), device=tokens.device
                    ),
                    "code_correct": (
                        selected_code_logits.argmax(dim=-1) == code_targets
                    ).sum().detach(),
                }
            )

        if use_bridge_job:
            if b_fact_mask is None or not bool(b_fact_mask.any()):
                raise ValueError("bridge job requires a non-empty b_fact_mask")
            job_state = (
                self.job_norm(left)
                if self.config.c1_head_style == "shared-vocab-plain"
                else self.value_norm(left)
            )
            job_logits = self.job_head(job_state)
            bridge_job_ce = F.cross_entropy(
                job_logits[b_fact_mask], tokens[b_fact_mask]
            )
            total_loss = total_loss + job_lambda * bridge_job_ce
            metrics["bridge_job_ce"] = bridge_job_ce.detach()

        aux: dict[str, object] = {}
        if collect_bridge_messages:
            aux = {
                "bridge_messages": head_output["bridge_messages"],
                "left_state": left,
                "right_state": right,
                "code_logits": code_logits,
                "value_logits": value_logits,
                "answer_logits": value_logits,
            }
        elif return_answer_logits:
            aux = {
                "code_logits": code_logits,
                "value_logits": value_logits,
                "answer_logits": value_logits,
            }
        return C1ModelOutput(logits, total_loss, metrics, aux)


def language_model_loss(
    logits: torch.Tensor, targets: torch.Tensor | None
) -> torch.Tensor | None:
    if targets is None:
        return None
    return F.cross_entropy(
        logits.reshape(-1, logits.shape[-1]),
        targets.reshape(-1),
    )


def build_model(config: ModelConfig) -> nn.Module:
    if config.variant in {"narrow-dense", "wide-dense"}:
        return NarrowDenseTransformer(config)
    if config.variant in {"twin-no-comm", "twin-callosum"}:
        return TwinTransformer(config)
    raise ValueError(f"unknown variant: {config.variant}")


def count_parameters(model: nn.Module) -> int:
    return sum(parameter.numel() for parameter in model.parameters())
