from __future__ import annotations

import argparse
import csv
import json
import statistics
from dataclasses import replace
from pathlib import Path
from typing import Any

from .budget import model_budget
from .config import ExperimentConfig, ModelConfig
from .data import make_synthetic_corpus, read_corpus
from .train import train_one

BASE_VARIANTS = ("narrow-dense", "twin-no-comm", "twin-callosum")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run Callosum Nano comparison")
    parser.add_argument("--output", type=Path, default=Path("runs"))
    parser.add_argument("--train-file", type=Path)
    parser.add_argument("--valid-file", type=Path)
    parser.add_argument("--steps", type=int, default=2_000)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--context-length", type=int, default=128)
    parser.add_argument("--eval-interval", type=int, default=100)
    parser.add_argument("--eval-batches", type=int, default=20)
    parser.add_argument("--learning-rate", type=float, default=3e-4)
    parser.add_argument("--weight-decay", type=float, default=0.1)
    parser.add_argument("--grad-clip", type=float, default=1.0)
    parser.add_argument("--device", default="auto")
    parser.add_argument("--seeds", type=int, nargs="+", default=[1])
    parser.add_argument("--layers", type=int, default=4)
    parser.add_argument("--heads", type=int, default=3)
    parser.add_argument("--dense-heads", type=int)
    parser.add_argument("--branch-heads", type=int)
    parser.add_argument("--branch-width", type=int, default=48)
    parser.add_argument("--dense-width", type=int)
    parser.add_argument("--wide-dense-width", type=int)
    parser.add_argument("--include-wide-dense", action="store_true")
    parser.add_argument("--callosum-rank", type=int, default=8)
    parser.add_argument("--interface-width", type=int, default=64)
    parser.add_argument("--mlp-ratio", type=int, default=4)
    parser.add_argument("--dropout", type=float, default=0.0)
    parser.add_argument("--warmup-steps", type=int, default=100)
    parser.add_argument("--lr-decay-steps", type=int)
    parser.add_argument("--min-lr-ratio", type=float, default=0.1)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--synthetic-records", type=int, default=20_000)
    return parser.parse_args()


def load_data(args: argparse.Namespace) -> tuple[bytes, bytes]:
    if bool(args.train_file) != bool(args.valid_file):
        raise ValueError("--train-file and --valid-file must be supplied together")
    if args.train_file:
        return read_corpus(args.train_file), read_corpus(args.valid_file)
    return (
        make_synthetic_corpus(args.synthetic_records, seed=73),
        make_synthetic_corpus(max(2_000, args.synthetic_records // 10), seed=91),
    )


def aggregate(
    results: list[dict[str, Any]], variants: tuple[str, ...]
) -> dict[str, Any]:
    grouped: dict[str, list[dict[str, Any]]] = {
        variant: [] for variant in variants
    }
    for result in results:
        grouped[result["model"]["variant"]].append(result)

    summary: dict[str, Any] = {}
    for variant, runs in grouped.items():
        losses = [run["best_validation_loss"] for run in runs]
        bpbs = [run["best_validation_bpb"] for run in runs]
        summary[variant] = {
            "runs": len(runs),
            "mean_best_validation_loss": statistics.mean(losses),
            "std_best_validation_loss": (
                statistics.stdev(losses) if len(losses) > 1 else 0.0
            ),
            "mean_best_validation_bpb": statistics.mean(bpbs),
            "parameters": runs[0]["parameters"],
        }
    return summary


def write_csv(path: Path, results: list[dict[str, Any]]) -> None:
    fields = (
        "variant",
        "seed",
        "parameters",
        "best_step",
        "best_validation_loss",
        "best_validation_bpb",
        "elapsed_seconds",
    )
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for result in results:
            writer.writerow(
                {
                    "variant": result["model"]["variant"],
                    "seed": result["experiment"]["seed"],
                    **{field: result[field] for field in fields[2:]},
                }
            )


def main() -> None:
    args = parse_args()
    train_bytes, valid_bytes = load_data(args)
    args.output.mkdir(parents=True, exist_ok=True)
    variants = (
        ("narrow-dense", "wide-dense", "twin-no-comm", "twin-callosum")
        if args.include_wide_dense
        else BASE_VARIANTS
    )

    base_model = ModelConfig(
        variant="narrow-dense",
        context_length=args.context_length,
        n_layers=args.layers,
        n_heads=args.heads,
        dense_heads=args.dense_heads,
        branch_heads=args.branch_heads,
        branch_width=args.branch_width,
        dense_width_override=args.dense_width,
        wide_dense_width_override=args.wide_dense_width,
        callosum_rank=args.callosum_rank,
        interface_width=args.interface_width,
        mlp_ratio=args.mlp_ratio,
        dropout=args.dropout,
    )
    base_experiment = ExperimentConfig(
        steps=args.steps,
        batch_size=args.batch_size,
        learning_rate=args.learning_rate,
        warmup_steps=args.warmup_steps,
        lr_decay_steps=args.lr_decay_steps,
        min_lr_ratio=args.min_lr_ratio,
        weight_decay=args.weight_decay,
        grad_clip=args.grad_clip,
        eval_interval=args.eval_interval,
        eval_batches=args.eval_batches,
        seed=args.seeds[0],
        device=args.device,
        synthetic_records=args.synthetic_records,
    )

    analytical_budgets = {
        variant: model_budget(
            variant,
            vocab_size=base_model.vocab_size,
            interface_width=base_model.interface_width,
            n_layers=base_model.n_layers,
            branch_width=base_model.branch_width,
            callosum_rank=base_model.callosum_rank,
            mlp_ratio=base_model.mlp_ratio,
            context_length=base_model.context_length,
            dense_width=base_model.dense_width,
            wide_dense_width=(
                base_model.wide_dense_width_override
                or 2 * base_model.branch_width
            ),
        ).to_dict()
        for variant in variants
    }
    print(json.dumps({"analytical_budgets": analytical_budgets}, indent=2))

    results: list[dict[str, Any]] = []
    for seed in args.seeds:
        for variant in variants:
            model_config = replace(base_model, variant=variant)
            experiment = replace(base_experiment, seed=seed)
            run_dir = args.output / variant / f"seed-{seed}"
            results.append(
                train_one(
                    model_config,
                    experiment,
                    train_bytes,
                    valid_bytes,
                    run_dir,
                    resume=args.resume,
                )
            )

    output = {
        "analytical_budgets": analytical_budgets,
        "aggregate": aggregate(results, variants),
        "runs": results,
    }
    (args.output / "summary.json").write_text(
        json.dumps(output, indent=2, sort_keys=True),
        encoding="utf-8",
    )
    write_csv(args.output / "summary.csv", results)
    print(json.dumps(output["aggregate"], indent=2))


if __name__ == "__main__":
    main()
