#!/usr/bin/env bash
set -euo pipefail

output_root="${1:-runs-c1-v0.1.9-logging-smoke}"
device="${2:-cpu}"

if [[ -e "$output_root" ]]; then
  echo "refusing to mix with existing output: $output_root" >&2
  exit 2
fi

python -m pytest -q
python -m callosum_nano.c1_compare \
  --output "$output_root" \
  --steps 20 --batch-size 8 --eval-interval 10 \
  --validation-episodes 64 \
  --learning-rate 3e-3 --warmup-steps 2 \
  --lr-decay-steps 20 --min-lr-ratio 1.0 \
  --full-lm-lambda 1.0 --weight-decay 0 \
  --layers 2 --heads 2 --branch-width 64 \
  --position-encoding learned --id-count 64 \
  --seeds 1 --conditions oracle-left \
  --assay-label C1-v0.1.9-logging-smoke \
  --device "$device"

python - "$output_root/oracle-left/seed-1/logging_audit.json" <<'PY'
import json
import sys

path = sys.argv[1]
audit = json.load(open(path, encoding="utf-8"))
assert audit["train_curve"]["required_new_steps"] == 20
assert audit["train_curve"]["records"] == 20
assert audit["metrics"]["required_new_steps"] == 3
assert audit["metrics"]["records"] == 3
assert audit["train_curve"]["nul_holes"] == 0
assert audit["metrics"]["malformed_records"] == 0
print("logging smoke OK:", json.dumps(audit, sort_keys=True))
PY
