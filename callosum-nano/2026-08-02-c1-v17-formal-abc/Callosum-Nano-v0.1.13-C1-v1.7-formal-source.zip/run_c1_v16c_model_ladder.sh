#!/usr/bin/env bash
set -euo pipefail

output_root="${1:-runs-c1-v1.6c-model-ladder}"
device="${2:-cpu}"

if [[ -e "$output_root" ]]; then
  echo "refusing to mix with existing output: $output_root" >&2
  exit 2
fi

python -m pytest -q

common=(
  --steps 4000
  --batch-size 64
  --eval-interval 200
  --validation-episodes 1024
  --learning-rate 3e-3
  --warmup-steps 1
  --lr-decay-steps 4000
  --min-lr-ratio 1.0
  --weight-decay 0
  --grad-clip 1.0
  --full-lm-lambda 0.0
  --data-mode chain-two-hop
  --filler-mode random
  --id-count 16
  --layers 2
  --heads 2
  --branch-width 64
  --interface-width 64
  --position-encoding learned
  --c1-head-style shared-vocab-plain
  --seeds 1 2
  --conditions oracle-left
  --device "$device"
)

run_cell() {
  local cell="$1"
  local block_style="$2"
  local input_style="$3"
  echo "===== C1-v1.6c CELL $cell ====="
  python -m callosum_nano.c1_compare \
    --output "$output_root/$cell" \
    --assay-label "C1-v1.6c-$cell" \
    --c1-block-style "$block_style" \
    --c1-input-style "$input_style" \
    "${common[@]}"
}

run_cell BLOCK torch-post-ln nano-adapter
run_cell INPUT nano-pre-rms direct-default
run_cell BOTH torch-post-ln direct-default

python - "$output_root" <<'PY'
import json
import pathlib
import sys

root = pathlib.Path(sys.argv[1])
cells = {}
for cell in ("BLOCK", "INPUT", "BOTH"):
    summary = json.load(open(root / cell / "summary.json", encoding="utf-8"))
    rows = []
    for result in summary["results"]:
        endpoint = result["endpoint_validation"]
        passed = (
            endpoint["free_code_acc"] >= 0.90
            and endpoint["free_v_given4_acc"] >= 0.90
            and endpoint["free_chain_exact_acc"] >= 0.90
        )
        rows.append(
            {
                "seed": result["train"]["seed"],
                "endpoint_step": result["endpoint_step"],
                "free_code_acc": endpoint["free_code_acc"],
                "free_v_given4_acc": endpoint["free_v_given4_acc"],
                "free_chain_exact_acc": endpoint["free_chain_exact_acc"],
                "passed": passed,
            }
        )
    cells[cell] = {
        "passed": len(rows) == 2 and all(row["passed"] for row in rows),
        "seeds": rows,
    }

block = cells["BLOCK"]["passed"]
input_passed = cells["INPUT"]["passed"]
both = cells["BOTH"]["passed"]
if not both:
    interpretation = "internal positive bridge failed; no block/input attribution"
elif block and not input_passed:
    interpretation = "block bundle alone is sufficient"
elif input_passed and not block:
    interpretation = "input/adapter-scale bundle alone is sufficient"
elif not block and not input_passed:
    interpretation = "block and input bundles require an interaction"
else:
    interpretation = "each bundle is independently sufficient"

ladder = {
    "rule": "each cell requires both seeds endpoint free_code/free_v_given4/free_chain_exact >= 0.90",
    "cells": cells,
    "interpretation": interpretation,
}
with open(root / "ladder_gate.json", "w", encoding="utf-8") as handle:
    json.dump(ladder, handle, indent=2, sort_keys=True)
print(json.dumps(ladder, indent=2, sort_keys=True))
raise SystemExit(0 if both else 3)
PY

