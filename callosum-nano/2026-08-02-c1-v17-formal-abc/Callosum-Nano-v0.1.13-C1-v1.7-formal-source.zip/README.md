# Callosum Nano

一个尽量小、尽量干净的实验：比较窄 Dense Transformer 与两个半宽、
权重独立、只通过低秩“胼胝体”通信的 Twin Transformer。

核心问题不是“两条流能不能工作”，而是：

> 在 Transformer 主干参数量和计算量接近时，两个局部全连接的半宽流，
> 加上窄通信通道，能否优于一个全连接的窄 Dense 流？

## 默认对照

| 变体 | 隐状态 | 分支通信 | 用途 |
| --- | ---: | --- | --- |
| `narrow-dense` | 自动匹配，默认 69 | 不适用 | 公平预算基线 |
| `wide-dense` | 默认 96 | 不适用 | 完整同宽 Dense 上界 |
| `twin-no-comm` | 48 + 48 | 无 | 检验“双流本身” |
| `twin-callosum` | 48 + 48 | 每层双向 rank 8 | 主实验 |

默认 4 层、3 heads、MLP ratio 4。69 维不是拍脑袋选的：
程序会搜索使 Dense 主干参数最接近 Twin + Callosum 主干参数的整数宽度。
所有 attention 都使用无参数 RoPE；当 head dimension 为奇数时，最后一维
保持不旋转，因此默认 Dense 的 23 维 head 旋转前 22 维。

每层通信是同步、逐 token、保持因果性的：

```text
left'  = left  + Up_RL(SiLU(Down_RL(Norm(right))))
right' = right + Up_LR(SiLU(Down_LR(Norm(left))))
```

两个 `Up` 矩阵零初始化，因此 Callosum 模型从严格等价于
`twin-no-comm` 的函数开始训练，而不是一开始就互相注入随机噪声。
构造顺序保证相同 seed 下两者所有公共权重逐位相同；embedding 和 linear
权重显式使用 `std=0.02` 初始化，避免 tied output embedding 产生过大 logits。

## 公平性边界

- 两个 Twin 分支的 attention、MLP、归一化和通信方向权重完全独立。
- 三个模型都用 byte-level 词表和一个共享 token-interface embedding。
- Twin 的左右输入投影独立，输出前才拼接并映射回共享 token interface。
- 宽度匹配计入 attention/MLP 投影参数、RMSNorm 和低秩通信。
- 总参数量也会报告；由于整数宽度及输入/输出 adapter，不可能完全相等。
- 完整 attention 还有 `T²·d` 项；默认 context 128 时 Callosum 的估算
  前向 MACs 比 Dense 高约 9.2%，因此首轮是近似等参数而非严格等算力。
- `twin-no-comm` 是消融，不额外塞“无用参数”假装匹配 Callosum。

## 安装与运行

需要 Python 3.10+ 和 PyTorch 2.2+。

```bash
python -m pip install -e ".[dev]"
python -m pytest
```

先做 20 步 smoke run：

```bash
python -m callosum_nano.compare \
  --steps 20 --eval-interval 10 --eval-batches 4 \
  --batch-size 8 --context-length 64
```

正式一点的 CPU 小实验：

```bash
python -m callosum_nano.compare \
  --steps 2000 --eval-interval 100 --eval-batches 20 \
  --batch-size 32 --context-length 128 \
  --seeds 1 2 3
```

使用自己的 UTF-8/任意二进制文本（tokenizer 直接读取 bytes）：

```bash
python -m callosum_nano.compare \
  --train-file data/train.txt \
  --valid-file data/valid.txt \
  --steps 5000 --seeds 1 2 3
```

控制 Dense/Twin 的总 attention head 数：

```bash
python -m callosum_nano.compare \
  --dense-width 72 --dense-heads 6 --branch-heads 3 \
  --steps 300 --seeds 1 2 3
```

这里 Dense 有 6 heads；Twin 每支 3 heads、总计也是 6 heads。
`--dense-width` 允许故意给 Dense 更多参数，构造偏袒 Dense 的保守对照。

加入与两个分支总宽相同的完整 Dense、使用 warmup + cosine decay，并保存可精确续训的状态：

```bash
python -m callosum_nano.compare \
  --output runs-formal \
  --include-wide-dense \
  --dense-width 72 --dense-heads 6 --branch-heads 3 \
  --steps 5000 --warmup-steps 100 \
  --lr-decay-steps 5000 --min-lr-ratio 0.1 \
  --eval-interval 100 --eval-batches 20 \
  --batch-size 8 --context-length 64 --seeds 1
```

中断后用相同实验参数恢复，只需加 `--resume`；`--steps` 是新的目标总步数：

```bash
python -m callosum_nano.compare \
  --output runs-formal \
  --include-wide-dense --resume \
  --dense-width 72 --dense-heads 6 --branch-heads 3 \
  --steps 5000 --warmup-steps 100 \
  --lr-decay-steps 5000 --min-lr-ratio 0.1 \
  --eval-interval 100 --eval-batches 20 \
  --batch-size 8 --context-length 64 --seeds 1
```

只看预算：

```bash
python -m callosum_nano.budget
```

输出目录包含：

- 每个 run 的 `metrics.jsonl`
- 最优验证损失 `best.pt`
- 可精确续训的 `latest.pt`（包括优化器、数据流和 RNG 状态）
- `summary.json` 与便于画图的 `summary.csv`

比较时优先看每个 seed 的最佳 validation loss，以及三种变体的均值和标准差。
一次单 seed 的小胜不应当被视为结论。

## C1-v1.3 链式通信考场

`c1_compare` 是独立于上面 C0 byte-LM 比较的合成 assay。左支只看
`name→code`，右支只看 `code→value`。终问要求自由解码
`[Q,name]→code→value`：code 由左支生成并作为下一公共 token 写回，右支随后
按 code 检索 value；code/value 两个判决头都只读左支，因此 value 检索结果
若要到达判决位，不能借最终 concat decoder 绕过桥。

v1.3 将 context 从 64 增至 65，只追加中间 code；原有 facts、37 个 filler、
query 位置、保持距离和 RoPE 坐标均不移动。训练使用标准 teacher forcing，
正式验证则严格 greedy free-run，真 code 不进入 value 判决路径。

```bash
python -m callosum_nano.c1_compare \
  --output runs-c1-v1.3-oracle \
  --steps 5000 --batch-size 32 --eval-interval 100 \
  --lr-decay-steps 10000 --validation-episodes 4096 \
  --seeds 1 2 --conditions oracle-left
```

Oracle 两个 seeds 必须同时达到 `free_code_acc≥90%`、
`free_v_given4_acc≥90%` 和 `free_chain_exact_acc≥90%`。若 5000 步未过，
由于一开始将 cosine decay 固定为 10000，可原样精确续训：

```bash
python -m callosum_nano.c1_compare \
  --output runs-c1-v1.3-oracle --resume \
  --steps 10000 --batch-size 32 --eval-interval 100 \
  --lr-decay-steps 10000 --validation-episodes 4096 \
  --seeds 1 2 --conditions oracle-left
```

Oracle 过门后才允许显式加入 `--oracle-approved`，运行
`c1-a-no-bridge`、`c1-b-bridge` 和 `c1-c-reconstruction-job`。C 条件自动
记录关桥 C-zero；`--probe-episodes 4096` 会在最优 B/C checkpoint 上用互不
重叠的数据拟合确定性 ridge probes，比较 filler、query-name、code 三个位置的
queried-value 与 all-four-value 可解码性。

验证集固定为 4096 episodes，最优 checkpoint 按 free-run value NLL 选择；
teacher-forced value 指标只用于诊断。训练逐步轨迹写入 `train_curve.jsonl`。

当前 frozen v1.1 在启动 A/B/C 前触发了 Oracle 熔断：5000-step Oracle
只达到 12.52% accuracy，证明任务可部分学习但未可靠解决。因此该结果不能
用来判断桥或重建作业。详见 `C1-v1.1-ORACLE-REPORT.md`。

C1-v1.2 的两轮 Oracle 校准也已完成：先将 ID/value 池降至 16，再将
37 个随机 filler 换为固定 filler、保持序列距离不变。两轮各 2 seeds、
5000 steps，`given4_acc` 都保持约 25%。固定 filler 条件下，模型的 top-1
几乎 100% 属于 episode 的四个 value，却仍四选一随机，因而 A/B/C 继续
冻结。详见 `C1-v1.2-CALIBRATION-REPORT.md`。

战报 6 进一步表明，旧考场叠加了“随机符号绑定”与“单次前向内两跳组合”
两层困难：单跳技能满分仍不能让茶杯 Transformer 在直答格式中组合，而把
中间 code 外化后可迅速满分。因此 v1.3 用链式答案校准通信考场；无外化时的
内化组合能力留给 C2 预测环实验。

C1-v1.3 正式 Oracle 最终原样续训至 10000 steps，两个 seeds 的 free-code
仅为 23.80% / 20.39%，value-given4 为 25.34% / 25.00%，chain-exact 为
4.81% / 3.86%，三重门控全部失败。A/B/C 仍冻结。下一步是预注册的
学习率 `3e-4/3e-3` × full-LM λ `1/0` 诊断，区分优化预算与辅助损失干扰；
详见 `C1-v1.3-ORACLE-REPORT.md` 与 `C1-v1.4-DIAGNOSTIC.md`。

C1-v1.4 的四个 step-2000 endpoint 全部未达到绑定逃逸门槛；10 倍学习率与
移除 full-LM 都不足以救活 Oracle。full-LM 没有表现为干扰，反而对 value 与
chain 有单 seed 的帮助趋势。正式判词见 `C1-v1.4-DIAGNOSTIC-REPORT.md`。

下一炉 C1-v1.5 只做模型侧仪器诊断：weight decay、width/head 布局与 learned
absolute position 三个单因素格，加一个近似猫盆模型的组合阳性控制。新增
`--position-encoding {rope,learned}`；诊断脚本为
`run_c1_v15_structural.sh`。Oracle 通过双 seed 正式复验前，A/B/C 仍冻结。

v1.5 五格在 step 2000 全部未逃逸，但 K3 随后发现其“64 IDs 在 2000 步
成功相变”的预算对照存在标签/复现问题。进一步审计又发现附带的 N16 验证脚本
实际仍把 `NID=64` 写死，且 reference generator 与 C1Stream 的 unique IDs / B
permutation 语义不同。因此结构归因与 v1.6 LONG 均暂停，先完成精确复现对账。
详见 `C1-v1.5-EVIDENCE-AUDIT.md`。

v0.1.9 同时修复共享挂载上的稀疏 NUL 日志洞：C1 曲线改为 checkpoint 边界的
原子 ledger 替换，并生成强制 `logging_audit.json`。短验证入口为
`run_c1_v019_logging_smoke.sh`。

v0.1.10 增加仅用于 Oracle 结构诊断的
`--c1-head-style shared-vocab-plain`：它像 ref2 一样用一个带 bias、默认初始化的
256 行 Linear 直接读取左支状态，再切出合法 code/value 行。由于 CE 在切片后
计算，这不是“全词表 softmax”；它同时诊断 head RMSNorm、初始化/bias 与参数
容器组成的 readout bundle。正式 C1 默认仍为 `separate-rms`。

v0.1.11 增加 C1 Oracle 模型梯子开关：
`--c1-block-style {nano-pre-rms,torch-post-ln}` 与
`--c1-input-style {nano-adapter,direct-default}`。它们只用于把 Nano 与 ref2 的
block family 和输入尺度/adapter 差异做 2×2 诊断；默认值保持原模型不变。
冻结运行单见 `C1-v1.6c-MODEL-LADDER.md`。
