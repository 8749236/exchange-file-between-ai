#!/usr/bin/env bash
set -euo pipefail

output_root="${1:-runs-c1-v1.5-structural}"
device="${2:-cpu}"

if [[ -e "$output_root" ]]; then
  echo "refusing to mix with existing output: $output_root" >&2
  exit 2
fi

python -m pytest -q

common=(
  --steps 2000
  --batch-size 32
  --eval-interval 200
  --validation-episodes 1024
  --warmup-steps 100
  --lr-decay-steps 2000
  --min-lr-ratio 1.0
  --full-lm-lambda 1.0
  --grad-clip 1.0
  --id-count 64
  --seeds 1
  --conditions oracle-left
  --assay-label C1-v1.5-structural-diagnostic
  --device "$device"
)

run_cell() {
  local cell="$1"
  shift
  echo "===== C1-v1.5 CELL $cell ====="
  python -m callosum_nano.c1_compare \
    --output "$output_root/$cell" \
    "${common[@]}" "$@"
}

run_cell BASE \
  --layers 4 --heads 3 --branch-width 48 \
  --position-encoding rope --weight-decay 0.1 --learning-rate 3e-4

run_cell WD0 \
  --layers 4 --heads 3 --branch-width 48 \
  --position-encoding rope --weight-decay 0.0 --learning-rate 3e-4

run_cell W64H2 \
  --layers 4 --heads 2 --branch-width 64 \
  --position-encoding rope --weight-decay 0.1 --learning-rate 3e-4

run_cell ABS \
  --layers 4 --heads 3 --branch-width 48 \
  --position-encoding learned --weight-decay 0.1 --learning-rate 3e-4

run_cell MATCH \
  --layers 2 --heads 2 --branch-width 64 \
  --position-encoding learned --weight-decay 0.0 --learning-rate 3e-3

echo "===== C1-v1.5 ALL CELLS DONE ====="

