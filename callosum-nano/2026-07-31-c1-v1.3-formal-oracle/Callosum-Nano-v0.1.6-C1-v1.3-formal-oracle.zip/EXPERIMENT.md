# Callosum Nano 实验约定

## 假设

- `H0`：在相近的 Transformer 主干参数/FLOPs 下，低秩通信的 Twin
  不优于 Narrow Dense。
- `H1`：将完整连接限制在两个半宽子空间内，再用低秩通道交换信息，
  能形成有用的结构偏置，使 Twin Callosum 的验证损失低于 Narrow Dense。

主比较是：

```text
narrow-dense  vs  twin-callosum
```

`twin-no-comm` 用于回答差异来自“双流分解”还是“跨流通信”。

## 冻结的默认架构

- layers: 4
- heads: 3
- branch width: 48
- combined Twin state: 96
- Callosum rank: 8
- matched Narrow Dense width: 69
- MLP ratio: 4
- token interface width: 64
- tokenizer: raw bytes, vocab size 256
- positional representation: RoPE（奇数 head dimension 的最后一维不旋转）

## 指标与判定

主指标为 validation bits per byte（BPB），同时记录交叉熵 loss、参数量、
达到最佳验证损失的 step 和 wall time。

最低可解释运行：

- 同一数据；
- 同一 batch 顺序；
- 同一训练步数和优化器超参数；
- 至少 3 个 seeds；
- 报告均值和标准差。

默认是近似等参数、固定训练 tokens。分析式估算在 context 128 时，
Callosum 每 token 前向 MACs 比 Narrow Dense 高约 9.2%，来源主要是
attention 的 `T²·d` 项。若主实验优势很小，应追加固定 MAC 预算复验，
不能把多出来的计算直接归功于架构。

支持 `H1` 的最低证据是：`twin-callosum` 在多数 seeds 上优于
`narrow-dense`，且均值差异大于 seed 间随机波动。若只优于
`twin-no-comm`，只能说明通信有用，不能说明结构优于 Dense。

## 当前状态

- [x] 分析式预算匹配
- [x] 三种模型实现
- [x] 零初始化双向低秩通信
- [x] 统一数据、训练、评估与汇总入口
- [x] 因果性、分支权重独立、bridge identity 测试
- [x] 加入 RoPE
- [x] v0.1.0 在 PyTorch CPU 环境完成 20-step smoke run
- [x] smoke run 发现并修正 tied embedding 尺度与配对初始化问题
- [x] v0.1.1 动态测试与 20-step smoke run
- [x] v0.1.3 5000-step × 3-seed C0 正式小实验
- [x] C1-v1.1 实现、捷径审计、固定验证与精确续训测试
- [x] C1-v1.1 5000-step Oracle；触发阳性对照熔断
- [x] C1-v1.2 16-ID × random/constant filler，2-seed Oracle 校准
- [x] 战报 6 将直答死锁分解为绑定层与内化组合层
- [x] C1-v1.3 链式 `code→value`、free-run 门控与桥位置探针实现
- [x] C1-v1.3 31 tests 与 20-step 独立动态 smoke
- [ ] C1-v1.3 双 seed 5000-step Oracle
- [ ] Oracle 双门槛通过后再运行 A/B/C

v0.1.0 的 smoke 排名不能作为架构证据，因为 Callosum bridge 的构造曾改变
后续公共权重的随机数流，且默认 embedding 初始化造成过大初始 logits。
详见 `results/smoke_v0.1.0.md`。

## C1-v1.1 熔断状态

C1 要求跨流完成 `name→code→value`，判决头仅从左支读取。冻结判读首先
要求 `oracle-left` 能可靠学会，否则整个 assay 无效；其次要求无桥 A 保持
chance，才允许比较 B（有桥无作业）与 C（有桥+重建作业）及 C-zero。

seed 1 的正式 Oracle（5000 steps、固定 4096 episodes）最佳结果为
`answer_nll=3.3028`、`answer_acc=12.52%`，相对 64 类 chance
`4.1589 / 1.56%` 是弱阳性，但未解决任务。结构探针显示模型能识别 episode
中的 value 集合，却不能依据 query 在四个候选中选择：把答案限制在四个
真实候选后 accuracy 为 25.07%，等同四选一随机。因此 A/B/C 尚未运行，
也没有桥的正负判词。

C1-v1.2 将答案类别/随机 ID 池降到 16；第一轮保留随机 filler，第二轮
仅把 filler 固定为常量，保留 37-token 距离、query 位置和 RoPE 坐标。
两轮的 `given4_acc` 在两个 seeds 上均约为 25%。固定 filler 最终令
top-1 几乎总是 episode 的四个 value 之一，但没有改善 query-conditioned
选择。降低题目难度与消除随机干扰都没有解除绑定死锁，A/B/C 仍未开放。

## C1-v1.3 冻结设计

终问改为 `[Q,name]→code→value`。code 由 left-only code head 自由生成并写回
公共 token 序列；右支据此从 B facts 检索 value，再通过 right→left bridge
把检索结果交给 left-only value head。code 本身是公共 token，不宣称过桥。

正式判决全部使用 greedy free-run。Oracle 两个 seeds 均须满足
`free_code_acc≥90%`、`free_v_given4_acc≥90%`、
`free_chain_exact_acc≥90%`；teacher-forced `v|true-code` 只作诊断。
先跑 5000 steps，同一 10000-step cosine schedule 允许原样续训至 10000；仍失败
则熔断。A 必须选择性保持 code 成功、value chance；C-zero 必须选择性摧毁
value 而保留 code。

桥探针在 filler 60、query-name 62、code 63 三个位置读取每层 right→left
message，并在独立 train/validation episodes 上拟合 ridge probe。queried-value
与 all-four-value 两组读数用于鉴别“索引服务”和“集合走私”。
