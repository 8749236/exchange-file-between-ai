# C1-D：query-conditioned shuttle（冻结）

日期：2026-08-02

## 问题

C1-v1.7 已证明普通 rank-8 桥会搬运四个 value 的集合，却没有稳定学会
`queried code -> queried value` 的绑定。C1-D 将缺失关系拆成两条可单独清零的腿：

1. 左支在位置 63 持有预测/teacher-forced code；右支同位输入为 MASK；
2. 第一层后的左→右低秩桥必须送达地址；
3. 最后一层的 assay-specific 四槽指针，在右支 B facts 的 code 槽上寻址，读取同槽
   value state；
4. 最后一层右→左低秩桥必须把取回的 value 送给左支正式答案头。

未来真值位于输入 64；位置 63 的所有状态与指针仅因果读取 0..63。指针的四类标签
由 query code 在 B-code 槽 `{13,16,19,22}` 中的唯一匹配产生，不读取 value 标签。

## 诚实边界

该模块显式提供“按 code 选择同槽 value”的可微结构。因此本炉检验的是：

> 在给定 query/retrieval 归纳偏置后，低秩双向桥能否可靠形成地址去、值回的协议，
> 以及直接地址作业是否提高该协议的跨 seed 可靠性。

它不检验普通 Transformer 是否会自发发明 binding，也不能把成功外推为通用
Transformer 架构定律。

## 条件

| cell | shuttle | 四槽地址 CE | 正式 value CE |
|---|---|---|---|
| D0 | 开 | 关 | 左答案头，开 |
| D | 开 | 开，lambda 1.0 | 左答案头，开 |

D0/D 构造完全相同的参数并使用 paired seed；唯一差异是地址 CE 是否计入总损失。

## 冻结运行规格

- chain-two-hop、N16、4 facts、random filler；
- Nano pre-RMS、direct-default、shared-vocab-plain；
- 2 layers、2 heads、branch/interface width 64、MLP ratio 4；
- 每层双向 rank-8 同步桥；不扫 rank；
- batch 64、10,000 steps、eval interval 200、fixed-valid 4,096；
- AdamW：lr 3e-3、warmup 1、constant LR、WD 0、clip 1；
- full-LM lambda 0、pointer-job lambda 1.0、seeds 1/2；
- best checkpoint 按 fixed-valid free-value NLL 机械选择；
- D0/D 保存全程轨迹与 4,096+4,096 probe；D best 做三组方向清零。

## 预注册判读

D 必须双 seed endpoint 同时满足：

- `free_code_acc >= .90`；
- `query_job_acc >= .90`（四槽地址）；
- `free_chain_exact_acc >= .90`；
- 日志 10,000/10,000 与 51/51 全绿。

D best checkpoint 的方向因果门（双 seed）：

- 左→右清零：`query_job_acc <= .30` 且 `free_v_given4_acc <= .30`；
- 右→左清零：`query_job_acc >= .90` 且 `free_value_acc <= .10`；
- 双向清零：`query_job_acc <= .30` 且 `free_value_acc <= .10`。

D0 不设成 assay 熔断，而用于区分监督必要性：

- D0 双 seed 也过：显式地址作业非必要，结构偏置已足够；
- D 过而 D0 仅部分 seed 过：地址作业提高 10k 窗口内可靠性；
- D 过而 D0 双 seed 不过：支持本配置中地址作业必要；
- D 过但方向门不过：禁止桥机制归因；
- D 双 seed不过：C1-D 失败。

校准曾在 2k/512-valid 下看到 D 双 seed 100%，D0 为 seed 1 逃逸、seed 2 停在
约四选一；该结果只用于冻结设计与窗口，不进入正式证据。

## 执行

```bash
bash run_c1_d_formal.sh runs-c1-d-formal cpu
```

脚本先跑全部测试与 autograd preflight，再成对运行 D0/D，最后 fail-closed gate。
