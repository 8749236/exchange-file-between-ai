#!/usr/bin/env bash
set -euo pipefail

output_root="${1:-runs-c1-d-formal}"
device="${2:-cpu}"

if [[ -e "$output_root" ]]; then
  echo "refusing to mix with existing output: $output_root" >&2
  exit 2
fi

mkdir -p "$output_root"
exec > >(tee "$output_root/stdout.txt") 2>&1

python -m pytest -q
python - <<'PY'
import torch
print(f"torch={torch.__version__} device_test=cpu")
x = torch.ones(4, requires_grad=True)
x.square().sum().backward()
assert x.grad is not None
print("autograd preflight OK")
PY

python -m callosum_nano.c1_compare \
  --output "$output_root" \
  --assay-label C1-D-query-conditioned-shuttle-formal \
  --conditions c1-d-shuttle-no-job c1-d-query-job \
  --steps 10000 \
  --batch-size 64 \
  --eval-interval 200 \
  --validation-episodes 4096 \
  --learning-rate 3e-3 \
  --warmup-steps 1 \
  --lr-decay-steps 10000 \
  --min-lr-ratio 1.0 \
  --weight-decay 0 \
  --grad-clip 1.0 \
  --job-lambda 1.0 \
  --full-lm-lambda 0.0 \
  --data-mode chain-two-hop \
  --filler-mode random \
  --id-count 16 \
  --probe-episodes 4096 \
  --layers 2 \
  --heads 2 \
  --branch-width 64 \
  --callosum-rank 8 \
  --interface-width 64 \
  --mlp-ratio 4 \
  --dropout 0 \
  --position-encoding learned \
  --c1-head-style shared-vocab-plain \
  --c1-block-style nano-pre-rms \
  --c1-input-style direct-default \
  --seeds 1 2 \
  --oracle-approved \
  --device "$device"

python -m callosum_nano.c1_d_gate "$output_root"
