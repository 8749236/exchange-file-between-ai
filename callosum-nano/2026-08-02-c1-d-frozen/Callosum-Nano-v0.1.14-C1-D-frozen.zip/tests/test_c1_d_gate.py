import json
from pathlib import Path

from callosum_nano.c1_d_gate import adjudicate


def _result(condition: str, seed: int, learned: bool) -> dict:
    endpoint = {
        "free_code_acc": 1.0,
        "free_value_acc": 1.0 if learned else 0.25,
        "free_v_given4_acc": 1.0 if learned else 0.25,
        "free_chain_exact_acc": 1.0 if learned else 0.25,
        "query_job_acc": 1.0 if learned else 0.25,
    }
    zero16 = {**endpoint, "free_value_acc": 0.0625, "query_job_acc": 0.25}
    zero4 = {**endpoint, "free_v_given4_acc": 0.25, "query_job_acc": 0.25}
    return {
        "condition": condition,
        "endpoint_step": 10_000,
        "endpoint_validation": endpoint,
        "best_bridge_zero_validation": zero16,
        "best_left_to_right_zero_validation": zero4,
        "best_right_to_left_zero_validation": {
            **endpoint,
            "free_value_acc": 0.0625,
            "query_job_acc": 1.0,
        },
        "train": {
            "steps": 10_000, "batch_size": 64, "learning_rate": 3e-3,
            "warmup_steps": 1, "lr_decay_steps": 10_000,
            "min_lr_ratio": 1.0, "weight_decay": 0.0, "grad_clip": 1.0,
            "eval_interval": 200, "validation_episodes": 4_096,
            "job_lambda": 1.0, "data_mode": "chain-two-hop",
            "full_lm_lambda": 0.0, "id_count": 16,
            "filler_mode": "random", "probe_episodes": 4_096, "seed": seed,
        },
        "model": {
            "variant": "twin-callosum", "n_layers": 2, "n_heads": 2,
            "branch_width": 64, "callosum_rank": 8,
            "interface_width": 64, "mlp_ratio": 4, "dropout": 0.0,
            "position_encoding": "learned", "c1_heads": True,
            "c1_answer_classes": 16, "c1_head_style": "shared-vocab-plain",
            "c1_block_style": "nano-pre-rms",
            "c1_input_style": "direct-default", "c1_query_job_head": True,
        },
        "logging_audit": {
            "resume_start_step": 0,
            "train_curve": {"records": 10_000, "first_step": 1,
                "last_step": 10_000, "missing_required_new_steps": 0,
                "malformed_records": 0, "nul_holes": 0},
            "metrics": {"records": 51, "first_step": 1,
                "last_step": 10_000, "missing_required_new_steps": 0,
                "malformed_records": 0, "nul_holes": 0},
        },
    }


def test_c1_d_gate_distinguishes_job_reliability_and_directionality(tmp_path: Path) -> None:
    results = [
        _result("c1-d-shuttle-no-job", 1, True),
        _result("c1-d-shuttle-no-job", 2, False),
        _result("c1-d-query-job", 1, True),
        _result("c1-d-query-job", 2, True),
    ]
    (tmp_path / "summary.json").write_text(
        json.dumps({"results": results}), encoding="utf-8"
    )
    gate = adjudicate(tmp_path)
    assert gate["d_passed"]
    assert gate["directional_causality_passed"]
    assert gate["d0_endpoint_pass_count"] == 1
    assert "seed-dependent" in gate["interpretation"]
