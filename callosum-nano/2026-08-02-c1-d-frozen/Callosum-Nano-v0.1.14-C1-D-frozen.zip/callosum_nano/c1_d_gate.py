from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


PASS = 0.90
CHANCE16 = 0.10
CHANCE4 = 0.30

EXPECTED_TRAIN = {
    "steps": 10_000,
    "batch_size": 64,
    "learning_rate": 3e-3,
    "warmup_steps": 1,
    "lr_decay_steps": 10_000,
    "min_lr_ratio": 1.0,
    "weight_decay": 0.0,
    "grad_clip": 1.0,
    "eval_interval": 200,
    "validation_episodes": 4_096,
    "job_lambda": 1.0,
    "data_mode": "chain-two-hop",
    "full_lm_lambda": 0.0,
    "id_count": 16,
    "filler_mode": "random",
    "probe_episodes": 4_096,
}

EXPECTED_MODEL = {
    "variant": "twin-callosum",
    "n_layers": 2,
    "n_heads": 2,
    "branch_width": 64,
    "callosum_rank": 8,
    "interface_width": 64,
    "mlp_ratio": 4,
    "dropout": 0.0,
    "position_encoding": "learned",
    "c1_heads": True,
    "c1_answer_classes": 16,
    "c1_head_style": "shared-vocab-plain",
    "c1_block_style": "nano-pre-rms",
    "c1_input_style": "direct-default",
    "c1_query_job_head": True,
}


def _check_fields(actual: dict[str, Any], expected: dict[str, Any], label: str) -> None:
    for key, value in expected.items():
        if actual.get(key) != value:
            raise ValueError(
                f"{label}: {key}={actual.get(key)!r}, expected {value!r}"
            )


def _audit_is_green(result: dict[str, Any]) -> bool:
    audit = result.get("logging_audit", {})
    for ledger, records in (
        (audit.get("train_curve", {}), 10_000),
        (audit.get("metrics", {}), 51),
    ):
        if (
            ledger.get("records") != records
            or ledger.get("first_step") != 1
            or ledger.get("last_step") != 10_000
            or any(
                ledger.get(key) != 0
                for key in (
                    "missing_required_new_steps",
                    "malformed_records",
                    "nul_holes",
                )
            )
        ):
            return False
    start = audit.get("resume_start_step")
    return isinstance(start, int) and 0 <= start < 10_000


def _endpoint(result: dict[str, Any]) -> dict[str, Any]:
    condition = result["condition"]
    seed = int(result["train"]["seed"])
    _check_fields(result["train"], EXPECTED_TRAIN, f"{condition}/s{seed} train")
    _check_fields(result["model"], EXPECTED_MODEL, f"{condition}/s{seed} model")
    if result.get("endpoint_step") != 10_000:
        raise ValueError(f"{condition}/s{seed}: endpoint is not 10000")
    value = result["endpoint_validation"]
    return {
        "seed": seed,
        "free_code_acc": value["free_code_acc"],
        "free_value_acc": value["free_value_acc"],
        "free_v_given4_acc": value["free_v_given4_acc"],
        "free_chain_exact_acc": value["free_chain_exact_acc"],
        "query_slot_acc": value["query_job_acc"],
        "logging_audit_green": _audit_is_green(result),
    }


def _directional(result: dict[str, Any]) -> dict[str, Any]:
    both = result["best_bridge_zero_validation"]
    l2r = result["best_left_to_right_zero_validation"]
    r2l = result["best_right_to_left_zero_validation"]
    checks = {
        "both_zero": {
            "query_slot_acc": both["query_job_acc"],
            "free_value_acc": both["free_value_acc"],
            "passed": (
                both["query_job_acc"] <= CHANCE4
                and both["free_value_acc"] <= CHANCE16
            ),
        },
        "left_to_right_zero": {
            "query_slot_acc": l2r["query_job_acc"],
            "free_v_given4_acc": l2r["free_v_given4_acc"],
            "passed": (
                l2r["query_job_acc"] <= CHANCE4
                and l2r["free_v_given4_acc"] <= CHANCE4
            ),
        },
        "right_to_left_zero": {
            "query_slot_acc": r2l["query_job_acc"],
            "free_value_acc": r2l["free_value_acc"],
            "passed": (
                r2l["query_job_acc"] >= PASS
                and r2l["free_value_acc"] <= CHANCE16
            ),
        },
    }
    checks["passed"] = all(v["passed"] for v in checks.values())
    return checks


def adjudicate(root: Path) -> dict[str, Any]:
    results = json.loads((root / "summary.json").read_text(encoding="utf-8"))[
        "results"
    ]
    expected = {
        (condition, seed)
        for condition in ("c1-d-shuttle-no-job", "c1-d-query-job")
        for seed in (1, 2)
    }
    if {(r["condition"], int(r["train"]["seed"])) for r in results} != expected:
        raise ValueError("summary does not contain exactly D0/D paired seeds")

    rows: dict[str, list[dict[str, Any]]] = {}
    for condition in ("c1-d-shuttle-no-job", "c1-d-query-job"):
        rows[condition] = [
            _endpoint(r) for r in results if r["condition"] == condition
        ]
    for row in rows["c1-d-query-job"]:
        row["passed"] = (
            row["logging_audit_green"]
            and row["free_code_acc"] >= PASS
            and row["free_chain_exact_acc"] >= PASS
            and row["query_slot_acc"] >= PASS
        )
    d_results = [r for r in results if r["condition"] == "c1-d-query-job"]
    directional = [
        {"seed": int(r["train"]["seed"]), **_directional(r)}
        for r in d_results
    ]
    d_passed = all(r["passed"] for r in rows["c1-d-query-job"])
    causal_passed = all(r["passed"] for r in directional)
    d0_passes = sum(
        row["logging_audit_green"]
        and row["free_code_acc"] >= PASS
        and row["free_chain_exact_acc"] >= PASS
        and row["query_slot_acc"] >= PASS
        for row in rows["c1-d-shuttle-no-job"]
    )
    if d_passed and causal_passed and d0_passes < 2:
        interpretation = (
            "address supervision makes the two-leg shuttle reliable within 10k; "
            "the same architecture without the job remains seed-dependent"
        )
    elif d_passed and causal_passed:
        interpretation = (
            "the shuttle is causal and reliable, but endpoint evidence does not "
            "show that explicit address supervision is necessary"
        )
    elif d_passed:
        interpretation = "D learns, but directional necessity audit fails; no bridge claim"
    else:
        interpretation = "D fails the paired-seed 10k success gate"

    gate = {
        "assay": "C1-D-query-conditioned-shuttle",
        "d_passed": d_passed,
        "directional_causality_passed": causal_passed,
        "d0_endpoint_pass_count": d0_passes,
        "cells": rows,
        "directional_ablations": directional,
        "interpretation": interpretation,
        "scope": (
            "assay-specific pointer/retrieval inductive bias plus low-rank "
            "two-way communication; not a claim that a plain Transformer "
            "spontaneously invents binding"
        ),
    }
    (root / "c1_d_gate.json").write_text(
        json.dumps(gate, indent=2, sort_keys=True), encoding="utf-8"
    )
    return gate


def main() -> None:
    parser = argparse.ArgumentParser(description="Adjudicate frozen C1-D")
    parser.add_argument("root", type=Path)
    args = parser.parse_args()
    gate = adjudicate(args.root)
    print(json.dumps(gate, indent=2, sort_keys=True))
    if not gate["d_passed"] or not gate["directional_causality_passed"]:
        raise SystemExit(3)


if __name__ == "__main__":
    main()
