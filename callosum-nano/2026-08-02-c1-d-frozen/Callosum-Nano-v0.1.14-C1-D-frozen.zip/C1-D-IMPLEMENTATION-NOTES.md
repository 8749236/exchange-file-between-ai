# C1-D 实现与 smoke 记录

- 版本：Callosum Nano 0.1.14
- tests：48/48 passed（CPU，torch 2.13.0+cpu）
- 可见性：右支 query-code 位 63 固定 MASK；free run 只把预测 code 写入左支。
- 因果性：改变未来输入 64 不改变四槽指针 logits。
- 梯度：地址 CE 进入左→右桥，不进入右→左桥；正式左答案 CE 负责返回腿。
- 消融开关：每层桥支持 left-to-right/right-to-left 独立关闭，评估后自动复位。
- 捷径审计：地址标签是随机排列后 B-code 的唯一匹配槽，四槽 chance=1/4；不能靠
  value 集合或固定位置稳定得分。

设计校准使用 2,000 steps、fixed-valid 512，仅用于发现/修复第一版 value-class job
仍可退化为“值袋子”的漏洞。最终冻结版改为 slot-pointer job 后，D seed 1/2 均在
2k 达到完整 chain=1.0；D0 seed 1 逃逸、seed 2 保持约 .264。临时工作区清理发生在
校准完成后，因此这些终端结果不随包作为正式证据；正式判决只读取新炉原始结果。
